Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class PainterInfo
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("LinkLabel2")>
		Private _LinkLabel2 As LinkLabel

		<AccessedThroughProperty("LinkLabel1")>
		Private _LinkLabel1 As LinkLabel

		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		<AccessedThroughProperty("LinkLabel3")>
		Private _LinkLabel3 As LinkLabel

		<AccessedThroughProperty("LinkLabel4")>
		Private _LinkLabel4 As LinkLabel

		Friend Overridable Property LinkLabel2() As LinkLabel
			Get
				Return Me._LinkLabel2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As LinkLabel)
				Me._LinkLabel2 = value
			End Set
		End Property

		Friend Overridable Property LinkLabel1() As LinkLabel
			Get
				Return Me._LinkLabel1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As LinkLabel)
				Me._LinkLabel1 = value
			End Set
		End Property

		Friend Overridable Property Label1() As Label
			Get
				Return Me._Label1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		Friend Overridable Property Label2() As Label
			Get
				Return Me._Label2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		Friend Overridable Property LinkLabel3() As LinkLabel
			Get
				Return Me._LinkLabel3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As LinkLabel)
				Me._LinkLabel3 = value
			End Set
		End Property

		Friend Overridable Property LinkLabel4() As LinkLabel
			Get
				Return Me._LinkLabel4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As LinkLabel)
				Me._LinkLabel4 = value
			End Set
		End Property

		Public Sub New()
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			AddressOf Me.LinkLabel2 = New LinkLabel()
			AddressOf Me.LinkLabel1 = New LinkLabel()
			AddressOf Me.Label1 = New Label()
			AddressOf Me.Label2 = New Label()
			AddressOf Me.LinkLabel3 = New LinkLabel()
			AddressOf Me.LinkLabel4 = New LinkLabel()
			Me.SuspendLayout()
			AddressOf Me.LinkLabel2.AutoSize = True
			Dim arg_66_0 As Control = AddressOf Me.LinkLabel2
			Dim location As Point = New Point(19, 36)
			arg_66_0.Location = location
			AddressOf Me.LinkLabel2.Name = "LinkLabel2"
			Dim arg_90_0 As Control = AddressOf Me.LinkLabel2
			Dim size As Size = New Size(453, 13)
			arg_90_0.Size = size
			AddressOf Me.LinkLabel2.TabIndex = 22
			AddressOf Me.LinkLabel2.TabStop = True
			AddressOf Me.LinkLabel2.Text = "https://www.vb-paradise.de/index.php/Thread/57156-TuT-Eigenes-Paint-Programm-erstellen/"
			AddressOf Me.LinkLabel1.AutoSize = True
			Dim arg_DC_0 As Control = AddressOf Me.LinkLabel1
			location = New Point(19, 22)
			arg_DC_0.Location = location
			AddressOf Me.LinkLabel1.Name = "LinkLabel1"
			Dim arg_106_0 As Control = AddressOf Me.LinkLabel1
			size = New Size(293, 13)
			arg_106_0.Size = size
			AddressOf Me.LinkLabel1.TabIndex = 21
			AddressOf Me.LinkLabel1.TabStop = True
			AddressOf Me.LinkLabel1.Text = "https://www.vb-paradise.de/index.php/User/12105-Gather/"
			AddressOf Me.Label1.AutoSize = True
			Dim arg_152_0 As Control = AddressOf Me.Label1
			location = New Point(12, 9)
			arg_152_0.Location = location
			AddressOf Me.Label1.Name = "Label1"
			Dim arg_179_0 As Control = AddressOf Me.Label1
			size = New Size(121, 13)
			arg_179_0.Size = size
			AddressOf Me.Label1.TabIndex = 20
			AddressOf Me.Label1.Text = "Code by 'Gather Design'"
			AddressOf Me.Label2.AutoSize = True
			Dim arg_1B9_0 As Control = AddressOf Me.Label2
			location = New Point(12, 49)
			arg_1B9_0.Location = location
			AddressOf Me.Label2.Name = "Label2"
			Dim arg_1E3_0 As Control = AddressOf Me.Label2
			size = New Size(193, 13)
			arg_1E3_0.Size = size
			AddressOf Me.Label2.TabIndex = 23
			AddressOf Me.Label2.Text = "Design and  adjustments by 'Sky Super'"
			AddressOf Me.LinkLabel3.AutoSize = True
			Dim arg_223_0 As Control = AddressOf Me.LinkLabel3
			location = New Point(19, 62)
			arg_223_0.Location = location
			AddressOf Me.LinkLabel3.Name = "LinkLabel3"
			Dim arg_24D_0 As Control = AddressOf Me.LinkLabel3
			size = New Size(148, 13)
			arg_24D_0.Size = size
			AddressOf Me.LinkLabel3.TabIndex = 24
			AddressOf Me.LinkLabel3.TabStop = True
			AddressOf Me.LinkLabel3.Text = "http://gmmodsbyskysuper.net" & vbCrLf
			AddressOf Me.LinkLabel4.AutoSize = True
			Dim arg_299_0 As Control = AddressOf Me.LinkLabel4
			location = New Point(19, 75)
			arg_299_0.Location = location
			AddressOf Me.LinkLabel4.Name = "LinkLabel4"
			Dim arg_2C0_0 As Control = AddressOf Me.LinkLabel4
			size = New Size(100, 13)
			arg_2C0_0.Size = size
			AddressOf Me.LinkLabel4.TabIndex = 25
			AddressOf Me.LinkLabel4.TabStop = True
			AddressOf Me.LinkLabel4.Text = "http://gmmods.com"
			Dim autoScaleDimensions As SizeF = New SizeF(6F, 13F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			size = New Size(478, 97)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.LinkLabel4)
			Me.Controls.Add(AddressOf Me.LinkLabel3)
			Me.Controls.Add(AddressOf Me.Label2)
			Me.Controls.Add(AddressOf Me.LinkLabel2)
			Me.Controls.Add(AddressOf Me.LinkLabel1)
			Me.Controls.Add(AddressOf Me.Label1)
			Me.DoubleBuffered = True
			Me.ForeColor = Color.White
			Me.FormBorderStyle = FormBorderStyle.FixedDialog
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "PainterInfo"
			Me.ShowIcon = False
			Me.ShowInTaskbar = False
			Me.StartPosition = FormStartPosition.CenterScreen
			Me.Text = "PainterInfo"
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub
	End Class
End Namespace
