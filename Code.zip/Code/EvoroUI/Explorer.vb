Imports EvoroUI.My
Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Explorer
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("SplitContainer1")>
		Private _SplitContainer1 As SplitContainer

		<AccessedThroughProperty("ListBox1")>
		Private _ListBox1 As ListBox

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("GroupBox1")>
		Private _GroupBox1 As GroupBox

		<AccessedThroughProperty("Button2")>
		Private _Button2 As Button

		<AccessedThroughProperty("ListBox2")>
		Private _ListBox2 As ListBox

		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		<AccessedThroughProperty("Ü2LBL")>
		Private _Ü2LBL As Label

		<AccessedThroughProperty("Ü1LBL")>
		Private _Ü1LBL As Label

		<AccessedThroughProperty("GroupBox2")>
		Private _GroupBox2 As GroupBox

		<AccessedThroughProperty("Button3")>
		Private _Button3 As Button

		<AccessedThroughProperty("TextBox1")>
		Private _TextBox1 As TextBox

		<AccessedThroughProperty("GroupBox3")>
		Private _GroupBox3 As GroupBox

		<AccessedThroughProperty("Button8")>
		Private _Button8 As Button

		<AccessedThroughProperty("Button7")>
		Private _Button7 As Button

		<AccessedThroughProperty("Button6")>
		Private _Button6 As Button

		<AccessedThroughProperty("Button5")>
		Private _Button5 As Button

		<AccessedThroughProperty("Button4")>
		Private _Button4 As Button

		<AccessedThroughProperty("PictureBox1")>
		Private _PictureBox1 As PictureBox

		<AccessedThroughProperty("GroupBox4")>
		Private _GroupBox4 As GroupBox

		<AccessedThroughProperty("TextBox2")>
		Private _TextBox2 As TextBox

		<AccessedThroughProperty("DomainUpDown1")>
		Private _DomainUpDown1 As DomainUpDown

		<AccessedThroughProperty("Button9")>
		Private _Button9 As Button

		<AccessedThroughProperty("GroupBox5")>
		Private _GroupBox5 As GroupBox

		<AccessedThroughProperty("PictureBox2")>
		Private _PictureBox2 As PictureBox

		<AccessedThroughProperty("Button10")>
		Private _Button10 As Button

		Private pfad As String

		Private Dateiname As String

		Friend Overridable Property SplitContainer1() As SplitContainer
			Get
				Return Me._SplitContainer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As SplitContainer)
				Me._SplitContainer1 = value
			End Set
		End Property

		Friend Overridable Property ListBox1() As ListBox
			Get
				Return Me._ListBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Dim value2 As EventHandler = AddressOf Me.ListBox1_SelectedIndexChanged
				If Me._ListBox1 IsNot Nothing Then
					RemoveHandler Me._ListBox1.SelectedIndexChanged, value2
				End If
				Me._ListBox1 = value
				If Me._ListBox1 IsNot Nothing Then
					AddHandler Me._ListBox1.SelectedIndexChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button1_Click
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.Click, value2
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property GroupBox1() As GroupBox
			Get
				Return Me._GroupBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox1 = value
			End Set
		End Property

		Friend Overridable Property Button2() As Button
			Get
				Return Me._Button2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button2_Click
				If Me._Button2 IsNot Nothing Then
					RemoveHandler Me._Button2.Click, value2
				End If
				Me._Button2 = value
				If Me._Button2 IsNot Nothing Then
					AddHandler Me._Button2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ListBox2() As ListBox
			Get
				Return Me._ListBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Dim value2 As EventHandler = AddressOf Me.ListBox2_SelectedIndexChanged
				If Me._ListBox2 IsNot Nothing Then
					RemoveHandler Me._ListBox2.SelectedIndexChanged, value2
				End If
				Me._ListBox2 = value
				If Me._ListBox2 IsNot Nothing Then
					AddHandler Me._ListBox2.SelectedIndexChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property Timer1() As Timer
			Get
				Return Me._Timer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer1_Tick
				If Me._Timer1 IsNot Nothing Then
					RemoveHandler Me._Timer1.Tick, value2
				End If
				Me._Timer1 = value
				If Me._Timer1 IsNot Nothing Then
					AddHandler Me._Timer1.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Ü2LBL() As Label
			Get
				Return Me._Ü2LBL
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Ü2LBL = value
			End Set
		End Property

		Friend Overridable Property Ü1LBL() As Label
			Get
				Return Me._Ü1LBL
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Ü1LBL = value
			End Set
		End Property

		Friend Overridable Property GroupBox2() As GroupBox
			Get
				Return Me._GroupBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox2 = value
			End Set
		End Property

		Friend Overridable Property Button3() As Button
			Get
				Return Me._Button3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button3_Click
				If Me._Button3 IsNot Nothing Then
					RemoveHandler Me._Button3.Click, value2
				End If
				Me._Button3 = value
				If Me._Button3 IsNot Nothing Then
					AddHandler Me._Button3.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property TextBox1() As TextBox
			Get
				Return Me._TextBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox1 = value
			End Set
		End Property

		Friend Overridable Property GroupBox3() As GroupBox
			Get
				Return Me._GroupBox3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox3 = value
			End Set
		End Property

		Friend Overridable Property Button8() As Button
			Get
				Return Me._Button8
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button8_Click
				If Me._Button8 IsNot Nothing Then
					RemoveHandler Me._Button8.Click, value2
				End If
				Me._Button8 = value
				If Me._Button8 IsNot Nothing Then
					AddHandler Me._Button8.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button7() As Button
			Get
				Return Me._Button7
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button7_Click
				If Me._Button7 IsNot Nothing Then
					RemoveHandler Me._Button7.Click, value2
				End If
				Me._Button7 = value
				If Me._Button7 IsNot Nothing Then
					AddHandler Me._Button7.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button6() As Button
			Get
				Return Me._Button6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button6_Click
				If Me._Button6 IsNot Nothing Then
					RemoveHandler Me._Button6.Click, value2
				End If
				Me._Button6 = value
				If Me._Button6 IsNot Nothing Then
					AddHandler Me._Button6.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button5() As Button
			Get
				Return Me._Button5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button5_Click
				If Me._Button5 IsNot Nothing Then
					RemoveHandler Me._Button5.Click, value2
				End If
				Me._Button5 = value
				If Me._Button5 IsNot Nothing Then
					AddHandler Me._Button5.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button4() As Button
			Get
				Return Me._Button4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button4_Click
				If Me._Button4 IsNot Nothing Then
					RemoveHandler Me._Button4.Click, value2
				End If
				Me._Button4 = value
				If Me._Button4 IsNot Nothing Then
					AddHandler Me._Button4.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property PictureBox1() As PictureBox
			Get
				Return Me._PictureBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Dim value2 As EventHandler = AddressOf Me.PictureBox1_Click
				If Me._PictureBox1 IsNot Nothing Then
					RemoveHandler Me._PictureBox1.Click, value2
				End If
				Me._PictureBox1 = value
				If Me._PictureBox1 IsNot Nothing Then
					AddHandler Me._PictureBox1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property GroupBox4() As GroupBox
			Get
				Return Me._GroupBox4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox4 = value
			End Set
		End Property

		Friend Overridable Property TextBox2() As TextBox
			Get
				Return Me._TextBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox2 = value
			End Set
		End Property

		Friend Overridable Property DomainUpDown1() As DomainUpDown
			Get
				Return Me._DomainUpDown1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As DomainUpDown)
				Me._DomainUpDown1 = value
			End Set
		End Property

		Friend Overridable Property Button9() As Button
			Get
				Return Me._Button9
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button9_Click
				If Me._Button9 IsNot Nothing Then
					RemoveHandler Me._Button9.Click, value2
				End If
				Me._Button9 = value
				If Me._Button9 IsNot Nothing Then
					AddHandler Me._Button9.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property GroupBox5() As GroupBox
			Get
				Return Me._GroupBox5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox5 = value
			End Set
		End Property

		Friend Overridable Property PictureBox2() As PictureBox
			Get
				Return Me._PictureBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox2 = value
			End Set
		End Property

		Friend Overridable Property Button10() As Button
			Get
				Return Me._Button10
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button10_Click
				If Me._Button10 IsNot Nothing Then
					RemoveHandler Me._Button10.Click, value2
				End If
				Me._Button10 = value
				If Me._Button10 IsNot Nothing Then
					AddHandler Me._Button10.Click, value2
				End If
			End Set
		End Property

		Public Sub New()
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Container()
			Dim resources As ComponentResourceManager = New ComponentResourceManager(GetType(Explorer))
			AddressOf Me.SplitContainer1 = New SplitContainer()
			AddressOf Me.GroupBox2 = New GroupBox()
			AddressOf Me.TextBox1 = New TextBox()
			AddressOf Me.Ü2LBL = New Label()
			AddressOf Me.Ü1LBL = New Label()
			AddressOf Me.ListBox2 = New ListBox()
			AddressOf Me.ListBox1 = New ListBox()
			AddressOf Me.GroupBox3 = New GroupBox()
			AddressOf Me.GroupBox1 = New GroupBox()
			AddressOf Me.Timer1 = New Timer(Me.components)
			AddressOf Me.Button3 = New Button()
			AddressOf Me.Button1 = New Button()
			AddressOf Me.PictureBox1 = New PictureBox()
			AddressOf Me.Button8 = New Button()
			AddressOf Me.Button7 = New Button()
			AddressOf Me.Button6 = New Button()
			AddressOf Me.Button5 = New Button()
			AddressOf Me.Button4 = New Button()
			AddressOf Me.Button2 = New Button()
			AddressOf Me.GroupBox4 = New GroupBox()
			AddressOf Me.Button9 = New Button()
			AddressOf Me.DomainUpDown1 = New DomainUpDown()
			AddressOf Me.TextBox2 = New TextBox()
			AddressOf Me.GroupBox5 = New GroupBox()
			AddressOf Me.Button10 = New Button()
			AddressOf Me.PictureBox2 = New PictureBox()
			(CType(AddressOf Me.SplitContainer1, ISupportInitialize)).BeginInit()
			AddressOf Me.SplitContainer1.Panel1.SuspendLayout()
			AddressOf Me.SplitContainer1.Panel2.SuspendLayout()
			AddressOf Me.SplitContainer1.SuspendLayout()
			AddressOf Me.GroupBox2.SuspendLayout()
			AddressOf Me.GroupBox3.SuspendLayout()
			AddressOf Me.GroupBox1.SuspendLayout()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).BeginInit()
			AddressOf Me.GroupBox4.SuspendLayout()
			AddressOf Me.GroupBox5.SuspendLayout()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).BeginInit()
			Me.SuspendLayout()
			AddressOf Me.SplitContainer1.Dock = DockStyle.Fill
			Dim arg_1E4_0 As Control = AddressOf Me.SplitContainer1
			Dim location As Point = New Point(0, 0)
			arg_1E4_0.Location = location
			AddressOf Me.SplitContainer1.Name = "SplitContainer1"
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.GroupBox2)
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.Ü2LBL)
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.Ü1LBL)
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.ListBox2)
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.Button1)
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.ListBox1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.GroupBox5)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.GroupBox4)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.PictureBox1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.GroupBox3)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.GroupBox1)
			Dim arg_33B_0 As Control = AddressOf Me.SplitContainer1
			Dim size As Size = New Size(880, 611)
			arg_33B_0.Size = size
			AddressOf Me.SplitContainer1.SplitterDistance = 661
			AddressOf Me.SplitContainer1.TabIndex = 0
			AddressOf Me.GroupBox2.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.GroupBox2.Controls.Add(AddressOf Me.Button3)
			AddressOf Me.GroupBox2.Controls.Add(AddressOf Me.TextBox1)
			Dim arg_3A7_0 As Control = AddressOf Me.GroupBox2
			location = New Point(12, 29)
			arg_3A7_0.Location = location
			AddressOf Me.GroupBox2.Name = "GroupBox2"
			Dim arg_3D2_0 As Control = AddressOf Me.GroupBox2
			size = New Size(646, 42)
			arg_3D2_0.Size = size
			AddressOf Me.GroupBox2.TabIndex = 6
			AddressOf Me.GroupBox2.TabStop = False
			AddressOf Me.GroupBox2.Text = "Eigene Quelle:"
			AddressOf Me.TextBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.TextBox1.AutoCompleteSource = AutoCompleteSource.FileSystemDirectories
			AddressOf Me.TextBox1.BackColor = SystemColors.ScrollBar
			Dim arg_43A_0 As Control = AddressOf Me.TextBox1
			location = New Point(6, 15)
			arg_43A_0.Location = location
			AddressOf Me.TextBox1.Name = "TextBox1"
			Dim arg_465_0 As Control = AddressOf Me.TextBox1
			size = New Size(475, 20)
			arg_465_0.Size = size
			AddressOf Me.TextBox1.TabIndex = 5
			AddressOf Me.Ü2LBL.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Ü2LBL.AutoSize = True
			Dim arg_4A4_0 As Control = AddressOf Me.Ü2LBL
			location = New Point(423, 74)
			arg_4A4_0.Location = location
			AddressOf Me.Ü2LBL.Name = "Ü2LBL"
			Dim arg_4CC_0 As Control = AddressOf Me.Ü2LBL
			size = New Size(58, 13)
			arg_4CC_0.Size = size
			AddressOf Me.Ü2LBL.TabIndex = 3
			AddressOf Me.Ü2LBL.Text = "Dateiname"
			AddressOf Me.Ü1LBL.AutoSize = True
			Dim arg_50B_0 As Control = AddressOf Me.Ü1LBL
			location = New Point(12, 74)
			arg_50B_0.Location = location
			AddressOf Me.Ü1LBL.Name = "Ü1LBL"
			Dim arg_533_0 As Control = AddressOf Me.Ü1LBL
			size = New Size(45, 13)
			arg_533_0.Size = size
			AddressOf Me.Ü1LBL.TabIndex = 2
			AddressOf Me.Ü1LBL.Text = "Adresse"
			AddressOf Me.ListBox2.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.ListBox2.BackColor = Color.DarkGray
			AddressOf Me.ListBox2.Cursor = Cursors.No
			AddressOf Me.ListBox2.Enabled = False
			AddressOf Me.ListBox2.ForeColor = Color.White
			AddressOf Me.ListBox2.FormattingEnabled = True
			Dim arg_5BE_0 As Control = AddressOf Me.ListBox2
			location = New Point(426, 90)
			arg_5BE_0.Location = location
			AddressOf Me.ListBox2.Name = "ListBox2"
			Dim arg_5EC_0 As Control = AddressOf Me.ListBox2
			size = New Size(256, 511)
			arg_5EC_0.Size = size
			AddressOf Me.ListBox2.TabIndex = 1
			AddressOf Me.ListBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.ListBox1.BackColor = Color.DimGray
			AddressOf Me.ListBox1.Cursor = Cursors.Hand
			AddressOf Me.ListBox1.ForeColor = Color.White
			AddressOf Me.ListBox1.FormattingEnabled = True
			Dim arg_658_0 As Control = AddressOf Me.ListBox1
			location = New Point(12, 90)
			arg_658_0.Location = location
			AddressOf Me.ListBox1.Name = "ListBox1"
			Dim arg_686_0 As Control = AddressOf Me.ListBox1
			size = New Size(408, 511)
			arg_686_0.Size = size
			AddressOf Me.ListBox1.TabIndex = 0
			AddressOf Me.GroupBox3.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.GroupBox3.Controls.Add(AddressOf Me.Button8)
			AddressOf Me.GroupBox3.Controls.Add(AddressOf Me.Button7)
			AddressOf Me.GroupBox3.Controls.Add(AddressOf Me.Button6)
			AddressOf Me.GroupBox3.Controls.Add(AddressOf Me.Button5)
			AddressOf Me.GroupBox3.Controls.Add(AddressOf Me.Button4)
			AddressOf Me.GroupBox3.FlatStyle = FlatStyle.Flat
			Dim arg_72F_0 As Control = AddressOf Me.GroupBox3
			location = New Point(3, 64)
			arg_72F_0.Location = location
			AddressOf Me.GroupBox3.Name = "GroupBox3"
			Dim arg_75D_0 As Control = AddressOf Me.GroupBox3
			size = New Size(209, 136)
			arg_75D_0.Size = size
			AddressOf Me.GroupBox3.TabIndex = 1
			AddressOf Me.GroupBox3.TabStop = False
			AddressOf Me.GroupBox3.Text = "Öffnen:"
			AddressOf Me.GroupBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.Button2)
			AddressOf Me.GroupBox1.FlatStyle = FlatStyle.Flat
			Dim arg_7CA_0 As Control = AddressOf Me.GroupBox1
			location = New Point(3, 10)
			arg_7CA_0.Location = location
			AddressOf Me.GroupBox1.Name = "GroupBox1"
			Dim arg_7F5_0 As Control = AddressOf Me.GroupBox1
			size = New Size(209, 48)
			arg_7F5_0.Size = size
			AddressOf Me.GroupBox1.TabIndex = 0
			AddressOf Me.GroupBox1.TabStop = False
			AddressOf Me.GroupBox1.Text = "Öffnen in:"
			AddressOf Me.Timer1.Enabled = True
			AddressOf Me.Timer1.Interval = 1
			AddressOf Me.Button3.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button3.BackgroundImage = AddressOf Resources.VerlaufGrau
			AddressOf Me.Button3.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button3.Cursor = Cursors.Arrow
			AddressOf Me.Button3.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button3.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Button3.ForeColor = Color.White
			Dim arg_8C1_0 As Control = AddressOf Me.Button3
			location = New Point(487, 11)
			arg_8C1_0.Location = location
			AddressOf Me.Button3.Name = "Button3"
			Dim arg_8EC_0 As Control = AddressOf Me.Button3
			size = New Size(153, 28)
			arg_8EC_0.Size = size
			AddressOf Me.Button3.TabIndex = 6
			AddressOf Me.Button3.Text = "Laden"
			AddressOf Me.Button3.UseVisualStyleBackColor = True
			AddressOf Me.Button1.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), Image)
			AddressOf Me.Button1.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button1.Cursor = Cursors.Arrow
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button1.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Button1.ForeColor = Color.White
			Dim arg_9A7_0 As Control = AddressOf Me.Button1
			location = New Point(12, 3)
			arg_9A7_0.Location = location
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_9D2_0 As Control = AddressOf Me.Button1
			size = New Size(646, 31)
			arg_9D2_0.Size = size
			AddressOf Me.Button1.TabIndex = 0
			AddressOf Me.Button1.Text = "Dateien Laden"
			AddressOf Me.Button1.UseVisualStyleBackColor = True
			AddressOf Me.PictureBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.PictureBox1.BorderStyle = BorderStyle.Fixed3D
			Dim arg_A30_0 As Control = AddressOf Me.PictureBox1
			location = New Point(200, 602)
			arg_A30_0.Location = location
			AddressOf Me.PictureBox1.Name = "PictureBox1"
			Dim arg_A5E_0 As Control = AddressOf Me.PictureBox1
			size = New Size(209, 199)
			arg_A5E_0.Size = size
			AddressOf Me.PictureBox1.TabIndex = 2
			AddressOf Me.PictureBox1.TabStop = False
			AddressOf Me.PictureBox1.Visible = False
			AddressOf Me.Button8.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button8.BackgroundImage = CType(resources.GetObject("Button8.BackgroundImage"), Image)
			AddressOf Me.Button8.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button8.Cursor = Cursors.Arrow
			AddressOf Me.Button8.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button8.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Button8.ForeColor = Color.White
			Dim arg_B15_0 As Control = AddressOf Me.Button8
			location = New Point(6, 97)
			arg_B15_0.Location = location
			AddressOf Me.Button8.Name = "Button8"
			Dim arg_B40_0 As Control = AddressOf Me.Button8
			size = New Size(197, 23)
			arg_B40_0.Size = size
			AddressOf Me.Button8.TabIndex = 5
			AddressOf Me.Button8.Text = "Musik"
			AddressOf Me.Button8.UseVisualStyleBackColor = True
			AddressOf Me.Button7.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button7.BackgroundImage = CType(resources.GetObject("Button7.BackgroundImage"), Image)
			AddressOf Me.Button7.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button7.Cursor = Cursors.Arrow
			AddressOf Me.Button7.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button7.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Button7.ForeColor = Color.White
			Dim arg_BFB_0 As Control = AddressOf Me.Button7
			location = New Point(6, 77)
			arg_BFB_0.Location = location
			AddressOf Me.Button7.Name = "Button7"
			Dim arg_C26_0 As Control = AddressOf Me.Button7
			size = New Size(197, 23)
			arg_C26_0.Size = size
			AddressOf Me.Button7.TabIndex = 4
			AddressOf Me.Button7.Text = "Videos"
			AddressOf Me.Button7.UseVisualStyleBackColor = True
			AddressOf Me.Button6.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button6.BackgroundImage = CType(resources.GetObject("Button6.BackgroundImage"), Image)
			AddressOf Me.Button6.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button6.Cursor = Cursors.Arrow
			AddressOf Me.Button6.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button6.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Button6.ForeColor = Color.White
			Dim arg_CE1_0 As Control = AddressOf Me.Button6
			location = New Point(6, 57)
			arg_CE1_0.Location = location
			AddressOf Me.Button6.Name = "Button6"
			Dim arg_D0C_0 As Control = AddressOf Me.Button6
			size = New Size(197, 23)
			arg_D0C_0.Size = size
			AddressOf Me.Button6.TabIndex = 3
			AddressOf Me.Button6.Text = "Dokumente"
			AddressOf Me.Button6.UseVisualStyleBackColor = True
			AddressOf Me.Button5.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"), Image)
			AddressOf Me.Button5.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button5.Cursor = Cursors.Arrow
			AddressOf Me.Button5.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button5.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Button5.ForeColor = Color.White
			Dim arg_DC7_0 As Control = AddressOf Me.Button5
			location = New Point(6, 39)
			arg_DC7_0.Location = location
			AddressOf Me.Button5.Name = "Button5"
			Dim arg_DF2_0 As Control = AddressOf Me.Button5
			size = New Size(197, 23)
			arg_DF2_0.Size = size
			AddressOf Me.Button5.TabIndex = 2
			AddressOf Me.Button5.Text = "Bilder"
			AddressOf Me.Button5.UseVisualStyleBackColor = True
			AddressOf Me.Button4.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), Image)
			AddressOf Me.Button4.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button4.Cursor = Cursors.Arrow
			AddressOf Me.Button4.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button4.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Button4.ForeColor = Color.White
			Dim arg_EAD_0 As Control = AddressOf Me.Button4
			location = New Point(6, 19)
			arg_EAD_0.Location = location
			AddressOf Me.Button4.Name = "Button4"
			Dim arg_ED8_0 As Control = AddressOf Me.Button4
			size = New Size(197, 23)
			arg_ED8_0.Size = size
			AddressOf Me.Button4.TabIndex = 1
			AddressOf Me.Button4.Text = "Desktop"
			AddressOf Me.Button4.UseVisualStyleBackColor = True
			AddressOf Me.Button2.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), Image)
			AddressOf Me.Button2.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button2.Cursor = Cursors.Arrow
			AddressOf Me.Button2.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button2.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Button2.ForeColor = Color.White
			Dim arg_F93_0 As Control = AddressOf Me.Button2
			location = New Point(6, 19)
			arg_F93_0.Location = location
			AddressOf Me.Button2.Name = "Button2"
			Dim arg_FBE_0 As Control = AddressOf Me.Button2
			size = New Size(197, 23)
			arg_FBE_0.Size = size
			AddressOf Me.Button2.TabIndex = 0
			AddressOf Me.Button2.Text = "Text Editor"
			AddressOf Me.Button2.UseVisualStyleBackColor = True
			AddressOf Me.GroupBox4.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.GroupBox4.Controls.Add(AddressOf Me.TextBox2)
			AddressOf Me.GroupBox4.Controls.Add(AddressOf Me.DomainUpDown1)
			AddressOf Me.GroupBox4.Controls.Add(AddressOf Me.Button9)
			AddressOf Me.GroupBox4.FlatStyle = FlatStyle.Flat
			Dim arg_105A_0 As Control = AddressOf Me.GroupBox4
			location = New Point(6, 206)
			arg_105A_0.Location = location
			AddressOf Me.GroupBox4.Name = "GroupBox4"
			Dim arg_1085_0 As Control = AddressOf Me.GroupBox4
			size = New Size(206, 102)
			arg_1085_0.Size = size
			AddressOf Me.GroupBox4.TabIndex = 6
			AddressOf Me.GroupBox4.TabStop = False
			AddressOf Me.GroupBox4.Text = "Erstellen:"
			AddressOf Me.Button9.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button9.BackgroundImage = CType(resources.GetObject("Button9.BackgroundImage"), Image)
			AddressOf Me.Button9.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button9.Cursor = Cursors.Arrow
			AddressOf Me.Button9.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button9.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Button9.ForeColor = Color.White
			Dim arg_1140_0 As Control = AddressOf Me.Button9
			location = New Point(6, 71)
			arg_1140_0.Location = location
			AddressOf Me.Button9.Name = "Button9"
			Dim arg_116B_0 As Control = AddressOf Me.Button9
			size = New Size(194, 23)
			arg_116B_0.Size = size
			AddressOf Me.Button9.TabIndex = 5
			AddressOf Me.Button9.Text = "Erstellen"
			AddressOf Me.Button9.UseVisualStyleBackColor = True
			AddressOf Me.DomainUpDown1.BackColor = SystemColors.ScrollBar
			AddressOf Me.DomainUpDown1.Items.Add(".txt")
			AddressOf Me.DomainUpDown1.Items.Add(".*")
			AddressOf Me.DomainUpDown1.Items.Add(".png")
			AddressOf Me.DomainUpDown1.Items.Add(".mp3")
			AddressOf Me.DomainUpDown1.Items.Add(".mp4")
			AddressOf Me.DomainUpDown1.Items.Add(".html")
			Dim arg_123D_0 As Control = AddressOf Me.DomainUpDown1
			location = New Point(6, 45)
			arg_123D_0.Location = location
			AddressOf Me.DomainUpDown1.Name = "DomainUpDown1"
			Dim arg_1268_0 As Control = AddressOf Me.DomainUpDown1
			size = New Size(191, 20)
			arg_1268_0.Size = size
			AddressOf Me.DomainUpDown1.TabIndex = 6
			AddressOf Me.DomainUpDown1.Text = "Dateityp"
			AddressOf Me.TextBox2.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.TextBox2.BackColor = SystemColors.ScrollBar
			Dim arg_12B7_0 As Control = AddressOf Me.TextBox2
			location = New Point(6, 19)
			arg_12B7_0.Location = location
			AddressOf Me.TextBox2.Name = "TextBox2"
			Dim arg_12E2_0 As Control = AddressOf Me.TextBox2
			size = New Size(191, 20)
			arg_12E2_0.Size = size
			AddressOf Me.TextBox2.TabIndex = 7
			AddressOf Me.TextBox2.Text = "Name"
			AddressOf Me.GroupBox5.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.GroupBox5.Controls.Add(AddressOf Me.PictureBox2)
			AddressOf Me.GroupBox5.Controls.Add(AddressOf Me.Button10)
			AddressOf Me.GroupBox5.FlatStyle = FlatStyle.Flat
			Dim arg_135C_0 As Control = AddressOf Me.GroupBox5
			location = New Point(6, 314)
			arg_135C_0.Location = location
			AddressOf Me.GroupBox5.Name = "GroupBox5"
			Dim arg_138A_0 As Control = AddressOf Me.GroupBox5
			size = New Size(206, 224)
			arg_138A_0.Size = size
			AddressOf Me.GroupBox5.TabIndex = 7
			AddressOf Me.GroupBox5.TabStop = False
			AddressOf Me.GroupBox5.Text = "Vorschau:"
			AddressOf Me.Button10.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button10.BackgroundImage = CType(resources.GetObject("Button10.BackgroundImage"), Image)
			AddressOf Me.Button10.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button10.Cursor = Cursors.Arrow
			AddressOf Me.Button10.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button10.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Button10.ForeColor = Color.White
			Dim arg_1448_0 As Control = AddressOf Me.Button10
			location = New Point(6, 195)
			arg_1448_0.Location = location
			AddressOf Me.Button10.Name = "Button10"
			Dim arg_1473_0 As Control = AddressOf Me.Button10
			size = New Size(194, 23)
			arg_1473_0.Size = size
			AddressOf Me.Button10.TabIndex = 5
			AddressOf Me.Button10.Text = "Bild betrachten"
			AddressOf Me.Button10.UseVisualStyleBackColor = True
			AddressOf Me.PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_14BD_0 As Control = AddressOf Me.PictureBox2
			location = New Point(6, 15)
			arg_14BD_0.Location = location
			AddressOf Me.PictureBox2.Name = "PictureBox2"
			Dim arg_14EB_0 As Control = AddressOf Me.PictureBox2
			size = New Size(194, 174)
			arg_14EB_0.Size = size
			AddressOf Me.PictureBox2.TabIndex = 8
			AddressOf Me.PictureBox2.TabStop = False
			Dim autoScaleDimensions As SizeF = New SizeF(6F, 13F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.White
			size = New Size(880, 611)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.SplitContainer1)
			Me.FormBorderStyle = FormBorderStyle.SizableToolWindow
			Me.MinimizeBox = False
			Me.Name = "Explorer"
			Me.Text = "Explorationer Evoro"
			AddressOf Me.SplitContainer1.Panel1.ResumeLayout(False)
			AddressOf Me.SplitContainer1.Panel1.PerformLayout()
			AddressOf Me.SplitContainer1.Panel2.ResumeLayout(False)
			(CType(AddressOf Me.SplitContainer1, ISupportInitialize)).EndInit()
			AddressOf Me.SplitContainer1.ResumeLayout(False)
			AddressOf Me.GroupBox2.ResumeLayout(False)
			AddressOf Me.GroupBox2.PerformLayout()
			AddressOf Me.GroupBox3.ResumeLayout(False)
			AddressOf Me.GroupBox1.ResumeLayout(False)
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).EndInit()
			AddressOf Me.GroupBox4.ResumeLayout(False)
			AddressOf Me.GroupBox4.PerformLayout()
			AddressOf Me.GroupBox5.ResumeLayout(False)
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).EndInit()
			Me.ResumeLayout(False)
		End Sub

		Private Sub BindingNavigatorMovePreviousItem_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			AddressOf Me.ListBox1.Items.Clear()
			AddressOf Me.ListBox2.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Files") Then
				Dim directory As DirectoryInfo = New DirectoryInfo("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Files")
				AddressOf AddressOf MySettingsProperty.Settings.Pfad = "C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Files"
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					AddressOf Me.ListBox1.Items.Add(file.FullName)
					AddressOf Me.ListBox2.Items.Add(file.Name)
				Next
			Else
				Interaction.MsgBox("Neuer leerer Ordner wird erstellt, da dieser noch nicht vorhanden ist, jedoch dringend benötigt wird. Der Ordner befindet sich auf dem Desktop.", MsgBoxStyle.OkOnly, Nothing)
				Try
					Directory.CreateDirectory("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Files")
					Interaction.MsgBox("Der Ordner wurde erstellt. Er befindet sich auf dem Desktop unter dem Namen: 'EvoroVOS'", MsgBoxStyle.OkOnly, Nothing)
				Catch expr_102 As Exception
					ProjectData.SetProjectError(expr_102)
					Interaction.MsgBox("Fehler beim erstellen des Ordners! Bitte schließe das Programm, erstelle auf deinem Desktop einen Ordner mit dem Namen 'EvoroVOS' mit einem untergeordnetem Ordner 'Files'.", MsgBoxStyle.Critical, Nothing)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub Button2_Click(sender As Object, e As EventArgs)
			Try
				Dim openFile As OpenFileDialog = New OpenFileDialog()
				If Operators.CompareString(AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label2.Text, "F", False) = 0 Then
					AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = AddressOf AddressOf MyProject.Forms.MDIParent1
					AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.TexteditorToolStripMenuItem.Visible = True
					AddressOf AddressOf MyProject.Forms.Texteditor.Show()
					AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label2.Text = "T"
					AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.Text = AddressOf MyProject.Computer.FileSystem.ReadAllText(Conversions.ToString(AddressOf Me.ListBox1.SelectedItem))
					Me.pfad = Conversions.ToString(AddressOf Me.ListBox1.SelectedItem)
				Else
					Interaction.MsgBox("Es ist bereits ein Dokument geöffnet. Bitte speichern sie das Dokument, schließen den Texteditor und versuchen es dann erneut.", MsgBoxStyle.Critical, Nothing)
				End If
				AddressOf MyProject.Computer.FileSystem.WriteAllText(Me.pfad, AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.Text, True)
			Catch expr_106 As Exception
				ProjectData.SetProjectError(expr_106)
				Interaction.MsgBox("Datei kann nicht geöffnet werden. Es können nur .txt-Dateien geöffnet werden.", MsgBoxStyle.Critical, Nothing)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub ListBox2_SelectedIndexChanged(sender As Object, e As EventArgs)
		End Sub

		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			AddressOf Me.ListBox2.TopIndex = AddressOf Me.ListBox1.TopIndex
		End Sub

		Private Sub Button3_Click(sender As Object, e As EventArgs)
			Dim Ownsrc As String = AddressOf Me.TextBox1.Text
			AddressOf Me.ListBox1.Items.Clear()
			AddressOf Me.ListBox2.Items.Clear()
			AddressOf AddressOf MySettingsProperty.Settings.Pfad = AddressOf Me.TextBox1.Text
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists(Ownsrc) Then
				Dim directory As DirectoryInfo = New DirectoryInfo(Ownsrc)
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					AddressOf Me.ListBox1.Items.Add(file.FullName)
					AddressOf Me.ListBox2.Items.Add(file.Name)
				Next
			Else
				Interaction.MsgBox("Ordner nicht gefunden.", MsgBoxStyle.OkOnly, Nothing)
			End If
		End Sub

		Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)
			AddressOf Me.ListBox2.SelectedIndex = AddressOf Me.ListBox1.SelectedIndex
		End Sub

		Private Sub Button4_Click(sender As Object, e As EventArgs)
			Dim DesktopPfad As String = "C:\Users\" + Environment.UserName + "\Desktop\"
			AddressOf Me.ListBox1.Items.Clear()
			AddressOf Me.ListBox2.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists(DesktopPfad) Then
				Dim directory As DirectoryInfo = New DirectoryInfo(DesktopPfad)
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					AddressOf Me.ListBox1.Items.Add(file.FullName)
					AddressOf Me.ListBox2.Items.Add(file.Name)
				Next
			Else
				Interaction.MsgBox("Ordner nicht gefunden.", MsgBoxStyle.OkOnly, Nothing)
			End If
		End Sub

		Private Sub Button5_Click(sender As Object, e As EventArgs)
			Dim BilderPfad As String = "C:\Users\" + Environment.UserName + "\Pictures\"
			AddressOf Me.ListBox1.Items.Clear()
			AddressOf Me.ListBox2.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists(BilderPfad) Then
				Dim directory As DirectoryInfo = New DirectoryInfo(BilderPfad)
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					AddressOf Me.ListBox1.Items.Add(file.FullName)
					AddressOf Me.ListBox2.Items.Add(file.Name)
				Next
			Else
				Interaction.MsgBox("Ordner nicht gefunden.", MsgBoxStyle.OkOnly, Nothing)
			End If
		End Sub

		Private Sub Button6_Click(sender As Object, e As EventArgs)
			Dim DokumentePfad As String = "C:\Users\" + Environment.UserName + "\Documents\"
			AddressOf Me.ListBox1.Items.Clear()
			AddressOf Me.ListBox2.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists(DokumentePfad) Then
				Dim directory As DirectoryInfo = New DirectoryInfo(DokumentePfad)
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					AddressOf Me.ListBox1.Items.Add(file.FullName)
					AddressOf Me.ListBox2.Items.Add(file.Name)
				Next
			Else
				Interaction.MsgBox("Ordner nicht gefunden.", MsgBoxStyle.OkOnly, Nothing)
			End If
		End Sub

		Private Sub Button7_Click(sender As Object, e As EventArgs)
			Dim VideosPfad As String = "C:\Users\" + Environment.UserName + "\Videos\"
			AddressOf Me.ListBox1.Items.Clear()
			AddressOf Me.ListBox2.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists(VideosPfad) Then
				Dim directory As DirectoryInfo = New DirectoryInfo(VideosPfad)
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					AddressOf Me.ListBox1.Items.Add(file.FullName)
					AddressOf Me.ListBox2.Items.Add(file.Name)
				Next
			Else
				Interaction.MsgBox("Ordner nicht gefunden.", MsgBoxStyle.OkOnly, Nothing)
			End If
		End Sub

		Private Sub Button8_Click(sender As Object, e As EventArgs)
			Dim MusikPfad As String = "C:\Users\" + Environment.UserName + "\music\"
			AddressOf Me.ListBox1.Items.Clear()
			AddressOf Me.ListBox2.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists(MusikPfad) Then
				Dim directory As DirectoryInfo = New DirectoryInfo(MusikPfad)
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					AddressOf Me.ListBox1.Items.Add(file.FullName)
					AddressOf Me.ListBox2.Items.Add(file.Name)
				Next
			Else
				Interaction.MsgBox("Ordner nicht gefunden.", MsgBoxStyle.OkOnly, Nothing)
			End If
		End Sub

		Private Sub PictureBox1_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub Button9_Click(sender As Object, e As EventArgs)
			Try
				AddressOf MyProject.Computer.FileSystem.WriteAllText(Conversions.ToString(Operators.ConcatenateObject(Environment.GetFolderPath(CType(Conversions.ToInteger(AddressOf AddressOf MySettingsProperty.Settings.Pfad), Environment.SpecialFolder)) + "\" + AddressOf Me.TextBox2.Text, AddressOf Me.DomainUpDown1.SelectedItem)), "Leer", True)
			Catch expr_5A As Exception
				ProjectData.SetProjectError(expr_5A)
				Interaction.MsgBox("Fehler. Datei konnte nicht erstellt werden.", MsgBoxStyle.Critical, Nothing)
				ProjectData.ClearProjectError()
			End Try
			Dim Ownsrc2 As String = AddressOf AddressOf MySettingsProperty.Settings.Pfad
			AddressOf Me.ListBox1.Items.Clear()
			AddressOf Me.ListBox2.Items.Clear()
			AddressOf AddressOf MySettingsProperty.Settings.Pfad = AddressOf Me.TextBox1.Text
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists(Ownsrc2) Then
				Dim directory As DirectoryInfo = New DirectoryInfo(Ownsrc2)
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					AddressOf Me.ListBox1.Items.Add(file.FullName)
					AddressOf Me.ListBox2.Items.Add(file.Name)
				Next
			Else
				Interaction.MsgBox("Ordner nicht gefunden.", MsgBoxStyle.OkOnly, Nothing)
			End If
		End Sub

		Private Sub Button10_Click(sender As Object, e As EventArgs)
			Try
				AddressOf Me.PictureBox2.BackgroundImage = CType(AddressOf Me.ListBox1.SelectedItem, Image)
			Catch expr_1D As Exception
				ProjectData.SetProjectError(expr_1D)
				Interaction.MsgBox("Anzeigen der Datei nicht möglich. Handelt es sich bei der Datei um eine Bild-Datei?", MsgBoxStyle.Critical, Nothing)
				ProjectData.ClearProjectError()
			End Try
		End Sub
	End Class
End Namespace
