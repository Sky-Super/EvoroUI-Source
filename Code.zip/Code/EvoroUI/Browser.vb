Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Browser
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("ToolStrip1")>
		Private _ToolStrip1 As ToolStrip

		<AccessedThroughProperty("TextBox1")>
		Private _TextBox1 As ToolStripTextBox

		<AccessedThroughProperty("ToolStripButton1")>
		Private _ToolStripButton1 As ToolStripButton

		<AccessedThroughProperty("ToolStripSeparator1")>
		Private _ToolStripSeparator1 As ToolStripSeparator

		<AccessedThroughProperty("ToolStripButton2")>
		Private _ToolStripButton2 As ToolStripButton

		<AccessedThroughProperty("ToolStripButton5")>
		Private _ToolStripButton5 As ToolStripButton

		<AccessedThroughProperty("ToolStripButton3")>
		Private _ToolStripButton3 As ToolStripButton

		<AccessedThroughProperty("ToolStripButton4")>
		Private _ToolStripButton4 As ToolStripButton

		<AccessedThroughProperty("ToolStripButton6")>
		Private _ToolStripButton6 As ToolStripButton

		<AccessedThroughProperty("WebBrowser1")>
		Private _WebBrowser1 As WebBrowser

		<AccessedThroughProperty("ToolStripSeparator2")>
		Private _ToolStripSeparator2 As ToolStripSeparator

		<AccessedThroughProperty("ToolStripButton7")>
		Private _ToolStripButton7 As ToolStripButton

		Friend Overridable Property ToolStrip1() As ToolStrip
			Get
				Return Me._ToolStrip1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStrip)
				Me._ToolStrip1 = value
			End Set
		End Property

		Friend Overridable Property TextBox1() As ToolStripTextBox
			Get
				Return Me._TextBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripTextBox)
				Me._TextBox1 = value
			End Set
		End Property

		Friend Overridable Property ToolStripButton1() As ToolStripButton
			Get
				Return Me._ToolStripButton1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton1_Click
				If Me._ToolStripButton1 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton1.Click, value2
				End If
				Me._ToolStripButton1 = value
				If Me._ToolStripButton1 IsNot Nothing Then
					AddHandler Me._ToolStripButton1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripSeparator1() As ToolStripSeparator
			Get
				Return Me._ToolStripSeparator1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripSeparator)
				Me._ToolStripSeparator1 = value
			End Set
		End Property

		Friend Overridable Property ToolStripButton2() As ToolStripButton
			Get
				Return Me._ToolStripButton2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton2_Click
				If Me._ToolStripButton2 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton2.Click, value2
				End If
				Me._ToolStripButton2 = value
				If Me._ToolStripButton2 IsNot Nothing Then
					AddHandler Me._ToolStripButton2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton5() As ToolStripButton
			Get
				Return Me._ToolStripButton5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton5_Click
				If Me._ToolStripButton5 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton5.Click, value2
				End If
				Me._ToolStripButton5 = value
				If Me._ToolStripButton5 IsNot Nothing Then
					AddHandler Me._ToolStripButton5.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton3() As ToolStripButton
			Get
				Return Me._ToolStripButton3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton3_Click
				If Me._ToolStripButton3 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton3.Click, value2
				End If
				Me._ToolStripButton3 = value
				If Me._ToolStripButton3 IsNot Nothing Then
					AddHandler Me._ToolStripButton3.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton4() As ToolStripButton
			Get
				Return Me._ToolStripButton4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton4_Click
				If Me._ToolStripButton4 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton4.Click, value2
				End If
				Me._ToolStripButton4 = value
				If Me._ToolStripButton4 IsNot Nothing Then
					AddHandler Me._ToolStripButton4.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton6() As ToolStripButton
			Get
				Return Me._ToolStripButton6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton6_Click
				If Me._ToolStripButton6 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton6.Click, value2
				End If
				Me._ToolStripButton6 = value
				If Me._ToolStripButton6 IsNot Nothing Then
					AddHandler Me._ToolStripButton6.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property WebBrowser1() As WebBrowser
			Get
				Return Me._WebBrowser1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As WebBrowser)
				Me._WebBrowser1 = value
			End Set
		End Property

		Friend Overridable Property ToolStripSeparator2() As ToolStripSeparator
			Get
				Return Me._ToolStripSeparator2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripSeparator)
				Me._ToolStripSeparator2 = value
			End Set
		End Property

		Friend Overridable Property ToolStripButton7() As ToolStripButton
			Get
				Return Me._ToolStripButton7
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton7_Click
				If Me._ToolStripButton7 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton7.Click, value2
				End If
				Me._ToolStripButton7 = value
				If Me._ToolStripButton7 IsNot Nothing Then
					AddHandler Me._ToolStripButton7.Click, value2
				End If
			End Set
		End Property

		Public Sub New()
			AddHandler MyBase.AutoSizeChanged, AddressOf Me.Browser_AutoSizeChanged
			AddHandler MyBase.Load, AddressOf Me.Browser_Load
			AddHandler MyBase.KeyDown, AddressOf Me.Browser_KeyDown
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim resources As ComponentResourceManager = New ComponentResourceManager(GetType(Browser))
			AddressOf Me.WebBrowser1 = New WebBrowser()
			AddressOf Me.ToolStrip1 = New ToolStrip()
			AddressOf Me.TextBox1 = New ToolStripTextBox()
			AddressOf Me.ToolStripButton1 = New ToolStripButton()
			AddressOf Me.ToolStripSeparator1 = New ToolStripSeparator()
			AddressOf Me.ToolStripButton2 = New ToolStripButton()
			AddressOf Me.ToolStripButton5 = New ToolStripButton()
			AddressOf Me.ToolStripButton3 = New ToolStripButton()
			AddressOf Me.ToolStripButton4 = New ToolStripButton()
			AddressOf Me.ToolStripSeparator2 = New ToolStripSeparator()
			AddressOf Me.ToolStripButton6 = New ToolStripButton()
			AddressOf Me.ToolStripButton7 = New ToolStripButton()
			AddressOf Me.ToolStrip1.SuspendLayout()
			Me.SuspendLayout()
			AddressOf Me.WebBrowser1.Dock = DockStyle.Fill
			Dim arg_C2_0 As Control = AddressOf Me.WebBrowser1
			Dim location As Point = New Point(0, 25)
			arg_C2_0.Location = location
			Dim arg_DA_0 As Control = AddressOf Me.WebBrowser1
			Dim size As Size = New Size(20, 20)
			arg_DA_0.MinimumSize = size
			AddressOf Me.WebBrowser1.Name = "WebBrowser1"
			Dim arg_108_0 As Control = AddressOf Me.WebBrowser1
			size = New Size(741, 638)
			arg_108_0.Size = size
			AddressOf Me.WebBrowser1.TabIndex = 2
			AddressOf Me.ToolStrip1.BackgroundImage = AddressOf Resources.VerlaufGrau
			AddressOf Me.ToolStrip1.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.ToolStrip1.Items.AddRange(New ToolStripItem()() { AddressOf Me.TextBox1, AddressOf Me.ToolStripButton1, AddressOf Me.ToolStripSeparator1, AddressOf Me.ToolStripButton2, AddressOf Me.ToolStripButton5, AddressOf Me.ToolStripButton3, AddressOf Me.ToolStripButton4, AddressOf Me.ToolStripSeparator2, AddressOf Me.ToolStripButton6, AddressOf Me.ToolStripButton7 })
			Dim arg_1C5_0 As Control = AddressOf Me.ToolStrip1
			location = New Point(0, 0)
			arg_1C5_0.Location = location
			AddressOf Me.ToolStrip1.Name = "ToolStrip1"
			Dim arg_1F0_0 As Control = AddressOf Me.ToolStrip1
			size = New Size(741, 25)
			arg_1F0_0.Size = size
			AddressOf Me.ToolStrip1.TabIndex = 1
			AddressOf Me.ToolStrip1.Text = "ToolStrip1"
			AddressOf Me.TextBox1.Name = "TextBox1"
			Dim arg_237_0 As ToolStripControlHost = AddressOf Me.TextBox1
			size = New Size(200, 25)
			arg_237_0.Size = size
			AddressOf Me.TextBox1.ToolTipText = "Suchfeld: Bitte URL eingeben oder mit STRG + V einsetzen"
			AddressOf Me.ToolStripButton1.Checked = True
			AddressOf Me.ToolStripButton1.CheckState = CheckState.Checked
			AddressOf Me.ToolStripButton1.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), Image)
			AddressOf Me.ToolStripButton1.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton1.Name = "ToolStripButton1"
			Dim arg_2BE_0 As ToolStripItem = AddressOf Me.ToolStripButton1
			size = New Size(23, 22)
			arg_2BE_0.Size = size
			AddressOf Me.ToolStripButton1.Text = "Suchen"
			AddressOf Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
			Dim arg_2F5_0 As ToolStripItem = AddressOf Me.ToolStripSeparator1
			size = New Size(6, 25)
			arg_2F5_0.Size = size
			AddressOf Me.ToolStripButton2.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), Image)
			AddressOf Me.ToolStripButton2.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton2.Name = "ToolStripButton2"
			Dim arg_354_0 As ToolStripItem = AddressOf Me.ToolStripButton2
			size = New Size(23, 22)
			arg_354_0.Size = size
			AddressOf Me.ToolStripButton2.Text = "Zurück"
			AddressOf Me.ToolStripButton5.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton5.Image = CType(resources.GetObject("ToolStripButton5.Image"), Image)
			AddressOf Me.ToolStripButton5.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton5.Name = "ToolStripButton5"
			Dim arg_3C3_0 As ToolStripItem = AddressOf Me.ToolStripButton5
			size = New Size(23, 22)
			arg_3C3_0.Size = size
			AddressOf Me.ToolStripButton5.Text = "Laden abbrechen"
			AddressOf Me.ToolStripButton3.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton3.Image = CType(resources.GetObject("ToolStripButton3.Image"), Image)
			AddressOf Me.ToolStripButton3.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton3.Name = "ToolStripButton3"
			Dim arg_432_0 As ToolStripItem = AddressOf Me.ToolStripButton3
			size = New Size(23, 22)
			arg_432_0.Size = size
			AddressOf Me.ToolStripButton3.Text = "Nächste Seite"
			AddressOf Me.ToolStripButton4.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), Image)
			AddressOf Me.ToolStripButton4.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton4.Name = "ToolStripButton4"
			Dim arg_4A1_0 As ToolStripItem = AddressOf Me.ToolStripButton4
			size = New Size(23, 22)
			arg_4A1_0.Size = size
			AddressOf Me.ToolStripButton4.Text = "Neu Laden"
			AddressOf Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
			Dim arg_4D8_0 As ToolStripItem = AddressOf Me.ToolStripSeparator2
			size = New Size(6, 25)
			arg_4D8_0.Size = size
			AddressOf Me.ToolStripButton6.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton6.Image = CType(resources.GetObject("ToolStripButton6.Image"), Image)
			AddressOf Me.ToolStripButton6.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton6.Name = "ToolStripButton6"
			Dim arg_537_0 As ToolStripItem = AddressOf Me.ToolStripButton6
			size = New Size(23, 22)
			arg_537_0.Size = size
			AddressOf Me.ToolStripButton6.Text = "Google"
			AddressOf Me.ToolStripButton7.BackColor = Color.White
			AddressOf Me.ToolStripButton7.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton7.Image = CType(resources.GetObject("ToolStripButton7.Image"), Image)
			AddressOf Me.ToolStripButton7.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton7.Name = "ToolStripButton7"
			Dim arg_5B6_0 As ToolStripItem = AddressOf Me.ToolStripButton7
			size = New Size(23, 22)
			arg_5B6_0.Size = size
			AddressOf Me.ToolStripButton7.Text = "GMmods"
			Dim autoScaleDimensions As SizeF = New SizeF(8F, 17F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			size = New Size(741, 663)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.WebBrowser1)
			Me.Controls.Add(AddressOf Me.ToolStrip1)
			Me.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Me.FormBorderStyle = FormBorderStyle.FixedToolWindow
			Dim margin As Padding = New Padding(4)
			Me.Margin = margin
			Me.MinimizeBox = False
			Me.Name = "Browser"
			Me.Text = "SkyWeb Evoro"
			AddressOf Me.ToolStrip1.ResumeLayout(False)
			AddressOf Me.ToolStrip1.PerformLayout()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		Private Sub Browser_KeyDown(sender As Object, e As KeyEventArgs)
			If e.Control AndAlso e.KeyCode = Keys.[Return] Then
				AddressOf Me.WebBrowser1.Navigate(AddressOf Me.TextBox1.Text)
			End If
		End Sub

		Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs)
			AddressOf Me.WebBrowser1.Navigate(AddressOf Me.TextBox1.Text)
		End Sub

		Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs)
			AddressOf Me.WebBrowser1.GoForward()
		End Sub

		Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs)
			AddressOf Me.WebBrowser1.GoBack()
		End Sub

		Private Sub ToolStripButton5_Click(sender As Object, e As EventArgs)
			AddressOf Me.WebBrowser1.[Stop]()
		End Sub

		Private Sub ToolStripButton4_Click(sender As Object, e As EventArgs)
			AddressOf Me.WebBrowser1.Refresh()
		End Sub

		Private Sub ToolStripButton6_Click(sender As Object, e As EventArgs)
			AddressOf Me.WebBrowser1.Navigate("https://google.de")
		End Sub

		Private Sub ToolStripButton7_Click(sender As Object, e As EventArgs)
			AddressOf Me.WebBrowser1.Navigate("http://gmmods.bplaced.net")
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			AddressOf Me.WebBrowser1.Navigate(AddressOf Me.TextBox1.Text)
		End Sub

		Private Sub Browser_AutoSizeChanged(sender As Object, e As EventArgs)
		End Sub

		Private Sub Browser_Load(sender As Object, e As EventArgs)
		End Sub
	End Class
End Namespace
