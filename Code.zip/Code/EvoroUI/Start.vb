Imports EvoroUI.My
Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Start
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("PictureBox1")>
		Private _PictureBox1 As PictureBox

		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		Friend Overridable Property PictureBox1() As PictureBox
			Get
				Return Me._PictureBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox1 = value
			End Set
		End Property

		Friend Overridable Property Timer1() As Timer
			Get
				Return Me._Timer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer1_Tick
				If Me._Timer1 IsNot Nothing Then
					RemoveHandler Me._Timer1.Tick, value2
				End If
				Me._Timer1 = value
				If Me._Timer1 IsNot Nothing Then
					AddHandler Me._Timer1.Tick, value2
				End If
			End Set
		End Property

		Public Sub New()
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Container()
			AddressOf Me.PictureBox1 = New PictureBox()
			AddressOf Me.Timer1 = New Timer(Me.components)
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).BeginInit()
			Me.SuspendLayout()
			AddressOf Me.PictureBox1.BackColor = Color.Transparent
			AddressOf Me.PictureBox1.BackgroundImage = AddressOf Resources.SkyVOSBig___Kopie
			AddressOf Me.PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
			Dim arg_76_0 As Control = AddressOf Me.PictureBox1
			Dim location As Point = New Point(12, 12)
			arg_76_0.Location = location
			AddressOf Me.PictureBox1.Name = "PictureBox1"
			Dim arg_A4_0 As Control = AddressOf Me.PictureBox1
			Dim size As Size = New Size(290, 290)
			arg_A4_0.Size = size
			AddressOf Me.PictureBox1.TabIndex = 0
			AddressOf Me.PictureBox1.TabStop = False
			AddressOf Me.Timer1.Enabled = True
			AddressOf Me.Timer1.Interval = 1000
			Dim autoScaleDimensions As SizeF = New SizeF(6F, 13F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			size = New Size(314, 315)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.PictureBox1)
			Me.FormBorderStyle = FormBorderStyle.None
			Me.Name = "Start"
			Me.ShowInTaskbar = False
			Me.StartPosition = FormStartPosition.CenterScreen
			Me.Text = "Form3"
			Me.TransparencyKey = Color.Black
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).EndInit()
			Me.ResumeLayout(False)
		End Sub

		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf AddressOf MySettingsProperty.Settings.Startdesign, "2", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Black_Loader.Show()
				Me.Close()
			Else
				AddressOf AddressOf MyProject.Forms.Form1.Show()
				Me.Close()
			End If
		End Sub
	End Class
End Namespace
