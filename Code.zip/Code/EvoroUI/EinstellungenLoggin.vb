Imports EvoroUI.My
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class EinstellungenLoggin
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("TextBox1")>
		Private _TextBox1 As TextBox

		<AccessedThroughProperty("TextBox2")>
		Private _TextBox2 As TextBox

		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		<AccessedThroughProperty("RadioButton1")>
		Private _RadioButton1 As RadioButton

		<AccessedThroughProperty("RadioButton2")>
		Private _RadioButton2 As RadioButton

		<AccessedThroughProperty("Button2")>
		Private _Button2 As Button

		<AccessedThroughProperty("Button3")>
		Private _Button3 As Button

		<AccessedThroughProperty("TextBox3")>
		Private _TextBox3 As TextBox

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button1_Click
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.Click, value2
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property TextBox1() As TextBox
			Get
				Return Me._TextBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox1 = value
			End Set
		End Property

		Friend Overridable Property TextBox2() As TextBox
			Get
				Return Me._TextBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox2 = value
			End Set
		End Property

		Friend Overridable Property Label1() As Label
			Get
				Return Me._Label1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		Friend Overridable Property Label2() As Label
			Get
				Return Me._Label2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		Friend Overridable Property RadioButton1() As RadioButton
			Get
				Return Me._RadioButton1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Dim value2 As EventHandler = AddressOf Me.RadioButton1_CheckedChanged
				If Me._RadioButton1 IsNot Nothing Then
					RemoveHandler Me._RadioButton1.CheckedChanged, value2
				End If
				Me._RadioButton1 = value
				If Me._RadioButton1 IsNot Nothing Then
					AddHandler Me._RadioButton1.CheckedChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property RadioButton2() As RadioButton
			Get
				Return Me._RadioButton2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Dim value2 As EventHandler = AddressOf Me.RadioButton2_CheckedChanged
				If Me._RadioButton2 IsNot Nothing Then
					RemoveHandler Me._RadioButton2.CheckedChanged, value2
				End If
				Me._RadioButton2 = value
				If Me._RadioButton2 IsNot Nothing Then
					AddHandler Me._RadioButton2.CheckedChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button2() As Button
			Get
				Return Me._Button2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button2_Click
				If Me._Button2 IsNot Nothing Then
					RemoveHandler Me._Button2.Click, value2
				End If
				Me._Button2 = value
				If Me._Button2 IsNot Nothing Then
					AddHandler Me._Button2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button3() As Button
			Get
				Return Me._Button3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button3_Click
				If Me._Button3 IsNot Nothing Then
					RemoveHandler Me._Button3.Click, value2
				End If
				Me._Button3 = value
				If Me._Button3 IsNot Nothing Then
					AddHandler Me._Button3.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property TextBox3() As TextBox
			Get
				Return Me._TextBox3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox3 = value
			End Set
		End Property

		Public Sub New()
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			AddressOf Me.Button1 = New Button()
			AddressOf Me.TextBox1 = New TextBox()
			AddressOf Me.TextBox2 = New TextBox()
			AddressOf Me.Label1 = New Label()
			AddressOf Me.Label2 = New Label()
			AddressOf Me.RadioButton1 = New RadioButton()
			AddressOf Me.RadioButton2 = New RadioButton()
			AddressOf Me.Button2 = New Button()
			AddressOf Me.Button3 = New Button()
			AddressOf Me.TextBox3 = New TextBox()
			Me.SuspendLayout()
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			Dim arg_98_0 As Control = AddressOf Me.Button1
			Dim location As Point = New Point(926, 384)
			arg_98_0.Location = location
			Dim arg_AF_0 As Control = AddressOf Me.Button1
			Dim size As Size = New Size(62, 62)
			arg_AF_0.MaximumSize = size
			Dim arg_C6_0 As Control = AddressOf Me.Button1
			size = New Size(62, 62)
			arg_C6_0.MinimumSize = size
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_ED_0 As Control = AddressOf Me.Button1
			size = New Size(62, 62)
			arg_ED_0.Size = size
			AddressOf Me.Button1.TabIndex = 0
			AddressOf Me.Button1.Text = "Save"
			AddressOf Me.Button1.UseVisualStyleBackColor = True
			AddressOf Me.TextBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.TextBox1.BackColor = Color.Black
			AddressOf Me.TextBox1.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.TextBox1.Font = New Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.TextBox1.ForeColor = Color.White
			Dim arg_188_0 As Control = AddressOf Me.TextBox1
			location = New Point(994, 384)
			arg_188_0.Location = location
			Dim arg_1A0_0 As Control = AddressOf Me.TextBox1
			Dim margin As Padding = New Padding(3, 4, 3, 4)
			arg_1A0_0.Margin = margin
			Dim arg_1BA_0 As Control = AddressOf Me.TextBox1
			size = New Size(197, 27)
			arg_1BA_0.MaximumSize = size
			Dim arg_1D4_0 As Control = AddressOf Me.TextBox1
			size = New Size(197, 27)
			arg_1D4_0.MinimumSize = size
			AddressOf Me.TextBox1.Name = "TextBox1"
			Dim arg_1FE_0 As Control = AddressOf Me.TextBox1
			size = New Size(197, 27)
			arg_1FE_0.Size = size
			AddressOf Me.TextBox1.TabIndex = 3
			AddressOf Me.TextBox1.Text = "Username"
			AddressOf Me.TextBox2.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.TextBox2.BackColor = Color.Black
			AddressOf Me.TextBox2.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.TextBox2.Font = New Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.TextBox2.ForeColor = Color.White
			Dim arg_28D_0 As Control = AddressOf Me.TextBox2
			location = New Point(994, 419)
			arg_28D_0.Location = location
			Dim arg_2A5_0 As Control = AddressOf Me.TextBox2
			margin = New Padding(3, 4, 3, 4)
			arg_2A5_0.Margin = margin
			Dim arg_2BC_0 As Control = AddressOf Me.TextBox2
			size = New Size(100, 27)
			arg_2BC_0.MaximumSize = size
			Dim arg_2D3_0 As Control = AddressOf Me.TextBox2
			size = New Size(100, 27)
			arg_2D3_0.MinimumSize = size
			AddressOf Me.TextBox2.Name = "TextBox2"
			Dim arg_2FA_0 As Control = AddressOf Me.TextBox2
			size = New Size(100, 27)
			arg_2FA_0.Size = size
			AddressOf Me.TextBox2.TabIndex = 4
			AddressOf Me.TextBox2.Text = "Password"
			AddressOf Me.Label1.AutoSize = True
			AddressOf Me.Label1.Font = New Font("Century Gothic", 12F, FontStyle.Underline, GraphicsUnit.Point, 0)
			Dim arg_35C_0 As Control = AddressOf Me.Label1
			location = New Point(922, 359)
			arg_35C_0.Location = location
			AddressOf Me.Label1.Name = "Label1"
			Dim arg_386_0 As Control = AddressOf Me.Label1
			size = New Size(269, 21)
			arg_386_0.Size = size
			AddressOf Me.Label1.TabIndex = 5
			AddressOf Me.Label1.Text = "Change Username and Password"
			AddressOf Me.Label2.AutoSize = True
			AddressOf Me.Label2.Font = New Font("Century Gothic", 12F, FontStyle.Underline, GraphicsUnit.Point, 0)
			Dim arg_3E8_0 As Control = AddressOf Me.Label2
			location = New Point(922, 450)
			arg_3E8_0.Location = location
			AddressOf Me.Label2.Name = "Label2"
			Dim arg_412_0 As Control = AddressOf Me.Label2
			size = New Size(187, 21)
			arg_412_0.Size = size
			AddressOf Me.Label2.TabIndex = 6
			AddressOf Me.Label2.Text = "Change Loggin Design"
			AddressOf Me.RadioButton1.AutoSize = True
			AddressOf Me.RadioButton1.BackColor = Color.Black
			AddressOf Me.RadioButton1.FlatStyle = FlatStyle.Flat
			Dim arg_473_0 As Control = AddressOf Me.RadioButton1
			location = New Point(1090, 511)
			arg_473_0.Location = location
			AddressOf Me.RadioButton1.Name = "RadioButton1"
			Dim arg_49A_0 As Control = AddressOf Me.RadioButton1
			size = New Size(101, 25)
			arg_49A_0.Size = size
			AddressOf Me.RadioButton1.TabIndex = 7
			AddressOf Me.RadioButton1.Text = "Standard"
			AddressOf Me.RadioButton1.UseVisualStyleBackColor = False
			AddressOf Me.RadioButton2.AutoSize = True
			AddressOf Me.RadioButton2.BackColor = Color.Black
			AddressOf Me.RadioButton2.Checked = True
			AddressOf Me.RadioButton2.FlatStyle = FlatStyle.Flat
			Dim arg_513_0 As Control = AddressOf Me.RadioButton2
			location = New Point(1103, 474)
			arg_513_0.Location = location
			AddressOf Me.RadioButton2.Name = "RadioButton2"
			Dim arg_53A_0 As Control = AddressOf Me.RadioButton2
			size = New Size(88, 25)
			arg_53A_0.Size = size
			AddressOf Me.RadioButton2.TabIndex = 8
			AddressOf Me.RadioButton2.TabStop = True
			AddressOf Me.RadioButton2.Text = "Black UI"
			AddressOf Me.RadioButton2.UseVisualStyleBackColor = False
			AddressOf Me.Button2.FlatStyle = FlatStyle.Flat
			Dim arg_597_0 As Control = AddressOf Me.Button2
			location = New Point(926, 474)
			arg_597_0.Location = location
			Dim arg_5AE_0 As Control = AddressOf Me.Button2
			size = New Size(62, 62)
			arg_5AE_0.MaximumSize = size
			Dim arg_5C5_0 As Control = AddressOf Me.Button2
			size = New Size(62, 62)
			arg_5C5_0.MinimumSize = size
			AddressOf Me.Button2.Name = "Button2"
			Dim arg_5EC_0 As Control = AddressOf Me.Button2
			size = New Size(62, 62)
			arg_5EC_0.Size = size
			AddressOf Me.Button2.TabIndex = 9
			AddressOf Me.Button2.Text = "Save"
			AddressOf Me.Button2.UseVisualStyleBackColor = True
			AddressOf Me.Button3.FlatStyle = FlatStyle.Flat
			Dim arg_63E_0 As Control = AddressOf Me.Button3
			location = New Point(926, 542)
			arg_63E_0.Location = location
			Dim arg_658_0 As Control = AddressOf Me.Button3
			size = New Size(265, 32)
			arg_658_0.MaximumSize = size
			Dim arg_672_0 As Control = AddressOf Me.Button3
			size = New Size(265, 32)
			arg_672_0.MinimumSize = size
			AddressOf Me.Button3.Name = "Button3"
			Dim arg_69C_0 As Control = AddressOf Me.Button3
			size = New Size(265, 32)
			arg_69C_0.Size = size
			AddressOf Me.Button3.TabIndex = 10
			AddressOf Me.Button3.Text = "OK"
			AddressOf Me.Button3.UseVisualStyleBackColor = True
			AddressOf Me.TextBox3.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.TextBox3.BackColor = Color.Black
			AddressOf Me.TextBox3.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.TextBox3.Font = New Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.TextBox3.ForeColor = Color.White
			Dim arg_738_0 As Control = AddressOf Me.TextBox3
			location = New Point(1093, 419)
			arg_738_0.Location = location
			Dim arg_750_0 As Control = AddressOf Me.TextBox3
			margin = New Padding(3, 4, 3, 4)
			arg_750_0.Margin = margin
			Dim arg_767_0 As Control = AddressOf Me.TextBox3
			size = New Size(100, 27)
			arg_767_0.MaximumSize = size
			Dim arg_77E_0 As Control = AddressOf Me.TextBox3
			size = New Size(100, 27)
			arg_77E_0.MinimumSize = size
			AddressOf Me.TextBox3.Name = "TextBox3"
			Dim arg_7A5_0 As Control = AddressOf Me.TextBox3
			size = New Size(100, 27)
			arg_7A5_0.Size = size
			AddressOf Me.TextBox3.TabIndex = 11
			AddressOf Me.TextBox3.Text = "Password"
			Dim autoScaleDimensions As SizeF = New SizeF(10F, 21F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			size = New Size(1763, 838)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.TextBox3)
			Me.Controls.Add(AddressOf Me.Button3)
			Me.Controls.Add(AddressOf Me.Button2)
			Me.Controls.Add(AddressOf Me.RadioButton2)
			Me.Controls.Add(AddressOf Me.RadioButton1)
			Me.Controls.Add(AddressOf Me.Label2)
			Me.Controls.Add(AddressOf Me.Label1)
			Me.Controls.Add(AddressOf Me.TextBox2)
			Me.Controls.Add(AddressOf Me.TextBox1)
			Me.Controls.Add(AddressOf Me.Button1)
			Me.Font = New Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Me.ForeColor = Color.White
			Me.FormBorderStyle = FormBorderStyle.None
			margin = New Padding(5)
			Me.Margin = margin
			Me.Name = "EinstellungenLoggin"
			Me.Text = "Einstellungen"
			Me.WindowState = FormWindowState.Maximized
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.TextBox2.Text, "End", False) = 0 Then
				Interaction.MsgBox("'End' is not Enabled", MsgBoxStyle.Critical, Nothing)
			Else
				AddressOf AddressOf MySettingsProperty.Settings.Username = AddressOf Me.TextBox1.Text
				AddressOf AddressOf MySettingsProperty.Settings.Passwort = AddressOf Me.TextBox2.Text
			End If
		End Sub

		Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs)
		End Sub

		Private Sub Button2_Click(sender As Object, e As EventArgs)
			If AddressOf Me.RadioButton1.Checked Then
				AddressOf AddressOf MySettingsProperty.Settings.Startdesign = Conversions.ToString(1)
			Else
				If AddressOf Me.RadioButton2.Checked Then
					AddressOf AddressOf MySettingsProperty.Settings.Startdesign = Conversions.ToString(2)
				Else
					AddressOf AddressOf MySettingsProperty.Settings.Startdesign = Conversions.ToString(2)
				End If
			End If
		End Sub

		Private Sub Button3_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub

		Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs)
		End Sub
	End Class
End Namespace
