Imports EvoroUI.My
Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Texteditor
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("ToolStrip1")>
		Private _ToolStrip1 As ToolStrip

		<AccessedThroughProperty("ToolStripButton1")>
		Private _ToolStripButton1 As ToolStripButton

		<AccessedThroughProperty("ToolStripButton2")>
		Private _ToolStripButton2 As ToolStripButton

		<AccessedThroughProperty("ToolStripButton3")>
		Private _ToolStripButton3 As ToolStripButton

		<AccessedThroughProperty("ToolStripSeparator1")>
		Private _ToolStripSeparator1 As ToolStripSeparator

		<AccessedThroughProperty("ToolStripButton4")>
		Private _ToolStripButton4 As ToolStripButton

		<AccessedThroughProperty("ToolStripButton5")>
		Private _ToolStripButton5 As ToolStripButton

		<AccessedThroughProperty("ToolStripButton6")>
		Private _ToolStripButton6 As ToolStripButton

		<AccessedThroughProperty("RichTextBox1")>
		Private _RichTextBox1 As RichTextBox

		<AccessedThroughProperty("ColorDialog1")>
		Private _ColorDialog1 As ColorDialog

		<AccessedThroughProperty("ColorDialog2")>
		Private _ColorDialog2 As ColorDialog

		<AccessedThroughProperty("FontDialog1")>
		Private _FontDialog1 As FontDialog

		<AccessedThroughProperty("OpenFileDialog1")>
		Private _OpenFileDialog1 As OpenFileDialog

		<AccessedThroughProperty("SaveFileDialog1")>
		Private _SaveFileDialog1 As SaveFileDialog

		Friend Overridable Property ToolStrip1() As ToolStrip
			Get
				Return Me._ToolStrip1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStrip)
				Me._ToolStrip1 = value
			End Set
		End Property

		Friend Overridable Property ToolStripButton1() As ToolStripButton
			Get
				Return Me._ToolStripButton1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton1_Click
				If Me._ToolStripButton1 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton1.Click, value2
				End If
				Me._ToolStripButton1 = value
				If Me._ToolStripButton1 IsNot Nothing Then
					AddHandler Me._ToolStripButton1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton2() As ToolStripButton
			Get
				Return Me._ToolStripButton2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton2_Click
				If Me._ToolStripButton2 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton2.Click, value2
				End If
				Me._ToolStripButton2 = value
				If Me._ToolStripButton2 IsNot Nothing Then
					AddHandler Me._ToolStripButton2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton3() As ToolStripButton
			Get
				Return Me._ToolStripButton3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton3_Click
				If Me._ToolStripButton3 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton3.Click, value2
				End If
				Me._ToolStripButton3 = value
				If Me._ToolStripButton3 IsNot Nothing Then
					AddHandler Me._ToolStripButton3.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripSeparator1() As ToolStripSeparator
			Get
				Return Me._ToolStripSeparator1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripSeparator)
				Me._ToolStripSeparator1 = value
			End Set
		End Property

		Friend Overridable Property ToolStripButton4() As ToolStripButton
			Get
				Return Me._ToolStripButton4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton4_Click
				If Me._ToolStripButton4 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton4.Click, value2
				End If
				Me._ToolStripButton4 = value
				If Me._ToolStripButton4 IsNot Nothing Then
					AddHandler Me._ToolStripButton4.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton5() As ToolStripButton
			Get
				Return Me._ToolStripButton5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton5_Click
				If Me._ToolStripButton5 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton5.Click, value2
				End If
				Me._ToolStripButton5 = value
				If Me._ToolStripButton5 IsNot Nothing Then
					AddHandler Me._ToolStripButton5.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton6() As ToolStripButton
			Get
				Return Me._ToolStripButton6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton6_Click
				If Me._ToolStripButton6 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton6.Click, value2
				End If
				Me._ToolStripButton6 = value
				If Me._ToolStripButton6 IsNot Nothing Then
					AddHandler Me._ToolStripButton6.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property RichTextBox1() As RichTextBox
			Get
				Return Me._RichTextBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RichTextBox)
				Dim value2 As EventHandler = AddressOf Me.RichTextBox1_TextChanged
				If Me._RichTextBox1 IsNot Nothing Then
					RemoveHandler Me._RichTextBox1.TextChanged, value2
				End If
				Me._RichTextBox1 = value
				If Me._RichTextBox1 IsNot Nothing Then
					AddHandler Me._RichTextBox1.TextChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property ColorDialog1() As ColorDialog
			Get
				Return Me._ColorDialog1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ColorDialog)
				Me._ColorDialog1 = value
			End Set
		End Property

		Friend Overridable Property ColorDialog2() As ColorDialog
			Get
				Return Me._ColorDialog2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ColorDialog)
				Me._ColorDialog2 = value
			End Set
		End Property

		Friend Overridable Property FontDialog1() As FontDialog
			Get
				Return Me._FontDialog1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As FontDialog)
				Me._FontDialog1 = value
			End Set
		End Property

		Friend Overridable Property OpenFileDialog1() As OpenFileDialog
			Get
				Return Me._OpenFileDialog1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As OpenFileDialog)
				Dim value2 As CancelEventHandler = AddressOf Me.OpenFileDialog1_FileOk
				If Me._OpenFileDialog1 IsNot Nothing Then
					RemoveHandler Me._OpenFileDialog1.FileOk, value2
				End If
				Me._OpenFileDialog1 = value
				If Me._OpenFileDialog1 IsNot Nothing Then
					AddHandler Me._OpenFileDialog1.FileOk, value2
				End If
			End Set
		End Property

		Friend Overridable Property SaveFileDialog1() As SaveFileDialog
			Get
				Return Me._SaveFileDialog1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As SaveFileDialog)
				Me._SaveFileDialog1 = value
			End Set
		End Property

		Public Sub New()
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim resources As ComponentResourceManager = New ComponentResourceManager(GetType(Texteditor))
			AddressOf Me.RichTextBox1 = New RichTextBox()
			AddressOf Me.ToolStrip1 = New ToolStrip()
			AddressOf Me.ToolStripButton1 = New ToolStripButton()
			AddressOf Me.ToolStripButton2 = New ToolStripButton()
			AddressOf Me.ToolStripButton3 = New ToolStripButton()
			AddressOf Me.ToolStripSeparator1 = New ToolStripSeparator()
			AddressOf Me.ToolStripButton4 = New ToolStripButton()
			AddressOf Me.ToolStripButton5 = New ToolStripButton()
			AddressOf Me.ToolStripButton6 = New ToolStripButton()
			AddressOf Me.ColorDialog1 = New ColorDialog()
			AddressOf Me.ColorDialog2 = New ColorDialog()
			AddressOf Me.FontDialog1 = New FontDialog()
			AddressOf Me.OpenFileDialog1 = New OpenFileDialog()
			AddressOf Me.SaveFileDialog1 = New SaveFileDialog()
			AddressOf Me.ToolStrip1.SuspendLayout()
			Me.SuspendLayout()
			AddressOf Me.RichTextBox1.Dock = DockStyle.Fill
			Dim arg_D8_0 As Control = AddressOf Me.RichTextBox1
			Dim location As Point = New Point(0, 25)
			arg_D8_0.Location = location
			AddressOf Me.RichTextBox1.Name = "RichTextBox1"
			Dim arg_106_0 As Control = AddressOf Me.RichTextBox1
			Dim size As Size = New Size(1180, 602)
			arg_106_0.Size = size
			AddressOf Me.RichTextBox1.TabIndex = 3
			AddressOf Me.RichTextBox1.Text = ""
			AddressOf Me.ToolStrip1.BackgroundImage = AddressOf Resources.VerlaufGrau
			AddressOf Me.ToolStrip1.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.ToolStrip1.Items.AddRange(New ToolStripItem()() { AddressOf Me.ToolStripButton1, AddressOf Me.ToolStripButton2, AddressOf Me.ToolStripButton3, AddressOf Me.ToolStripSeparator1, AddressOf Me.ToolStripButton4, AddressOf Me.ToolStripButton5, AddressOf Me.ToolStripButton6 })
			Dim arg_1B3_0 As Control = AddressOf Me.ToolStrip1
			location = New Point(0, 0)
			arg_1B3_0.Location = location
			AddressOf Me.ToolStrip1.Name = "ToolStrip1"
			Dim arg_1DE_0 As Control = AddressOf Me.ToolStrip1
			size = New Size(1180, 25)
			arg_1DE_0.Size = size
			AddressOf Me.ToolStrip1.TabIndex = 2
			AddressOf Me.ToolStrip1.Text = "ToolStrip1"
			AddressOf Me.ToolStripButton1.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), Image)
			AddressOf Me.ToolStripButton1.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton1.Name = "ToolStripButton1"
			Dim arg_259_0 As ToolStripItem = AddressOf Me.ToolStripButton1
			size = New Size(23, 22)
			arg_259_0.Size = size
			AddressOf Me.ToolStripButton1.Text = "Öffnen"
			AddressOf Me.ToolStripButton2.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), Image)
			AddressOf Me.ToolStripButton2.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton2.Name = "ToolStripButton2"
			Dim arg_2C8_0 As ToolStripItem = AddressOf Me.ToolStripButton2
			size = New Size(23, 22)
			arg_2C8_0.Size = size
			AddressOf Me.ToolStripButton2.Text = "Speichern"
			AddressOf Me.ToolStripButton3.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton3.Image = CType(resources.GetObject("ToolStripButton3.Image"), Image)
			AddressOf Me.ToolStripButton3.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton3.Name = "ToolStripButton3"
			Dim arg_337_0 As ToolStripItem = AddressOf Me.ToolStripButton3
			size = New Size(23, 22)
			arg_337_0.Size = size
			AddressOf Me.ToolStripButton3.Text = "Neu"
			AddressOf Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
			Dim arg_36E_0 As ToolStripItem = AddressOf Me.ToolStripSeparator1
			size = New Size(6, 25)
			arg_36E_0.Size = size
			AddressOf Me.ToolStripButton4.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), Image)
			AddressOf Me.ToolStripButton4.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton4.Name = "ToolStripButton4"
			Dim arg_3CD_0 As ToolStripItem = AddressOf Me.ToolStripButton4
			size = New Size(23, 22)
			arg_3CD_0.Size = size
			AddressOf Me.ToolStripButton4.Text = "Schriftstil"
			AddressOf Me.ToolStripButton5.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton5.Image = CType(resources.GetObject("ToolStripButton5.Image"), Image)
			AddressOf Me.ToolStripButton5.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton5.Name = "ToolStripButton5"
			Dim arg_43C_0 As ToolStripItem = AddressOf Me.ToolStripButton5
			size = New Size(23, 22)
			arg_43C_0.Size = size
			AddressOf Me.ToolStripButton5.Text = "Schriftfarbe"
			AddressOf Me.ToolStripButton6.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton6.Image = CType(resources.GetObject("ToolStripButton6.Image"), Image)
			AddressOf Me.ToolStripButton6.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton6.Name = "ToolStripButton6"
			Dim arg_4AB_0 As ToolStripItem = AddressOf Me.ToolStripButton6
			size = New Size(23, 22)
			arg_4AB_0.Size = size
			AddressOf Me.ToolStripButton6.Text = "Hintergrundfarbe"
			AddressOf Me.OpenFileDialog1.FileName = "Dateiname"
			AddressOf Me.OpenFileDialog1.Filter = "Alle Dateien|*.*"
			AddressOf Me.SaveFileDialog1.FileName = "Neue Textdatei"
			AddressOf Me.SaveFileDialog1.Filter = "Alle Dateien|*.*"
			Dim autoScaleDimensions As SizeF = New SizeF(6F, 13F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			size = New Size(1180, 627)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.RichTextBox1)
			Me.Controls.Add(AddressOf Me.ToolStrip1)
			Me.FormBorderStyle = FormBorderStyle.SizableToolWindow
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "Texteditor"
			Me.Text = "Texter Evoro"
			AddressOf Me.ToolStrip1.ResumeLayout(False)
			AddressOf Me.ToolStrip1.PerformLayout()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs)
		End Sub

		Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs)
			AddressOf Me.RichTextBox1.Clear()
		End Sub

		Private Sub ToolStripButton4_Click(sender As Object, e As EventArgs)
			AddressOf Me.FontDialog1.ShowDialog()
			AddressOf Me.RichTextBox1.Font = AddressOf Me.FontDialog1.Font
		End Sub

		Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs)
			Try
				Dim savefile As SaveFileDialog = New SaveFileDialog()
				savefile.ShowDialog()
				AddressOf MyProject.Computer.FileSystem.WriteAllText(savefile.FileName, AddressOf Me.RichTextBox1.Text, True)
			Catch expr_30 As Exception
				ProjectData.SetProjectError(expr_30)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs)
			Try
				AddressOf Me.OpenFileDialog1.ShowDialog()
				Dim text As String = File.ReadAllText(AddressOf Me.OpenFileDialog1.FileName)
				AddressOf Me.RichTextBox1.Text = text
			Catch expr_2B As Exception
				ProjectData.SetProjectError(expr_2B)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub OpenFileDialog1_FileOk(sender As Object, e As CancelEventArgs)
		End Sub

		Private Sub ToolStripButton5_Click(sender As Object, e As EventArgs)
			AddressOf Me.ColorDialog1.ShowDialog()
			AddressOf Me.RichTextBox1.ForeColor = AddressOf Me.ColorDialog1.Color
		End Sub

		Private Sub ToolStripButton6_Click(sender As Object, e As EventArgs)
			AddressOf Me.ColorDialog1.ShowDialog()
			AddressOf Me.RichTextBox1.BackColor = AddressOf Me.ColorDialog1.Color
		End Sub
	End Class
End Namespace
