Imports AxWMPLib
Imports EvoroUI.My
Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports WMPLib

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Form2
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("OpenFileDialog1")>
		Private _OpenFileDialog1 As OpenFileDialog

		<AccessedThroughProperty("SplitContainer1")>
		Private _SplitContainer1 As SplitContainer

		<AccessedThroughProperty("ListBox1")>
		Private _ListBox1 As ListBox

		<AccessedThroughProperty("AxWindowsMediaPlayer1")>
		Private _AxWindowsMediaPlayer1 As AxWindowsMediaPlayer

		<AccessedThroughProperty("Button4")>
		Private _Button4 As Button

		<AccessedThroughProperty("Button3")>
		Private _Button3 As Button

		<AccessedThroughProperty("Button2")>
		Private _Button2 As Button

		<AccessedThroughProperty("TextBox1")>
		Private _TextBox1 As TextBox

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("FolderBrowserDialog1")>
		Private _FolderBrowserDialog1 As FolderBrowserDialog

		<AccessedThroughProperty("TrackBar1")>
		Private _TrackBar1 As TrackBar

		<AccessedThroughProperty("Button6")>
		Private _Button6 As Button

		<AccessedThroughProperty("Button5")>
		Private _Button5 As Button

		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		<AccessedThroughProperty("Timer2")>
		Private _Timer2 As Timer

		<AccessedThroughProperty("Button10")>
		Private _Button10 As Button

		<AccessedThroughProperty("Button9")>
		Private _Button9 As Button

		<AccessedThroughProperty("Button8")>
		Private _Button8 As Button

		<AccessedThroughProperty("Button7")>
		Private _Button7 As Button

		<AccessedThroughProperty("Timer3")>
		Private _Timer3 As Timer

		<AccessedThroughProperty("Timer4")>
		Private _Timer4 As Timer

		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		<AccessedThroughProperty("PictureBox1")>
		Private _PictureBox1 As PictureBox

		Friend Overridable Property OpenFileDialog1() As OpenFileDialog
			Get
				Return Me._OpenFileDialog1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As OpenFileDialog)
				Me._OpenFileDialog1 = value
			End Set
		End Property

		Friend Overridable Property SplitContainer1() As SplitContainer
			Get
				Return Me._SplitContainer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As SplitContainer)
				Me._SplitContainer1 = value
			End Set
		End Property

		Friend Overridable Property ListBox1() As ListBox
			Get
				Return Me._ListBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Dim value2 As EventHandler = AddressOf Me.ListBox1_SelectedIndexChanged
				If Me._ListBox1 IsNot Nothing Then
					RemoveHandler Me._ListBox1.SelectedIndexChanged, value2
				End If
				Me._ListBox1 = value
				If Me._ListBox1 IsNot Nothing Then
					AddHandler Me._ListBox1.SelectedIndexChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property AxWindowsMediaPlayer1() As AxWindowsMediaPlayer
			Get
				Return Me._AxWindowsMediaPlayer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As AxWindowsMediaPlayer)
				Me._AxWindowsMediaPlayer1 = value
			End Set
		End Property

		Friend Overridable Property Button4() As Button
			Get
				Return Me._Button4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button4_Click
				If Me._Button4 IsNot Nothing Then
					RemoveHandler Me._Button4.Click, value2
				End If
				Me._Button4 = value
				If Me._Button4 IsNot Nothing Then
					AddHandler Me._Button4.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button3() As Button
			Get
				Return Me._Button3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button3 = value
			End Set
		End Property

		Friend Overridable Property Button2() As Button
			Get
				Return Me._Button2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button2_Click_1
				If Me._Button2 IsNot Nothing Then
					RemoveHandler Me._Button2.Click, value2
				End If
				Me._Button2 = value
				If Me._Button2 IsNot Nothing Then
					AddHandler Me._Button2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property TextBox1() As TextBox
			Get
				Return Me._TextBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox1 = value
			End Set
		End Property

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button1_Click_1
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.Click, value2
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property FolderBrowserDialog1() As FolderBrowserDialog
			Get
				Return Me._FolderBrowserDialog1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As FolderBrowserDialog)
				Me._FolderBrowserDialog1 = value
			End Set
		End Property

		Friend Overridable Property TrackBar1() As TrackBar
			Get
				Return Me._TrackBar1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TrackBar)
				Dim value2 As EventHandler = AddressOf Me.TrackBar1_Scroll
				If Me._TrackBar1 IsNot Nothing Then
					RemoveHandler Me._TrackBar1.Scroll, value2
				End If
				Me._TrackBar1 = value
				If Me._TrackBar1 IsNot Nothing Then
					AddHandler Me._TrackBar1.Scroll, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button6() As Button
			Get
				Return Me._Button6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button6_Click
				If Me._Button6 IsNot Nothing Then
					RemoveHandler Me._Button6.Click, value2
				End If
				Me._Button6 = value
				If Me._Button6 IsNot Nothing Then
					AddHandler Me._Button6.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button5() As Button
			Get
				Return Me._Button5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button5_Click
				If Me._Button5 IsNot Nothing Then
					RemoveHandler Me._Button5.Click, value2
				End If
				Me._Button5 = value
				If Me._Button5 IsNot Nothing Then
					AddHandler Me._Button5.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Timer1() As Timer
			Get
				Return Me._Timer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer1_Tick
				If Me._Timer1 IsNot Nothing Then
					RemoveHandler Me._Timer1.Tick, value2
				End If
				Me._Timer1 = value
				If Me._Timer1 IsNot Nothing Then
					AddHandler Me._Timer1.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Timer2() As Timer
			Get
				Return Me._Timer2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer2_Tick
				If Me._Timer2 IsNot Nothing Then
					RemoveHandler Me._Timer2.Tick, value2
				End If
				Me._Timer2 = value
				If Me._Timer2 IsNot Nothing Then
					AddHandler Me._Timer2.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button10() As Button
			Get
				Return Me._Button10
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button10_Click
				If Me._Button10 IsNot Nothing Then
					RemoveHandler Me._Button10.Click, value2
				End If
				Me._Button10 = value
				If Me._Button10 IsNot Nothing Then
					AddHandler Me._Button10.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button9() As Button
			Get
				Return Me._Button9
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button9_Click
				If Me._Button9 IsNot Nothing Then
					RemoveHandler Me._Button9.Click, value2
				End If
				Me._Button9 = value
				If Me._Button9 IsNot Nothing Then
					AddHandler Me._Button9.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button8() As Button
			Get
				Return Me._Button8
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button8_Click
				If Me._Button8 IsNot Nothing Then
					RemoveHandler Me._Button8.Click, value2
				End If
				Me._Button8 = value
				If Me._Button8 IsNot Nothing Then
					AddHandler Me._Button8.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button7() As Button
			Get
				Return Me._Button7
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button7_Click
				If Me._Button7 IsNot Nothing Then
					RemoveHandler Me._Button7.Click, value2
				End If
				Me._Button7 = value
				If Me._Button7 IsNot Nothing Then
					AddHandler Me._Button7.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Timer3() As Timer
			Get
				Return Me._Timer3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer3_Tick
				If Me._Timer3 IsNot Nothing Then
					RemoveHandler Me._Timer3.Tick, value2
				End If
				Me._Timer3 = value
				If Me._Timer3 IsNot Nothing Then
					AddHandler Me._Timer3.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Timer4() As Timer
			Get
				Return Me._Timer4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer4_Tick
				If Me._Timer4 IsNot Nothing Then
					RemoveHandler Me._Timer4.Tick, value2
				End If
				Me._Timer4 = value
				If Me._Timer4 IsNot Nothing Then
					AddHandler Me._Timer4.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Label2() As Label
			Get
				Return Me._Label2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		Friend Overridable Property Label1() As Label
			Get
				Return Me._Label1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		Friend Overridable Property PictureBox1() As PictureBox
			Get
				Return Me._PictureBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox1 = value
			End Set
		End Property

		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.Form2_Load
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Container()
			Dim resources As ComponentResourceManager = New ComponentResourceManager(GetType(Form2))
			AddressOf Me.OpenFileDialog1 = New OpenFileDialog()
			AddressOf Me.SplitContainer1 = New SplitContainer()
			AddressOf Me.Button4 = New Button()
			AddressOf Me.Button3 = New Button()
			AddressOf Me.Button2 = New Button()
			AddressOf Me.TextBox1 = New TextBox()
			AddressOf Me.ListBox1 = New ListBox()
			AddressOf Me.Button1 = New Button()
			AddressOf Me.Button6 = New Button()
			AddressOf Me.Label2 = New Label()
			AddressOf Me.Label1 = New Label()
			AddressOf Me.Button10 = New Button()
			AddressOf Me.Button9 = New Button()
			AddressOf Me.Button8 = New Button()
			AddressOf Me.Button7 = New Button()
			AddressOf Me.TrackBar1 = New TrackBar()
			AddressOf Me.Button5 = New Button()
			AddressOf Me.PictureBox1 = New PictureBox()
			AddressOf Me.AxWindowsMediaPlayer1 = New AxWindowsMediaPlayer()
			AddressOf Me.FolderBrowserDialog1 = New FolderBrowserDialog()
			AddressOf Me.Timer1 = New Timer(Me.components)
			AddressOf Me.Timer2 = New Timer(Me.components)
			AddressOf Me.Timer3 = New Timer(Me.components)
			AddressOf Me.Timer4 = New Timer(Me.components)
			(CType(AddressOf Me.SplitContainer1, ISupportInitialize)).BeginInit()
			AddressOf Me.SplitContainer1.Panel1.SuspendLayout()
			AddressOf Me.SplitContainer1.Panel2.SuspendLayout()
			AddressOf Me.SplitContainer1.SuspendLayout()
			(CType(AddressOf Me.TrackBar1, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.AxWindowsMediaPlayer1, ISupportInitialize)).BeginInit()
			Me.SuspendLayout()
			AddressOf Me.OpenFileDialog1.FileName = "OpenFileDialog1"
			AddressOf Me.SplitContainer1.Dock = DockStyle.Fill
			Dim arg_1C4_0 As Control = AddressOf Me.SplitContainer1
			Dim location As Point = New Point(0, 0)
			arg_1C4_0.Location = location
			Dim arg_1D9_0 As Control = AddressOf Me.SplitContainer1
			Dim margin As Padding = New Padding(2)
			arg_1D9_0.Margin = margin
			AddressOf Me.SplitContainer1.Name = "SplitContainer1"
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.Button4)
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.Button3)
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.Button2)
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.TextBox1)
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.ListBox1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button6)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Label2)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Label1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button10)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button9)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button8)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button7)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.TrackBar1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button5)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.PictureBox1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.AxWindowsMediaPlayer1)
			Dim arg_3D2_0 As Control = AddressOf Me.SplitContainer1
			Dim size As Size = New Size(872, 502)
			arg_3D2_0.Size = size
			AddressOf Me.SplitContainer1.SplitterDistance = 264
			AddressOf Me.SplitContainer1.SplitterWidth = 3
			AddressOf Me.SplitContainer1.TabIndex = 0
			AddressOf Me.Button4.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), Image)
			AddressOf Me.Button4.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button4.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button4.ForeColor = Color.White
			Dim arg_464_0 As Control = AddressOf Me.Button4
			location = New Point(87, 426)
			arg_464_0.Location = location
			Dim arg_479_0 As Control = AddressOf Me.Button4
			margin = New Padding(2)
			arg_479_0.Margin = margin
			AddressOf Me.Button4.Name = "Button4"
			Dim arg_4A1_0 As Control = AddressOf Me.Button4
			size = New Size(86, 76)
			arg_4A1_0.Size = size
			AddressOf Me.Button4.TabIndex = 5
			AddressOf Me.Button4.Text = "Laden"
			AddressOf Me.Button4.UseVisualStyleBackColor = True
			AddressOf Me.Button3.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), Image)
			AddressOf Me.Button3.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button3.Enabled = False
			AddressOf Me.Button3.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button3.ForeColor = Color.White
			Dim arg_53E_0 As Control = AddressOf Me.Button3
			location = New Point(2, 426)
			arg_53E_0.Location = location
			Dim arg_553_0 As Control = AddressOf Me.Button3
			margin = New Padding(2)
			arg_553_0.Margin = margin
			AddressOf Me.Button3.Name = "Button3"
			Dim arg_57B_0 As Control = AddressOf Me.Button3
			size = New Size(86, 76)
			arg_57B_0.Size = size
			AddressOf Me.Button3.TabIndex = 4
			AddressOf Me.Button3.Text = "Durchsuchen"
			AddressOf Me.Button3.UseVisualStyleBackColor = True
			AddressOf Me.Button2.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Button2.BackgroundImage = CType(resources.GetObject("Button2.BackgroundImage"), Image)
			AddressOf Me.Button2.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button2.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button2.ForeColor = Color.White
			Dim arg_610_0 As Control = AddressOf Me.Button2
			location = New Point(172, 426)
			arg_610_0.Location = location
			Dim arg_625_0 As Control = AddressOf Me.Button2
			margin = New Padding(2)
			arg_625_0.Margin = margin
			AddressOf Me.Button2.Name = "Button2"
			Dim arg_64D_0 As Control = AddressOf Me.Button2
			size = New Size(86, 58)
			arg_64D_0.Size = size
			AddressOf Me.Button2.TabIndex = 3
			AddressOf Me.Button2.Text = "Laden"
			AddressOf Me.Button2.UseVisualStyleBackColor = True
			AddressOf Me.TextBox1.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.TextBox1.BackColor = Color.Black
			AddressOf Me.TextBox1.ForeColor = Color.White
			Dim arg_6BF_0 As Control = AddressOf Me.TextBox1
			location = New Point(172, 482)
			arg_6BF_0.Location = location
			Dim arg_6D4_0 As Control = AddressOf Me.TextBox1
			margin = New Padding(2)
			arg_6D4_0.Margin = margin
			AddressOf Me.TextBox1.Name = "TextBox1"
			Dim arg_6FC_0 As Control = AddressOf Me.TextBox1
			size = New Size(86, 20)
			arg_6FC_0.Size = size
			AddressOf Me.TextBox1.TabIndex = 2
			AddressOf Me.ListBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.ListBox1.BackColor = Color.Black
			AddressOf Me.ListBox1.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.ListBox1.ForeColor = Color.White
			AddressOf Me.ListBox1.FormattingEnabled = True
			Dim arg_762_0 As Control = AddressOf Me.ListBox1
			location = New Point(0, 0)
			arg_762_0.Location = location
			Dim arg_777_0 As Control = AddressOf Me.ListBox1
			margin = New Padding(2)
			arg_777_0.Margin = margin
			AddressOf Me.ListBox1.Name = "ListBox1"
			Dim arg_7A5_0 As Control = AddressOf Me.ListBox1
			size = New Size(258, 431)
			arg_7A5_0.Size = size
			AddressOf Me.ListBox1.TabIndex = 0
			AddressOf Me.Button1.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), Image)
			AddressOf Me.Button1.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button1.ForeColor = Color.White
			Dim arg_819_0 As Control = AddressOf Me.Button1
			location = New Point(3, 426)
			arg_819_0.Location = location
			Dim arg_82E_0 As Control = AddressOf Me.Button1
			margin = New Padding(2)
			arg_82E_0.Margin = margin
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_856_0 As Control = AddressOf Me.Button1
			size = New Size(86, 76)
			arg_856_0.Size = size
			AddressOf Me.Button1.TabIndex = 1
			AddressOf Me.Button1.Text = ChrW(9658) & "  Play"
			AddressOf Me.Button1.UseVisualStyleBackColor = True
			AddressOf Me.Button6.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button6.BackgroundImage = CType(resources.GetObject("Button6.BackgroundImage"), Image)
			AddressOf Me.Button6.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button6.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button6.ForeColor = Color.White
			Dim arg_8EA_0 As Control = AddressOf Me.Button6
			location = New Point(173, 426)
			arg_8EA_0.Location = location
			Dim arg_8FF_0 As Control = AddressOf Me.Button6
			margin = New Padding(2)
			arg_8FF_0.Margin = margin
			AddressOf Me.Button6.Name = "Button6"
			Dim arg_927_0 As Control = AddressOf Me.Button6
			size = New Size(86, 76)
			arg_927_0.Size = size
			AddressOf Me.Button6.TabIndex = 3
			AddressOf Me.Button6.Text = ChrW(9632) & "  Stop"
			AddressOf Me.Button6.UseVisualStyleBackColor = True
			AddressOf Me.Label2.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Label2.AutoSize = True
			AddressOf Me.Label2.BackColor = Color.FromArgb(64, 64, 64)
			AddressOf Me.Label2.ForeColor = Color.White
			Dim arg_9AB_0 As Control = AddressOf Me.Label2
			location = New Point(425, 458)
			arg_9AB_0.Location = location
			AddressOf Me.Label2.Name = "Label2"
			Dim arg_9D3_0 As Control = AddressOf Me.Label2
			size = New Size(27, 13)
			arg_9D3_0.Size = size
			AddressOf Me.Label2.TabIndex = 10
			AddressOf Me.Label2.Text = "Title"
			AddressOf Me.Label1.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Label1.AutoSize = True
			AddressOf Me.Label1.BackColor = Color.FromArgb(64, 64, 64)
			AddressOf Me.Label1.ForeColor = Color.White
			Dim arg_A4B_0 As Control = AddressOf Me.Label1
			location = New Point(255, 458)
			arg_A4B_0.Location = location
			AddressOf Me.Label1.Name = "Label1"
			Dim arg_A73_0 As Control = AddressOf Me.Label1
			size = New Size(46, 13)
			arg_A73_0.Size = size
			AddressOf Me.Label1.TabIndex = 9
			AddressOf Me.Label1.Text = "Playtime"
			AddressOf Me.Button10.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button10.BackgroundImage = CType(resources.GetObject("Button10.BackgroundImage"), Image)
			AddressOf Me.Button10.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button10.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button10.ForeColor = Color.White
			Dim arg_AFC_0 As Control = AddressOf Me.Button10
			location = New Point(513, 475)
			arg_AFC_0.Location = location
			Dim arg_B11_0 As Control = AddressOf Me.Button10
			margin = New Padding(2)
			arg_B11_0.Margin = margin
			AddressOf Me.Button10.Name = "Button10"
			Dim arg_B39_0 As Control = AddressOf Me.Button10
			size = New Size(86, 27)
			arg_B39_0.Size = size
			AddressOf Me.Button10.TabIndex = 8
			AddressOf Me.Button10.Text = ChrW(9658) & "  Next"
			AddressOf Me.Button10.UseVisualStyleBackColor = True
			AddressOf Me.Button9.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button9.BackgroundImage = CType(resources.GetObject("Button9.BackgroundImage"), Image)
			AddressOf Me.Button9.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button9.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button9.ForeColor = Color.White
			Dim arg_BCD_0 As Control = AddressOf Me.Button9
			location = New Point(428, 475)
			arg_BCD_0.Location = location
			Dim arg_BE2_0 As Control = AddressOf Me.Button9
			margin = New Padding(2)
			arg_BE2_0.Margin = margin
			AddressOf Me.Button9.Name = "Button9"
			Dim arg_C0A_0 As Control = AddressOf Me.Button9
			size = New Size(86, 27)
			arg_C0A_0.Size = size
			AddressOf Me.Button9.TabIndex = 7
			AddressOf Me.Button9.Text = ChrW(9668) & "  Prevous"
			AddressOf Me.Button9.UseVisualStyleBackColor = True
			AddressOf Me.Button8.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button8.BackgroundImage = CType(resources.GetObject("Button8.BackgroundImage"), Image)
			AddressOf Me.Button8.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button8.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button8.ForeColor = Color.White
			Dim arg_C9E_0 As Control = AddressOf Me.Button8
			location = New Point(258, 475)
			arg_C9E_0.Location = location
			Dim arg_CB3_0 As Control = AddressOf Me.Button8
			margin = New Padding(2)
			arg_CB3_0.Margin = margin
			AddressOf Me.Button8.Name = "Button8"
			Dim arg_CDB_0 As Control = AddressOf Me.Button8
			size = New Size(86, 27)
			arg_CDB_0.Size = size
			AddressOf Me.Button8.TabIndex = 6
			AddressOf Me.Button8.Text = ChrW(9668) & ChrW(9668)
			AddressOf Me.Button8.UseVisualStyleBackColor = True
			AddressOf Me.Button7.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button7.BackgroundImage = CType(resources.GetObject("Button7.BackgroundImage"), Image)
			AddressOf Me.Button7.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button7.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button7.ForeColor = Color.White
			Dim arg_D6F_0 As Control = AddressOf Me.Button7
			location = New Point(343, 475)
			arg_D6F_0.Location = location
			Dim arg_D84_0 As Control = AddressOf Me.Button7
			margin = New Padding(2)
			arg_D84_0.Margin = margin
			AddressOf Me.Button7.Name = "Button7"
			Dim arg_DAC_0 As Control = AddressOf Me.Button7
			size = New Size(86, 27)
			arg_DAC_0.Size = size
			AddressOf Me.Button7.TabIndex = 5
			AddressOf Me.Button7.Text = ChrW(9658) & ChrW(9658)
			AddressOf Me.Button7.UseVisualStyleBackColor = True
			AddressOf Me.TrackBar1.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.TrackBar1.BackColor = Color.FromArgb(64, 64, 64)
			Dim arg_E14_0 As Control = AddressOf Me.TrackBar1
			location = New Point(258, 426)
			arg_E14_0.Location = location
			Dim arg_E29_0 As Control = AddressOf Me.TrackBar1
			margin = New Padding(2)
			arg_E29_0.Margin = margin
			AddressOf Me.TrackBar1.Maximum = 0
			AddressOf Me.TrackBar1.Name = "TrackBar1"
			Dim arg_E60_0 As Control = AddressOf Me.TrackBar1
			size = New Size(348, 45)
			arg_E60_0.Size = size
			AddressOf Me.TrackBar1.TabIndex = 4
			AddressOf Me.Button5.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"), Image)
			AddressOf Me.Button5.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Button5.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button5.ForeColor = Color.White
			Dim arg_ED5_0 As Control = AddressOf Me.Button5
			location = New Point(88, 426)
			arg_ED5_0.Location = location
			Dim arg_EEA_0 As Control = AddressOf Me.Button5
			margin = New Padding(2)
			arg_EEA_0.Margin = margin
			AddressOf Me.Button5.Name = "Button5"
			Dim arg_F12_0 As Control = AddressOf Me.Button5
			size = New Size(86, 76)
			arg_F12_0.Size = size
			AddressOf Me.Button5.TabIndex = 2
			AddressOf Me.Button5.Text = "||  Pause"
			AddressOf Me.Button5.UseVisualStyleBackColor = True
			AddressOf Me.PictureBox1.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.PictureBox1.BackgroundImage = AddressOf Resources.Farbverlauf2
			AddressOf Me.PictureBox1.BackgroundImageLayout = ImageLayout.Stretch
			Dim arg_F80_0 As Control = AddressOf Me.PictureBox1
			location = New Point(-265, 426)
			arg_F80_0.Location = location
			AddressOf Me.PictureBox1.Name = "PictureBox1"
			Dim arg_FAB_0 As Control = AddressOf Me.PictureBox1
			size = New Size(880, 76)
			arg_FAB_0.Size = size
			AddressOf Me.PictureBox1.TabIndex = 11
			AddressOf Me.PictureBox1.TabStop = False
			AddressOf Me.AxWindowsMediaPlayer1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.AxWindowsMediaPlayer1.Enabled = True
			Dim arg_FF2_0 As Control = AddressOf Me.AxWindowsMediaPlayer1
			location = New Point(3, 0)
			arg_FF2_0.Location = location
			Dim arg_1007_0 As Control = AddressOf Me.AxWindowsMediaPlayer1
			margin = New Padding(2)
			arg_1007_0.Margin = margin
			AddressOf Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
			AddressOf Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), AxHost.State)
			Dim arg_1050_0 As Control = AddressOf Me.AxWindowsMediaPlayer1
			size = New Size(603, 554)
			arg_1050_0.Size = size
			AddressOf Me.AxWindowsMediaPlayer1.TabIndex = 0
			AddressOf Me.Timer1.Enabled = True
			AddressOf Me.Timer1.Interval = 1
			AddressOf Me.Timer2.Interval = 10
			AddressOf Me.Timer4.Interval = 10
			Dim autoScaleDimensions As SizeF = New SizeF(6F, 13F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			size = New Size(872, 502)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.SplitContainer1)
			Me.DoubleBuffered = True
			Me.ForeColor = Color.White
			Me.FormBorderStyle = FormBorderStyle.SizableToolWindow
			size = New Size(880, 34)
			Me.MinimumSize = size
			Me.Name = "Form2"
			Me.Text = "EvoroPlayer"
			AddressOf Me.SplitContainer1.Panel1.ResumeLayout(False)
			AddressOf Me.SplitContainer1.Panel1.PerformLayout()
			AddressOf Me.SplitContainer1.Panel2.ResumeLayout(False)
			AddressOf Me.SplitContainer1.Panel2.PerformLayout()
			(CType(AddressOf Me.SplitContainer1, ISupportInitialize)).EndInit()
			AddressOf Me.SplitContainer1.ResumeLayout(False)
			(CType(AddressOf Me.TrackBar1, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.AxWindowsMediaPlayer1, ISupportInitialize)).EndInit()
			Me.ResumeLayout(False)
		End Sub

		Private Sub Form2_Load(sender As Object, e As EventArgs)
			AddressOf AddressOf MySettingsProperty.Settings.Laeuft = "Nein"
		End Sub

		Private Sub TextBox1_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub AxWindowsMediaPlayer1_Enter(sender As Object, e As EventArgs)
		End Sub

		Private Sub Button2_Click(sender As Object, e As EventArgs)
			AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.[stop]()
		End Sub

		Private Sub Button3_Click(sender As Object, e As EventArgs)
			AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.pause()
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			AddressOf Me.AxWindowsMediaPlayer1.URL = Conversions.ToString(AddressOf Me.ListBox1.SelectedItem)
			If Operators.ConditionalCompareObjectEqual(AddressOf Me.AxWindowsMediaPlayer1.URL, AddressOf Me.ListBox1.SelectedItem, False) Then
				AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.play()
			End If
		End Sub

		Private Sub TrackBar2_Scroll(sender As Object, e As EventArgs)
		End Sub

		Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs)
			Try
				AddressOf Me.Label2.Text = Conversions.ToString(AddressOf Me.ListBox1.SelectedItem)
			Catch expr_1D As Exception
				ProjectData.SetProjectError(expr_1D)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub Button2_Click_1(sender As Object, e As EventArgs)
			Dim Ownsrc As String = AddressOf Me.TextBox1.Text
			AddressOf Me.ListBox1.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists(Ownsrc) Then
				Dim directory As DirectoryInfo = New DirectoryInfo(Ownsrc)
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					If Operators.CompareString(file.Extension, ".mp3", False) = 0 Or Operators.CompareString(file.Extension, ".mp4", False) = 0 Or Operators.CompareString(file.Extension, ".INK", False) = 0 Or Operators.CompareString(file.Extension, ".ink", False) = 0 Or Operators.CompareString(file.Extension, ".wav", False) = 0 Or Operators.CompareString(file.Extension, ".evoromusic", False) = 0 Then
						AddressOf Me.ListBox1.Items.Add(file.FullName)
					End If
				Next
			Else
				Interaction.MsgBox("Ordner nicht gefunden.", MsgBoxStyle.OkOnly, Nothing)
			End If
			If AddressOf Me.ListBox1.Items.Count = 0 Then
				AddressOf Me.ListBox1.Items.Add("Dieser Ordner enthällt keine gültigen Dateien.")
			End If
		End Sub

		Private Sub Button4_Click(sender As Object, e As EventArgs)
			AddressOf Me.ListBox1.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Music") Then
				Dim directory As DirectoryInfo = New DirectoryInfo("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Music")
				AddressOf Me.Button4.Text = "Neu Laden..."
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					If Operators.CompareString(file.Extension, ".mp3", False) = 0 Or Operators.CompareString(file.Extension, ".mp4", False) = 0 Or Operators.CompareString(file.Extension, ".INK", False) = 0 Or Operators.CompareString(file.Extension, ".ink", False) = 0 Or Operators.CompareString(file.Extension, ".wav", False) = 0 Or Operators.CompareString(file.Extension, ".evoromusic", False) = 0 Then
						AddressOf Me.ListBox1.Items.Add(file.FullName)
					End If
				Next
			Else
				Interaction.MsgBox("Neuer leerer Ordner wird erstellt, da dieser noch nicht vorhanden ist, jedoch dringend benötigt wird. Der Ordner befindet sich auf dem Desktop.", MsgBoxStyle.OkOnly, Nothing)
				Try
					Directory.CreateDirectory("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Music")
					Interaction.MsgBox("Der Ordner wurde erstellt. Er befindet sich auf dem Desktop unter dem Namen: 'EvoroVOS'", MsgBoxStyle.OkOnly, Nothing)
				Catch expr_152 As Exception
					ProjectData.SetProjectError(expr_152)
					Interaction.MsgBox("Fehler beim erstellen des Ordners! Bitte schließe das Programm, erstelle auf deinem Desktop einen Ordner mit dem Namen 'EvoroVOS' mit einem untergeordnetem Ordner 'Programs'.", MsgBoxStyle.Critical, Nothing)
					ProjectData.ClearProjectError()
				End Try
			End If
			If AddressOf Me.ListBox1.Items.Count = 0 Then
				Interaction.MsgBox("Der Ordner enthällt keine gültigen oder verfügbaren Dateien. Um gültige Dateien hinzuzufügen, gehen sie auf den Desktop und öffnen den Ordner EvoroVOS\Music und fügen hier die gesuchten Programme oder Verknüpfungen ein.", MsgBoxStyle.OkOnly, Nothing)
			End If
		End Sub

		Private Sub Button1_Click_1(sender As Object, e As EventArgs)
			Try
				AddressOf Me.AxWindowsMediaPlayer1.URL = Conversions.ToString(AddressOf Me.ListBox1.SelectedItem)
				' The following expression was wrapped in a checked-expression
				AddressOf Me.TrackBar1.Maximum = CInt(Math.Round(AddressOf Me.AxWindowsMediaPlayer1.currentMedia.duration))
				AddressOf Me.Label1.Text = Conversions.ToString(AddressOf Me.AxWindowsMediaPlayer1.currentMedia.duration)
			Catch expr_5E As Exception
				ProjectData.SetProjectError(expr_5E)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub Button5_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf AddressOf MySettingsProperty.Settings.Pausiert, "F", False) = 0 Then
				AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.pause()
				AddressOf AddressOf MySettingsProperty.Settings.Pausiert = "T"
				AddressOf Me.Button5.Text = ChrW(9658) & "  Continue"
			Else
				AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.play()
				AddressOf AddressOf MySettingsProperty.Settings.Pausiert = "F"
				AddressOf Me.Button5.Text = "||  Pause"
			End If
		End Sub

		Private Sub Button6_Click(sender As Object, e As EventArgs)
			AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.[stop]()
		End Sub

		Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs)
			AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.currentPosition = CDec(AddressOf Me.TrackBar1.Value)
		End Sub

		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				AddressOf Me.TrackBar1.Maximum = CInt(Math.Round(AddressOf Me.AxWindowsMediaPlayer1.currentMedia.duration))
				AddressOf Me.TrackBar1.Value = CInt(Math.Round(AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.currentPosition))
				Dim Dauer As Double = AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.currentPosition
				AddressOf Me.Label1.Text = Conversions.ToString(Dauer)
			Catch expr_66 As Exception
				ProjectData.SetProjectError(expr_66)
				ProjectData.ClearProjectError()
			End Try
			Try
				If AddressOf Me.TrackBar1.Value = 99 And Operators.CompareString(AddressOf AddressOf MySettingsProperty.Settings.Laeuft, "Ja", False) = 0 Then
					Try
						AddressOf Me.Timer2.Start()
					Catch expr_AB As Exception
						ProjectData.SetProjectError(expr_AB)
						ProjectData.ClearProjectError()
					End Try
				End If
			Catch expr_BB As Exception
				ProjectData.SetProjectError(expr_BB)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub Timer2_Tick(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				If AddressOf Me.ListBox1.SelectedIndex + 1 >= AddressOf Me.ListBox1.Items.Count Then
					AddressOf Me.ListBox1.SelectedIndex = 0
					AddressOf Me.Timer3.Start()
					AddressOf Me.Timer2.[Stop]()
				Else
					AddressOf Me.ListBox1.SelectedIndex = AddressOf Me.ListBox1.SelectedIndex + 1
				End If
			Catch expr_5D As Exception
				ProjectData.SetProjectError(expr_5D)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub Timer3_Tick(sender As Object, e As EventArgs)
			AddressOf Me.AxWindowsMediaPlayer1.URL = Conversions.ToString(AddressOf Me.ListBox1.SelectedIndex)
			AddressOf Me.AxWindowsMediaPlayer1.URL = Conversions.ToString(AddressOf Me.ListBox1.SelectedItem)
			' The following expression was wrapped in a checked-expression
			AddressOf Me.TrackBar1.Maximum = CInt(Math.Round(AddressOf Me.AxWindowsMediaPlayer1.currentMedia.duration))
			AddressOf Me.Timer3.[Stop]()
		End Sub

		Private Sub Button8_Click(sender As Object, e As EventArgs)
			AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.fastReverse()
		End Sub

		Private Sub Button7_Click(sender As Object, e As EventArgs)
			AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.fastForward()
		End Sub

		Private Sub Button9_Click(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				If AddressOf Me.ListBox1.SelectedIndex - 1 >= AddressOf Me.ListBox1.Items.Count Then
					AddressOf Me.ListBox1.SelectedIndex = 0
				Else
					AddressOf Me.ListBox1.SelectedIndex = AddressOf Me.ListBox1.SelectedIndex - 1
				End If
			Catch expr_47 As Exception
				ProjectData.SetProjectError(expr_47)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub Button10_Click(sender As Object, e As EventArgs)
			AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.[stop]()
			AddressOf AddressOf MySettingsProperty.Settings.Pausiert = "F"
			' The following expression was wrapped in a checked-statement
			If AddressOf Me.ListBox1.SelectedIndex + 1 >= AddressOf Me.ListBox1.Items.Count Then
				AddressOf Me.ListBox1.SelectedIndex = 0
			Else
				AddressOf Me.ListBox1.SelectedIndex = AddressOf Me.ListBox1.SelectedIndex + 1
			End If
		End Sub

		Private Sub Timer4_Tick(sender As Object, e As EventArgs)
			Try
				AddressOf Me.AxWindowsMediaPlayer1.URL = Conversions.ToString(AddressOf Me.ListBox1.SelectedItem)
				' The following expression was wrapped in a checked-expression
				AddressOf Me.TrackBar1.Maximum = CInt(Math.Round(AddressOf Me.AxWindowsMediaPlayer1.currentMedia.duration))
				AddressOf Me.AxWindowsMediaPlayer1.Ctlcontrols.play()
				If AddressOf Me.AxWindowsMediaPlayer1.playState = CType((-1), WMPPlayState) Then
					AddressOf AddressOf MySettingsProperty.Settings.Laeuft = "Ja"
				End If
			Catch expr_6B As Exception
				ProjectData.SetProjectError(expr_6B)
				ProjectData.ClearProjectError()
			End Try
		End Sub
	End Class
End Namespace
