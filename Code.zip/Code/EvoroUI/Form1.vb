Imports EvoroUI.My
Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Form1
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		<AccessedThroughProperty("PictureBox1")>
		Private _PictureBox1 As PictureBox

		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		<AccessedThroughProperty("PictureBox2")>
		Private _PictureBox2 As PictureBox

		<AccessedThroughProperty("Timer2")>
		Private _Timer2 As Timer

		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		<AccessedThroughProperty("TextBox1")>
		Private _TextBox1 As TextBox

		<AccessedThroughProperty("Timer3")>
		Private _Timer3 As Timer

		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		<AccessedThroughProperty("TextBox2")>
		Private _TextBox2 As TextBox

		<AccessedThroughProperty("PictureBox3")>
		Private _PictureBox3 As PictureBox

		Friend Overridable Property Label1() As Label
			Get
				Return Me._Label1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		Friend Overridable Property PictureBox1() As PictureBox
			Get
				Return Me._PictureBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox1 = value
			End Set
		End Property

		Friend Overridable Property Timer1() As Timer
			Get
				Return Me._Timer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer1_Tick
				If Me._Timer1 IsNot Nothing Then
					RemoveHandler Me._Timer1.Tick, value2
				End If
				Me._Timer1 = value
				If Me._Timer1 IsNot Nothing Then
					AddHandler Me._Timer1.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property PictureBox2() As PictureBox
			Get
				Return Me._PictureBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox2 = value
			End Set
		End Property

		Friend Overridable Property Timer2() As Timer
			Get
				Return Me._Timer2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer2_Tick
				If Me._Timer2 IsNot Nothing Then
					RemoveHandler Me._Timer2.Tick, value2
				End If
				Me._Timer2 = value
				If Me._Timer2 IsNot Nothing Then
					AddHandler Me._Timer2.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Label2() As Label
			Get
				Return Me._Label2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		Friend Overridable Property TextBox1() As TextBox
			Get
				Return Me._TextBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox1 = value
			End Set
		End Property

		Friend Overridable Property Timer3() As Timer
			Get
				Return Me._Timer3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer3_Tick
				If Me._Timer3 IsNot Nothing Then
					RemoveHandler Me._Timer3.Tick, value2
				End If
				Me._Timer3 = value
				If Me._Timer3 IsNot Nothing Then
					AddHandler Me._Timer3.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Label3() As Label
			Get
				Return Me._Label3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		Friend Overridable Property TextBox2() As TextBox
			Get
				Return Me._TextBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox2 = value
			End Set
		End Property

		Friend Overridable Property PictureBox3() As PictureBox
			Get
				Return Me._PictureBox3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Dim value2 As EventHandler = AddressOf Me.PictureBox3_Click
				If Me._PictureBox3 IsNot Nothing Then
					RemoveHandler Me._PictureBox3.Click, value2
				End If
				Me._PictureBox3 = value
				If Me._PictureBox3 IsNot Nothing Then
					AddHandler Me._PictureBox3.Click, value2
				End If
			End Set
		End Property

		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.Form1_Load
			AddHandler MyBase.KeyDown, AddressOf Me.Form1_KeyDown
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Container()
			Dim resources As ComponentResourceManager = New ComponentResourceManager(GetType(Form1))
			AddressOf Me.Label1 = New Label()
			AddressOf Me.Timer1 = New Timer(Me.components)
			AddressOf Me.Timer2 = New Timer(Me.components)
			AddressOf Me.Label2 = New Label()
			AddressOf Me.TextBox1 = New TextBox()
			AddressOf Me.Timer3 = New Timer(Me.components)
			AddressOf Me.Label3 = New Label()
			AddressOf Me.TextBox2 = New TextBox()
			AddressOf Me.PictureBox3 = New PictureBox()
			AddressOf Me.PictureBox2 = New PictureBox()
			AddressOf Me.PictureBox1 = New PictureBox()
			(CType(AddressOf Me.PictureBox3, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).BeginInit()
			Me.SuspendLayout()
			AddressOf Me.Label1.AutoSize = True
			AddressOf Me.Label1.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.Label1.Font = New Font("Century Gothic", 26.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Label1.ForeColor = Color.White
			Dim arg_124_0 As Control = AddressOf Me.Label1
			Dim location As Point = New Point(107, 112)
			arg_124_0.Location = location
			AddressOf Me.Label1.Name = "Label1"
			Dim arg_14F_0 As Control = AddressOf Me.Label1
			Dim size As Size = New Size(227, 44)
			arg_14F_0.Size = size
			AddressOf Me.Label1.TabIndex = 0
			AddressOf Me.Label1.Text = "    EvoroUI    "
			AddressOf Me.Timer1.Interval = 7000
			AddressOf Me.Timer2.Interval = 1000
			AddressOf Me.Label2.AutoSize = True
			AddressOf Me.Label2.Font = New Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Label2.ForeColor = Color.White
			Dim arg_1DE_0 As Control = AddressOf Me.Label2
			location = New Point(104, 403)
			arg_1DE_0.Location = location
			AddressOf Me.Label2.Name = "Label2"
			Dim arg_206_0 As Control = AddressOf Me.Label2
			size = New Size(59, 16)
			arg_206_0.Size = size
			AddressOf Me.Label2.TabIndex = 6
			AddressOf Me.Label2.Text = "Password"
			AddressOf Me.TextBox1.BackColor = Color.Black
			AddressOf Me.TextBox1.BorderStyle = BorderStyle.None
			AddressOf Me.TextBox1.Font = New Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.TextBox1.ForeColor = Color.White
			Dim arg_288_0 As Control = AddressOf Me.TextBox1
			location = New Point(169, 403)
			arg_288_0.Location = location
			AddressOf Me.TextBox1.Name = "TextBox1"
			Dim arg_2B3_0 As Control = AddressOf Me.TextBox1
			size = New Size(163, 14)
			arg_2B3_0.Size = size
			AddressOf Me.TextBox1.TabIndex = 7
			AddressOf Me.Timer3.Enabled = True
			AddressOf Me.Timer3.Interval = 10
			AddressOf Me.Label3.AutoSize = True
			AddressOf Me.Label3.Font = New Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Label3.ForeColor = Color.White
			Dim arg_32B_0 As Control = AddressOf Me.Label3
			location = New Point(104, 387)
			arg_32B_0.Location = location
			AddressOf Me.Label3.Name = "Label3"
			Dim arg_353_0 As Control = AddressOf Me.Label3
			size = New Size(62, 16)
			arg_353_0.Size = size
			AddressOf Me.Label3.TabIndex = 8
			AddressOf Me.Label3.Text = "Username"
			AddressOf Me.TextBox2.BackColor = Color.Black
			AddressOf Me.TextBox2.BorderStyle = BorderStyle.None
			AddressOf Me.TextBox2.Font = New Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.TextBox2.ForeColor = Color.White
			Dim arg_3D5_0 As Control = AddressOf Me.TextBox2
			location = New Point(169, 387)
			arg_3D5_0.Location = location
			AddressOf Me.TextBox2.Name = "TextBox2"
			Dim arg_400_0 As Control = AddressOf Me.TextBox2
			size = New Size(163, 14)
			arg_400_0.Size = size
			AddressOf Me.TextBox2.TabIndex = 5
			AddressOf Me.PictureBox3.BackgroundImage = AddressOf Resources.X
			AddressOf Me.PictureBox3.BackgroundImageLayout = ImageLayout.Zoom
			AddressOf Me.PictureBox3.Cursor = Cursors.Hand
			Dim arg_452_0 As Control = AddressOf Me.PictureBox3
			location = New Point(396, 12)
			arg_452_0.Location = location
			AddressOf Me.PictureBox3.Name = "PictureBox3"
			Dim arg_47A_0 As Control = AddressOf Me.PictureBox3
			size = New Size(34, 36)
			arg_47A_0.Size = size
			AddressOf Me.PictureBox3.TabIndex = 9
			AddressOf Me.PictureBox3.TabStop = False
			AddressOf Me.PictureBox2.BackgroundImage = AddressOf Resources.windows8
			AddressOf Me.PictureBox2.BackgroundImageLayout = ImageLayout.None
			AddressOf Me.PictureBox2.Image = AddressOf Resources.windows8
			Dim arg_4D9_0 As Control = AddressOf Me.PictureBox2
			location = New Point(115, 283)
			arg_4D9_0.Location = location
			AddressOf Me.PictureBox2.Name = "PictureBox2"
			Dim arg_501_0 As Control = AddressOf Me.PictureBox2
			size = New Size(89, 89)
			arg_501_0.Size = size
			AddressOf Me.PictureBox2.TabIndex = 2
			AddressOf Me.PictureBox2.TabStop = False
			AddressOf Me.PictureBox2.Visible = False
			AddressOf Me.PictureBox1.BackgroundImage = AddressOf Resources.SkyVOSBig
			AddressOf Me.PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_55B_0 As Control = AddressOf Me.PictureBox1
			location = New Point(-7, 159)
			arg_55B_0.Location = location
			AddressOf Me.PictureBox1.Name = "PictureBox1"
			Dim arg_589_0 As Control = AddressOf Me.PictureBox1
			size = New Size(452, 225)
			arg_589_0.Size = size
			AddressOf Me.PictureBox1.TabIndex = 1
			AddressOf Me.PictureBox1.TabStop = False
			Dim autoScaleDimensions As SizeF = New SizeF(6F, 13F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			size = New Size(442, 501)
			Me.ClientSize = size
			Me.ControlBox = False
			Me.Controls.Add(AddressOf Me.PictureBox3)
			Me.Controls.Add(AddressOf Me.Label3)
			Me.Controls.Add(AddressOf Me.TextBox2)
			Me.Controls.Add(AddressOf Me.Label2)
			Me.Controls.Add(AddressOf Me.TextBox1)
			Me.Controls.Add(AddressOf Me.PictureBox2)
			Me.Controls.Add(AddressOf Me.PictureBox1)
			Me.Controls.Add(AddressOf Me.Label1)
			Me.Cursor = Cursors.WaitCursor
			Me.FormBorderStyle = FormBorderStyle.Fixed3D
			Me.Icon = CType(resources.GetObject("$this.Icon"), Icon)
			Me.Name = "Form1"
			Me.StartPosition = FormStartPosition.CenterScreen
			(CType(AddressOf Me.PictureBox3, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		Private Sub Form1_Load(sender As Object, e As EventArgs)
			AddressOf AddressOf MySettingsProperty.Settings.Pausiert = "F"
			AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Clear()
		End Sub

		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			Me.Hide()
			AddressOf Me.Timer1.[Stop]()
			AddressOf Me.Timer2.Start()
		End Sub

		Private Sub Timer2_Tick(sender As Object, e As EventArgs)
			Cursor.Show()
			If Operators.CompareString(AddressOf AddressOf MySettingsProperty.Settings.StandartStartfenster, "Desktop", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Ansicht2.Show()
			Else
				If Operators.CompareString(AddressOf AddressOf MySettingsProperty.Settings.StandartStartfenster, "MDIParent1", False) = 0 Then
					AddressOf AddressOf MyProject.Forms.MDIParent1.Show()
				Else
					AddressOf AddressOf MyProject.Forms.Ansicht2.Show()
				End If
			End If
			Me.Close()
			AddressOf Me.Timer2.[Stop]()
		End Sub

		Private Sub Timer3_Tick(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.TextBox1.Text, AddressOf AddressOf MySettingsProperty.Settings.Passwort, False) = 0 And Operators.CompareString(AddressOf Me.TextBox2.Text, AddressOf AddressOf MySettingsProperty.Settings.Username, False) = 0 Then
				AddressOf Me.PictureBox2.Show()
				Cursor.Show()
				AddressOf Me.TextBox1.Hide()
				AddressOf Me.Label2.Hide()
				AddressOf Me.TextBox2.Hide()
				AddressOf Me.Label3.Hide()
				AddressOf Me.Timer1.Start()
			End If
			If Operators.CompareString(AddressOf Me.TextBox1.Text, "", False) = 0 And Operators.CompareString(AddressOf Me.TextBox2.Text, AddressOf AddressOf MySettingsProperty.Settings.Username, False) = 0 Then
				AddressOf Me.TextBox1.[Select]()
			End If
			If Operators.CompareString(AddressOf Me.TextBox1.Text, AddressOf AddressOf MySettingsProperty.Settings.Passwort, False) = 0 And Operators.CompareString(AddressOf Me.TextBox2.Text, "", False) = 0 Then
				AddressOf Me.TextBox2.[Select]()
			End If
		End Sub

		Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs)
			If e.Control AndAlso e.KeyCode = Keys.Down Then
				AddressOf Me.TextBox1.[Select]()
			End If
		End Sub

		<MethodImpl(MethodImplOptions.NoInlining Or MethodImplOptions.NoOptimization)>
		Private Sub PictureBox3_Click(sender As Object, e As EventArgs)
			ProjectData.EndApp()
		End Sub
	End Class
End Namespace
