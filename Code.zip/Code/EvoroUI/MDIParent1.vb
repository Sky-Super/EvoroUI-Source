Imports EvoroUI.My
Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class MDIParent1
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("ToolTip")>
		Private _ToolTip As ToolTip

		<AccessedThroughProperty("ToolStrip")>
		Private _ToolStrip As ToolStrip

		<AccessedThroughProperty("ViewMenu")>
		Private _ViewMenu As ToolStripMenuItem

		<AccessedThroughProperty("ToolBarToolStripMenuItem")>
		Private _ToolBarToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("StatusBarToolStripMenuItem")>
		Private _StatusBarToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("WindowsMenu")>
		Private _WindowsMenu As ToolStripMenuItem

		<AccessedThroughProperty("NewWindowToolStripMenuItem")>
		Private _NewWindowToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("CascadeToolStripMenuItem")>
		Private _CascadeToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("TileVerticalToolStripMenuItem")>
		Private _TileVerticalToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("TileHorizontalToolStripMenuItem")>
		Private _TileHorizontalToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("CloseAllToolStripMenuItem")>
		Private _CloseAllToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("ArrangeIconsToolStripMenuItem")>
		Private _ArrangeIconsToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("HelpMenu")>
		Private _HelpMenu As ToolStripMenuItem

		<AccessedThroughProperty("ContentsToolStripMenuItem")>
		Private _ContentsToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("IndexToolStripMenuItem")>
		Private _IndexToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("SearchToolStripMenuItem")>
		Private _SearchToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("ToolStripSeparator8")>
		Private _ToolStripSeparator8 As ToolStripSeparator

		<AccessedThroughProperty("AboutToolStripMenuItem")>
		Private _AboutToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("MenuStrip")>
		Private _MenuStrip As MenuStrip

		<AccessedThroughProperty("ToolStripButton1")>
		Private _ToolStripButton1 As ToolStripButton

		<AccessedThroughProperty("BrowserToolStripMenuItem")>
		Private _BrowserToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("LosToolStripMenuItem")>
		Private _LosToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("ToolStripSeparator1")>
		Private _ToolStripSeparator1 As ToolStripSeparator

		<AccessedThroughProperty("NächsteSeiteToolStripMenuItem")>
		Private _NächsteSeiteToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("VorherigeSeiteToolStripMenuItem")>
		Private _VorherigeSeiteToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("NeuLadenToolStripMenuItem")>
		Private _NeuLadenToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("LadenAnhaltenToolStripMenuItem")>
		Private _LadenAnhaltenToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("ToolStripButton2")>
		Private _ToolStripButton2 As ToolStripButton

		<AccessedThroughProperty("TexteditorToolStripMenuItem")>
		Private _TexteditorToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("ToolStripButton3")>
		Private _ToolStripButton3 As ToolStripButton

		<AccessedThroughProperty("ToolStripButton4")>
		Private _ToolStripButton4 As ToolStripButton

		<AccessedThroughProperty("WiederholenToolStripMenuItem")>
		Private _WiederholenToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("RückgängigToolStripMenuItem")>
		Private _RückgängigToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("ToolStripSeparator2")>
		Private _ToolStripSeparator2 As ToolStripSeparator

		<AccessedThroughProperty("KopierenToolStripMenuItem")>
		Private _KopierenToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("EinfügenToolStripMenuItem")>
		Private _EinfügenToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("AusschneidenToolStripMenuItem")>
		Private _AusschneidenToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("ToolStripMenuItem1")>
		Private _ToolStripMenuItem1 As ToolStripSeparator

		<AccessedThroughProperty("AllesAuswählenToolStripMenuItem")>
		Private _AllesAuswählenToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		<AccessedThroughProperty("Timer2")>
		Private _Timer2 As Timer

		<AccessedThroughProperty("ToolTip1")>
		Private _ToolTip1 As ToolTip

		<AccessedThroughProperty("ToolTip2")>
		Private _ToolTip2 As ToolTip

		<AccessedThroughProperty("ToolTip3")>
		Private _ToolTip3 As ToolTip

		<AccessedThroughProperty("ToolStripButton5")>
		Private _ToolStripButton5 As ToolStripButton

		<AccessedThroughProperty("ToolTip4")>
		Private _ToolTip4 As ToolTip

		<AccessedThroughProperty("ToolStripMenuItem2")>
		Private _ToolStripMenuItem2 As ToolStripMenuItem

		<AccessedThroughProperty("Label6")>
		Private _Label6 As Label

		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("Panel1")>
		Private _Panel1 As Panel

		<AccessedThroughProperty("CheckBox1")>
		Private _CheckBox1 As CheckBox

		<AccessedThroughProperty("CheckBox2")>
		Private _CheckBox2 As CheckBox

		<AccessedThroughProperty("Button6")>
		Private _Button6 As Button

		<AccessedThroughProperty("Button5")>
		Private _Button5 As Button

		<AccessedThroughProperty("Button4")>
		Private _Button4 As Button

		<AccessedThroughProperty("Button3")>
		Private _Button3 As Button

		<AccessedThroughProperty("Button2")>
		Private _Button2 As Button

		<AccessedThroughProperty("PictureBox5")>
		Private _PictureBox5 As PictureBox

		<AccessedThroughProperty("PictureBox4")>
		Private _PictureBox4 As PictureBox

		<AccessedThroughProperty("PictureBox3")>
		Private _PictureBox3 As PictureBox

		<AccessedThroughProperty("PictureBox2")>
		Private _PictureBox2 As PictureBox

		<AccessedThroughProperty("PictureBox1")>
		Private _PictureBox1 As PictureBox

		<AccessedThroughProperty("PictureBox6")>
		Private _PictureBox6 As PictureBox

		<AccessedThroughProperty("Button7")>
		Private _Button7 As Button

		<AccessedThroughProperty("Panel2")>
		Private _Panel2 As Panel

		<AccessedThroughProperty("CheckBox3")>
		Private _CheckBox3 As CheckBox

		<AccessedThroughProperty("Button8")>
		Private _Button8 As Button

		<AccessedThroughProperty("StartmenüToolStripMenuItem")>
		Private _StartmenüToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("ToolStripButton6")>
		Private _ToolStripButton6 As ToolStripButton

		<AccessedThroughProperty("Button9")>
		Private _Button9 As Button

		<AccessedThroughProperty("PictureBox7")>
		Private _PictureBox7 As PictureBox

		<AccessedThroughProperty("ToolStripStatusLabel1")>
		Private _ToolStripStatusLabel1 As ToolStripStatusLabel

		<AccessedThroughProperty("ToolStripStatusLabel")>
		Private _ToolStripStatusLabel As ToolStripStatusLabel

		<AccessedThroughProperty("StatusStrip")>
		Private _StatusStrip As StatusStrip

		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		<AccessedThroughProperty("Label8")>
		Private _Label8 As Label

		<AccessedThroughProperty("Ansicht2ToolStripMenuItem")>
		Private _Ansicht2ToolStripMenuItem As ToolStripMenuItem

		Private m_ChildFormNumber As Integer

		Friend Overridable Property ToolTip() As ToolTip
			Get
				Return Me._ToolTip
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolTip)
				Me._ToolTip = value
			End Set
		End Property

		Friend Overridable Property ToolStrip() As ToolStrip
			Get
				Return Me._ToolStrip
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStrip)
				Me._ToolStrip = value
			End Set
		End Property

		Friend Overridable Property ViewMenu() As ToolStripMenuItem
			Get
				Return Me._ViewMenu
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Me._ViewMenu = value
			End Set
		End Property

		Friend Overridable Property ToolBarToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._ToolBarToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.ToolBarToolStripMenuItem_Click
				If Me._ToolBarToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._ToolBarToolStripMenuItem.Click, value2
				End If
				Me._ToolBarToolStripMenuItem = value
				If Me._ToolBarToolStripMenuItem IsNot Nothing Then
					AddHandler Me._ToolBarToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property StatusBarToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._StatusBarToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.StatusBarToolStripMenuItem_Click
				If Me._StatusBarToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._StatusBarToolStripMenuItem.Click, value2
				End If
				Me._StatusBarToolStripMenuItem = value
				If Me._StatusBarToolStripMenuItem IsNot Nothing Then
					AddHandler Me._StatusBarToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property WindowsMenu() As ToolStripMenuItem
			Get
				Return Me._WindowsMenu
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Me._WindowsMenu = value
			End Set
		End Property

		Friend Overridable Property NewWindowToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._NewWindowToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.ShowNewForm
				If Me._NewWindowToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._NewWindowToolStripMenuItem.Click, value2
				End If
				Me._NewWindowToolStripMenuItem = value
				If Me._NewWindowToolStripMenuItem IsNot Nothing Then
					AddHandler Me._NewWindowToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property CascadeToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._CascadeToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.CascadeToolStripMenuItem_Click
				If Me._CascadeToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._CascadeToolStripMenuItem.Click, value2
				End If
				Me._CascadeToolStripMenuItem = value
				If Me._CascadeToolStripMenuItem IsNot Nothing Then
					AddHandler Me._CascadeToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property TileVerticalToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._TileVerticalToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.TileVerticalToolStripMenuItem_Click
				If Me._TileVerticalToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._TileVerticalToolStripMenuItem.Click, value2
				End If
				Me._TileVerticalToolStripMenuItem = value
				If Me._TileVerticalToolStripMenuItem IsNot Nothing Then
					AddHandler Me._TileVerticalToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property TileHorizontalToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._TileHorizontalToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.TileHorizontalToolStripMenuItem_Click
				If Me._TileHorizontalToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._TileHorizontalToolStripMenuItem.Click, value2
				End If
				Me._TileHorizontalToolStripMenuItem = value
				If Me._TileHorizontalToolStripMenuItem IsNot Nothing Then
					AddHandler Me._TileHorizontalToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property CloseAllToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._CloseAllToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.CloseAllToolStripMenuItem_Click
				If Me._CloseAllToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._CloseAllToolStripMenuItem.Click, value2
				End If
				Me._CloseAllToolStripMenuItem = value
				If Me._CloseAllToolStripMenuItem IsNot Nothing Then
					AddHandler Me._CloseAllToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ArrangeIconsToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._ArrangeIconsToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.ArrangeIconsToolStripMenuItem_Click
				If Me._ArrangeIconsToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._ArrangeIconsToolStripMenuItem.Click, value2
				End If
				Me._ArrangeIconsToolStripMenuItem = value
				If Me._ArrangeIconsToolStripMenuItem IsNot Nothing Then
					AddHandler Me._ArrangeIconsToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property HelpMenu() As ToolStripMenuItem
			Get
				Return Me._HelpMenu
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Me._HelpMenu = value
			End Set
		End Property

		Friend Overridable Property ContentsToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._ContentsToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.ContentsToolStripMenuItem_Click
				If Me._ContentsToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._ContentsToolStripMenuItem.Click, value2
				End If
				Me._ContentsToolStripMenuItem = value
				If Me._ContentsToolStripMenuItem IsNot Nothing Then
					AddHandler Me._ContentsToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property IndexToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._IndexToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Me._IndexToolStripMenuItem = value
			End Set
		End Property

		Friend Overridable Property SearchToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._SearchToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Me._SearchToolStripMenuItem = value
			End Set
		End Property

		Friend Overridable Property ToolStripSeparator8() As ToolStripSeparator
			Get
				Return Me._ToolStripSeparator8
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripSeparator)
				Me._ToolStripSeparator8 = value
			End Set
		End Property

		Friend Overridable Property AboutToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._AboutToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.AboutToolStripMenuItem_Click
				If Me._AboutToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._AboutToolStripMenuItem.Click, value2
				End If
				Me._AboutToolStripMenuItem = value
				If Me._AboutToolStripMenuItem IsNot Nothing Then
					AddHandler Me._AboutToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property MenuStrip() As MenuStrip
			Get
				Return Me._MenuStrip
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MenuStrip)
				Me._MenuStrip = value
			End Set
		End Property

		Friend Overridable Property ToolStripButton1() As ToolStripButton
			Get
				Return Me._ToolStripButton1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton1_Click
				If Me._ToolStripButton1 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton1.Click, value2
				End If
				Me._ToolStripButton1 = value
				If Me._ToolStripButton1 IsNot Nothing Then
					AddHandler Me._ToolStripButton1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property BrowserToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._BrowserToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Me._BrowserToolStripMenuItem = value
			End Set
		End Property

		Friend Overridable Property LosToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._LosToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.LosToolStripMenuItem_Click
				If Me._LosToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._LosToolStripMenuItem.Click, value2
				End If
				Me._LosToolStripMenuItem = value
				If Me._LosToolStripMenuItem IsNot Nothing Then
					AddHandler Me._LosToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripSeparator1() As ToolStripSeparator
			Get
				Return Me._ToolStripSeparator1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripSeparator)
				Me._ToolStripSeparator1 = value
			End Set
		End Property

		Friend Overridable Property NächsteSeiteToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._NächsteSeiteToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.NächsteSeiteToolStripMenuItem_Click
				If Me._NächsteSeiteToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._NächsteSeiteToolStripMenuItem.Click, value2
				End If
				Me._NächsteSeiteToolStripMenuItem = value
				If Me._NächsteSeiteToolStripMenuItem IsNot Nothing Then
					AddHandler Me._NächsteSeiteToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property VorherigeSeiteToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._VorherigeSeiteToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.VorherigeSeiteToolStripMenuItem_Click
				If Me._VorherigeSeiteToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._VorherigeSeiteToolStripMenuItem.Click, value2
				End If
				Me._VorherigeSeiteToolStripMenuItem = value
				If Me._VorherigeSeiteToolStripMenuItem IsNot Nothing Then
					AddHandler Me._VorherigeSeiteToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property NeuLadenToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._NeuLadenToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.NeuLadenToolStripMenuItem_Click
				If Me._NeuLadenToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._NeuLadenToolStripMenuItem.Click, value2
				End If
				Me._NeuLadenToolStripMenuItem = value
				If Me._NeuLadenToolStripMenuItem IsNot Nothing Then
					AddHandler Me._NeuLadenToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property LadenAnhaltenToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._LadenAnhaltenToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.LadenAnhaltenToolStripMenuItem_Click
				If Me._LadenAnhaltenToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._LadenAnhaltenToolStripMenuItem.Click, value2
				End If
				Me._LadenAnhaltenToolStripMenuItem = value
				If Me._LadenAnhaltenToolStripMenuItem IsNot Nothing Then
					AddHandler Me._LadenAnhaltenToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton2() As ToolStripButton
			Get
				Return Me._ToolStripButton2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton2_Click
				If Me._ToolStripButton2 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton2.Click, value2
				End If
				Me._ToolStripButton2 = value
				If Me._ToolStripButton2 IsNot Nothing Then
					AddHandler Me._ToolStripButton2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property TexteditorToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._TexteditorToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Me._TexteditorToolStripMenuItem = value
			End Set
		End Property

		Friend Overridable Property ToolStripButton3() As ToolStripButton
			Get
				Return Me._ToolStripButton3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton3_Click
				If Me._ToolStripButton3 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton3.Click, value2
				End If
				Me._ToolStripButton3 = value
				If Me._ToolStripButton3 IsNot Nothing Then
					AddHandler Me._ToolStripButton3.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton4() As ToolStripButton
			Get
				Return Me._ToolStripButton4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton4_Click
				If Me._ToolStripButton4 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton4.Click, value2
				End If
				Me._ToolStripButton4 = value
				If Me._ToolStripButton4 IsNot Nothing Then
					AddHandler Me._ToolStripButton4.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property WiederholenToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._WiederholenToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.WiederholenToolStripMenuItem_Click
				If Me._WiederholenToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._WiederholenToolStripMenuItem.Click, value2
				End If
				Me._WiederholenToolStripMenuItem = value
				If Me._WiederholenToolStripMenuItem IsNot Nothing Then
					AddHandler Me._WiederholenToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property RückgängigToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._RückgängigToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.RückgängigToolStripMenuItem_Click
				If Me._RückgängigToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._RückgängigToolStripMenuItem.Click, value2
				End If
				Me._RückgängigToolStripMenuItem = value
				If Me._RückgängigToolStripMenuItem IsNot Nothing Then
					AddHandler Me._RückgängigToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripSeparator2() As ToolStripSeparator
			Get
				Return Me._ToolStripSeparator2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripSeparator)
				Me._ToolStripSeparator2 = value
			End Set
		End Property

		Friend Overridable Property KopierenToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._KopierenToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.KopierenToolStripMenuItem_Click
				If Me._KopierenToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._KopierenToolStripMenuItem.Click, value2
				End If
				Me._KopierenToolStripMenuItem = value
				If Me._KopierenToolStripMenuItem IsNot Nothing Then
					AddHandler Me._KopierenToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property EinfügenToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._EinfügenToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.EinfügenToolStripMenuItem_Click
				If Me._EinfügenToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._EinfügenToolStripMenuItem.Click, value2
				End If
				Me._EinfügenToolStripMenuItem = value
				If Me._EinfügenToolStripMenuItem IsNot Nothing Then
					AddHandler Me._EinfügenToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property AusschneidenToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._AusschneidenToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.AusschneidenToolStripMenuItem_Click
				If Me._AusschneidenToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._AusschneidenToolStripMenuItem.Click, value2
				End If
				Me._AusschneidenToolStripMenuItem = value
				If Me._AusschneidenToolStripMenuItem IsNot Nothing Then
					AddHandler Me._AusschneidenToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripMenuItem1() As ToolStripSeparator
			Get
				Return Me._ToolStripMenuItem1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripSeparator)
				Me._ToolStripMenuItem1 = value
			End Set
		End Property

		Friend Overridable Property AllesAuswählenToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._AllesAuswählenToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.AllesAuswählenToolStripMenuItem_Click
				If Me._AllesAuswählenToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._AllesAuswählenToolStripMenuItem.Click, value2
				End If
				Me._AllesAuswählenToolStripMenuItem = value
				If Me._AllesAuswählenToolStripMenuItem IsNot Nothing Then
					AddHandler Me._AllesAuswählenToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Timer1() As Timer
			Get
				Return Me._Timer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer1_Tick
				If Me._Timer1 IsNot Nothing Then
					RemoveHandler Me._Timer1.Tick, value2
				End If
				Me._Timer1 = value
				If Me._Timer1 IsNot Nothing Then
					AddHandler Me._Timer1.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Timer2() As Timer
			Get
				Return Me._Timer2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer2_Tick
				If Me._Timer2 IsNot Nothing Then
					RemoveHandler Me._Timer2.Tick, value2
				End If
				Me._Timer2 = value
				If Me._Timer2 IsNot Nothing Then
					AddHandler Me._Timer2.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolTip1() As ToolTip
			Get
				Return Me._ToolTip1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolTip)
				Me._ToolTip1 = value
			End Set
		End Property

		Friend Overridable Property ToolTip2() As ToolTip
			Get
				Return Me._ToolTip2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolTip)
				Me._ToolTip2 = value
			End Set
		End Property

		Friend Overridable Property ToolTip3() As ToolTip
			Get
				Return Me._ToolTip3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolTip)
				Me._ToolTip3 = value
			End Set
		End Property

		Friend Overridable Property ToolStripButton5() As ToolStripButton
			Get
				Return Me._ToolStripButton5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton5_Click
				If Me._ToolStripButton5 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton5.Click, value2
				End If
				Me._ToolStripButton5 = value
				If Me._ToolStripButton5 IsNot Nothing Then
					AddHandler Me._ToolStripButton5.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolTip4() As ToolTip
			Get
				Return Me._ToolTip4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolTip)
				Me._ToolTip4 = value
			End Set
		End Property

		Friend Overridable Property ToolStripMenuItem2() As ToolStripMenuItem
			Get
				Return Me._ToolStripMenuItem2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.ToolStripMenuItem2_Click
				If Me._ToolStripMenuItem2 IsNot Nothing Then
					RemoveHandler Me._ToolStripMenuItem2.Click, value2
				End If
				Me._ToolStripMenuItem2 = value
				If Me._ToolStripMenuItem2 IsNot Nothing Then
					AddHandler Me._ToolStripMenuItem2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Label6() As Label
			Get
				Return Me._Label6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label6 = value
			End Set
		End Property

		Friend Overridable Property Label7() As Label
			Get
				Return Me._Label7
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button1_Click_1
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.Click, value2
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Panel1() As Panel
			Get
				Return Me._Panel1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._Panel1 = value
			End Set
		End Property

		Friend Overridable Property CheckBox1() As CheckBox
			Get
				Return Me._CheckBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim value2 As EventHandler = AddressOf Me.CheckBox1_CheckedChanged
				If Me._CheckBox1 IsNot Nothing Then
					RemoveHandler Me._CheckBox1.CheckedChanged, value2
				End If
				Me._CheckBox1 = value
				If Me._CheckBox1 IsNot Nothing Then
					AddHandler Me._CheckBox1.CheckedChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property CheckBox2() As CheckBox
			Get
				Return Me._CheckBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim value2 As EventHandler = AddressOf Me.CheckBox2_CheckedChanged
				If Me._CheckBox2 IsNot Nothing Then
					RemoveHandler Me._CheckBox2.CheckedChanged, value2
				End If
				Me._CheckBox2 = value
				If Me._CheckBox2 IsNot Nothing Then
					AddHandler Me._CheckBox2.CheckedChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button6() As Button
			Get
				Return Me._Button6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button6_Click
				If Me._Button6 IsNot Nothing Then
					RemoveHandler Me._Button6.Click, value2
				End If
				Me._Button6 = value
				If Me._Button6 IsNot Nothing Then
					AddHandler Me._Button6.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button5() As Button
			Get
				Return Me._Button5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button5_Click
				If Me._Button5 IsNot Nothing Then
					RemoveHandler Me._Button5.Click, value2
				End If
				Me._Button5 = value
				If Me._Button5 IsNot Nothing Then
					AddHandler Me._Button5.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button4() As Button
			Get
				Return Me._Button4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button4_Click
				If Me._Button4 IsNot Nothing Then
					RemoveHandler Me._Button4.Click, value2
				End If
				Me._Button4 = value
				If Me._Button4 IsNot Nothing Then
					AddHandler Me._Button4.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button3() As Button
			Get
				Return Me._Button3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button3_Click
				If Me._Button3 IsNot Nothing Then
					RemoveHandler Me._Button3.Click, value2
				End If
				Me._Button3 = value
				If Me._Button3 IsNot Nothing Then
					AddHandler Me._Button3.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button2() As Button
			Get
				Return Me._Button2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button2_Click
				If Me._Button2 IsNot Nothing Then
					RemoveHandler Me._Button2.Click, value2
				End If
				Me._Button2 = value
				If Me._Button2 IsNot Nothing Then
					AddHandler Me._Button2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property PictureBox5() As PictureBox
			Get
				Return Me._PictureBox5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox5 = value
			End Set
		End Property

		Friend Overridable Property PictureBox4() As PictureBox
			Get
				Return Me._PictureBox4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox4 = value
			End Set
		End Property

		Friend Overridable Property PictureBox3() As PictureBox
			Get
				Return Me._PictureBox3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox3 = value
			End Set
		End Property

		Friend Overridable Property PictureBox2() As PictureBox
			Get
				Return Me._PictureBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox2 = value
			End Set
		End Property

		Friend Overridable Property PictureBox1() As PictureBox
			Get
				Return Me._PictureBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox1 = value
			End Set
		End Property

		Friend Overridable Property PictureBox6() As PictureBox
			Get
				Return Me._PictureBox6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox6 = value
			End Set
		End Property

		Friend Overridable Property Button7() As Button
			Get
				Return Me._Button7
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button7_Click
				If Me._Button7 IsNot Nothing Then
					RemoveHandler Me._Button7.Click, value2
				End If
				Me._Button7 = value
				If Me._Button7 IsNot Nothing Then
					AddHandler Me._Button7.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Panel2() As Panel
			Get
				Return Me._Panel2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._Panel2 = value
			End Set
		End Property

		Friend Overridable Property CheckBox3() As CheckBox
			Get
				Return Me._CheckBox3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As CheckBox)
				Dim value2 As EventHandler = AddressOf Me.CheckBox3_CheckedChanged
				If Me._CheckBox3 IsNot Nothing Then
					RemoveHandler Me._CheckBox3.CheckedChanged, value2
				End If
				Me._CheckBox3 = value
				If Me._CheckBox3 IsNot Nothing Then
					AddHandler Me._CheckBox3.CheckedChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button8() As Button
			Get
				Return Me._Button8
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button8_Click
				If Me._Button8 IsNot Nothing Then
					RemoveHandler Me._Button8.Click, value2
				End If
				Me._Button8 = value
				If Me._Button8 IsNot Nothing Then
					AddHandler Me._Button8.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property StartmenüToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._StartmenüToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.StartmenüToolStripMenuItem_Click
				If Me._StartmenüToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._StartmenüToolStripMenuItem.Click, value2
				End If
				Me._StartmenüToolStripMenuItem = value
				If Me._StartmenüToolStripMenuItem IsNot Nothing Then
					AddHandler Me._StartmenüToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripButton6() As ToolStripButton
			Get
				Return Me._ToolStripButton6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripButton)
				Dim value2 As EventHandler = AddressOf Me.ToolStripButton6_Click
				If Me._ToolStripButton6 IsNot Nothing Then
					RemoveHandler Me._ToolStripButton6.Click, value2
				End If
				Me._ToolStripButton6 = value
				If Me._ToolStripButton6 IsNot Nothing Then
					AddHandler Me._ToolStripButton6.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button9() As Button
			Get
				Return Me._Button9
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button9_Click_1
				If Me._Button9 IsNot Nothing Then
					RemoveHandler Me._Button9.Click, value2
				End If
				Me._Button9 = value
				If Me._Button9 IsNot Nothing Then
					AddHandler Me._Button9.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property PictureBox7() As PictureBox
			Get
				Return Me._PictureBox7
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox7 = value
			End Set
		End Property

		Friend Overridable Property ToolStripStatusLabel1() As ToolStripStatusLabel
			Get
				Return Me._ToolStripStatusLabel1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripStatusLabel)
				Me._ToolStripStatusLabel1 = value
			End Set
		End Property

		Friend Overridable Property ToolStripStatusLabel() As ToolStripStatusLabel
			Get
				Return Me._ToolStripStatusLabel
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripStatusLabel)
				Me._ToolStripStatusLabel = value
			End Set
		End Property

		Friend Overridable Property StatusStrip() As StatusStrip
			Get
				Return Me._StatusStrip
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As StatusStrip)
				Me._StatusStrip = value
			End Set
		End Property

		Friend Overridable Property Label1() As Label
			Get
				Return Me._Label1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		Friend Overridable Property Label2() As Label
			Get
				Return Me._Label2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		Friend Overridable Property Label3() As Label
			Get
				Return Me._Label3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		Friend Overridable Property Label4() As Label
			Get
				Return Me._Label4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		Friend Overridable Property Label5() As Label
			Get
				Return Me._Label5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		Friend Overridable Property Label8() As Label
			Get
				Return Me._Label8
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label8 = value
			End Set
		End Property

		Friend Overridable Property Ansicht2ToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._Ansicht2ToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.Ansicht2ToolStripMenuItem_Click
				If Me._Ansicht2ToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._Ansicht2ToolStripMenuItem.Click, value2
				End If
				Me._Ansicht2ToolStripMenuItem = value
				If Me._Ansicht2ToolStripMenuItem IsNot Nothing Then
					AddHandler Me._Ansicht2ToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.MDIParent1_Load
			AddHandler MyBase.MouseHover, AddressOf Me.MDIParent1_MouseHover
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Container()
			Dim resources As ComponentResourceManager = New ComponentResourceManager(GetType(MDIParent1))
			AddressOf Me.ToolTip = New ToolTip(Me.components)
			AddressOf Me.Timer1 = New Timer(Me.components)
			AddressOf Me.Timer2 = New Timer(Me.components)
			AddressOf Me.ToolTip1 = New ToolTip(Me.components)
			AddressOf Me.ToolTip2 = New ToolTip(Me.components)
			AddressOf Me.ToolTip3 = New ToolTip(Me.components)
			AddressOf Me.ToolTip4 = New ToolTip(Me.components)
			AddressOf Me.Panel1 = New Panel()
			AddressOf Me.Button9 = New Button()
			AddressOf Me.CheckBox3 = New CheckBox()
			AddressOf Me.Button8 = New Button()
			AddressOf Me.Button2 = New Button()
			AddressOf Me.Button7 = New Button()
			AddressOf Me.Button6 = New Button()
			AddressOf Me.Button5 = New Button()
			AddressOf Me.Button4 = New Button()
			AddressOf Me.Button3 = New Button()
			AddressOf Me.CheckBox2 = New CheckBox()
			AddressOf Me.CheckBox1 = New CheckBox()
			AddressOf Me.Label1 = New Label()
			AddressOf Me.Label2 = New Label()
			AddressOf Me.Label3 = New Label()
			AddressOf Me.Label4 = New Label()
			AddressOf Me.Label5 = New Label()
			AddressOf Me.Label8 = New Label()
			AddressOf Me.Button1 = New Button()
			AddressOf Me.PictureBox7 = New PictureBox()
			AddressOf Me.PictureBox1 = New PictureBox()
			AddressOf Me.Panel2 = New Panel()
			AddressOf Me.Label7 = New Label()
			AddressOf Me.Label6 = New Label()
			AddressOf Me.PictureBox6 = New PictureBox()
			AddressOf Me.PictureBox5 = New PictureBox()
			AddressOf Me.PictureBox4 = New PictureBox()
			AddressOf Me.PictureBox3 = New PictureBox()
			AddressOf Me.PictureBox2 = New PictureBox()
			AddressOf Me.ToolStrip = New ToolStrip()
			AddressOf Me.ToolStripButton1 = New ToolStripButton()
			AddressOf Me.ToolStripButton2 = New ToolStripButton()
			AddressOf Me.ToolStripButton3 = New ToolStripButton()
			AddressOf Me.ToolStripButton4 = New ToolStripButton()
			AddressOf Me.ToolStripButton5 = New ToolStripButton()
			AddressOf Me.ToolStripButton6 = New ToolStripButton()
			AddressOf Me.MenuStrip = New MenuStrip()
			AddressOf Me.ViewMenu = New ToolStripMenuItem()
			AddressOf Me.ToolBarToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.StatusBarToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.StartmenüToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.WindowsMenu = New ToolStripMenuItem()
			AddressOf Me.NewWindowToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.CascadeToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.TileVerticalToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.TileHorizontalToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.CloseAllToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.ArrangeIconsToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.HelpMenu = New ToolStripMenuItem()
			AddressOf Me.ContentsToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.IndexToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.SearchToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.ToolStripSeparator8 = New ToolStripSeparator()
			AddressOf Me.AboutToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.ToolStripMenuItem2 = New ToolStripMenuItem()
			AddressOf Me.BrowserToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.LosToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.ToolStripSeparator1 = New ToolStripSeparator()
			AddressOf Me.NächsteSeiteToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.VorherigeSeiteToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.NeuLadenToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.LadenAnhaltenToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.TexteditorToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.RückgängigToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.WiederholenToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.ToolStripSeparator2 = New ToolStripSeparator()
			AddressOf Me.KopierenToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.EinfügenToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.AusschneidenToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.ToolStripMenuItem1 = New ToolStripSeparator()
			AddressOf Me.AllesAuswählenToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.StatusStrip = New StatusStrip()
			AddressOf Me.ToolStripStatusLabel1 = New ToolStripStatusLabel()
			AddressOf Me.ToolStripStatusLabel = New ToolStripStatusLabel()
			AddressOf Me.Ansicht2ToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.Panel1.SuspendLayout()
			(CType(AddressOf Me.PictureBox7, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).BeginInit()
			AddressOf Me.Panel2.SuspendLayout()
			(CType(AddressOf Me.PictureBox6, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox5, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox4, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox3, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).BeginInit()
			AddressOf Me.ToolStrip.SuspendLayout()
			AddressOf Me.MenuStrip.SuspendLayout()
			AddressOf Me.StatusStrip.SuspendLayout()
			Me.SuspendLayout()
			AddressOf Me.Timer1.Enabled = True
			AddressOf Me.Timer1.Interval = 1
			AddressOf Me.Timer2.Enabled = True
			AddressOf Me.Timer2.Interval = 1
			AddressOf Me.Panel1.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Panel1.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button9)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.PictureBox7)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.CheckBox3)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button8)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.PictureBox1)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button2)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Panel2)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.PictureBox6)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button7)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.PictureBox5)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.PictureBox4)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.PictureBox3)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.PictureBox2)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button6)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button5)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button4)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button3)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.CheckBox2)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.CheckBox1)
			AddressOf Me.Panel1.ForeColor = Color.White
			Dim arg_664_0 As Control = AddressOf Me.Panel1
			Dim location As Point = New Point(52, 254)
			arg_664_0.Location = location
			AddressOf Me.Panel1.Name = "Panel1"
			Dim arg_692_0 As Control = AddressOf Me.Panel1
			Dim size As Size = New Size(266, 298)
			arg_692_0.Size = size
			AddressOf Me.Panel1.TabIndex = 21
			AddressOf Me.Panel1.Visible = False
			AddressOf Me.Button9.FlatStyle = FlatStyle.Flat
			Dim arg_6D1_0 As Control = AddressOf Me.Button9
			location = New Point(40, 200)
			arg_6D1_0.Location = location
			AddressOf Me.Button9.Name = "Button9"
			Dim arg_6FC_0 As Control = AddressOf Me.Button9
			size = New Size(221, 25)
			arg_6FC_0.Size = size
			AddressOf Me.Button9.TabIndex = 37
			AddressOf Me.Button9.Text = "EvoPaint"
			AddressOf Me.Button9.UseVisualStyleBackColor = True
			AddressOf Me.CheckBox3.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.CheckBox3.AutoSize = True
			AddressOf Me.CheckBox3.Checked = True
			AddressOf Me.CheckBox3.CheckState = CheckState.Checked
			Dim arg_770_0 As Control = AddressOf Me.CheckBox3
			location = New Point(40, 276)
			arg_770_0.Location = location
			AddressOf Me.CheckBox3.Name = "CheckBox3"
			Dim arg_798_0 As Control = AddressOf Me.CheckBox3
			size = New Size(74, 17)
			arg_798_0.Size = size
			AddressOf Me.CheckBox3.TabIndex = 35
			AddressOf Me.CheckBox3.Text = "Startmenü"
			AddressOf Me.CheckBox3.UseVisualStyleBackColor = True
			AddressOf Me.Button8.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button8.FlatStyle = FlatStyle.Flat
			Dim arg_7F7_0 As Control = AddressOf Me.Button8
			location = New Point(185, 261)
			arg_7F7_0.Location = location
			AddressOf Me.Button8.Name = "Button8"
			Dim arg_81F_0 As Control = AddressOf Me.Button8
			size = New Size(76, 32)
			arg_81F_0.Size = size
			AddressOf Me.Button8.TabIndex = 34
			AddressOf Me.Button8.Text = "Beenden"
			AddressOf Me.Button8.UseVisualStyleBackColor = True
			AddressOf Me.Button2.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button2.ImageAlign = ContentAlignment.TopLeft
			Dim arg_877_0 As Control = AddressOf Me.Button2
			location = New Point(40, 45)
			arg_877_0.Location = location
			AddressOf Me.Button2.Name = "Button2"
			Dim arg_8A2_0 As Control = AddressOf Me.Button2
			size = New Size(221, 25)
			arg_8A2_0.Size = size
			AddressOf Me.Button2.TabIndex = 22
			AddressOf Me.Button2.Text = "SkyWeb Evoro"
			AddressOf Me.Button2.UseVisualStyleBackColor = True
			AddressOf Me.Button7.FlatStyle = FlatStyle.Flat
			Dim arg_8F1_0 As Control = AddressOf Me.Button7
			location = New Point(40, 231)
			arg_8F1_0.Location = location
			AddressOf Me.Button7.Name = "Button7"
			Dim arg_91C_0 As Control = AddressOf Me.Button7
			size = New Size(221, 25)
			arg_91C_0.Size = size
			AddressOf Me.Button7.TabIndex = 32
			AddressOf Me.Button7.Text = "Options"
			AddressOf Me.Button7.UseVisualStyleBackColor = True
			AddressOf Me.Button6.FlatStyle = FlatStyle.Flat
			Dim arg_96B_0 As Control = AddressOf Me.Button6
			location = New Point(40, 169)
			arg_96B_0.Location = location
			AddressOf Me.Button6.Name = "Button6"
			Dim arg_996_0 As Control = AddressOf Me.Button6
			size = New Size(221, 25)
			arg_996_0.Size = size
			AddressOf Me.Button6.TabIndex = 26
			AddressOf Me.Button6.Text = "EvoPlayer"
			AddressOf Me.Button6.UseVisualStyleBackColor = True
			AddressOf Me.Button5.FlatStyle = FlatStyle.Flat
			Dim arg_9E5_0 As Control = AddressOf Me.Button5
			location = New Point(40, 138)
			arg_9E5_0.Location = location
			AddressOf Me.Button5.Name = "Button5"
			Dim arg_A10_0 As Control = AddressOf Me.Button5
			size = New Size(221, 25)
			arg_A10_0.Size = size
			AddressOf Me.Button5.TabIndex = 25
			AddressOf Me.Button5.Text = "GreenStart"
			AddressOf Me.Button5.UseVisualStyleBackColor = True
			AddressOf Me.Button4.FlatStyle = FlatStyle.Flat
			Dim arg_A5C_0 As Control = AddressOf Me.Button4
			location = New Point(40, 107)
			arg_A5C_0.Location = location
			AddressOf Me.Button4.Name = "Button4"
			Dim arg_A87_0 As Control = AddressOf Me.Button4
			size = New Size(221, 25)
			arg_A87_0.Size = size
			AddressOf Me.Button4.TabIndex = 24
			AddressOf Me.Button4.Text = "Evoxplorer"
			AddressOf Me.Button4.UseVisualStyleBackColor = True
			AddressOf Me.Button3.FlatStyle = FlatStyle.Flat
			Dim arg_AD3_0 As Control = AddressOf Me.Button3
			location = New Point(40, 76)
			arg_AD3_0.Location = location
			AddressOf Me.Button3.Name = "Button3"
			Dim arg_AFE_0 As Control = AddressOf Me.Button3
			size = New Size(221, 25)
			arg_AFE_0.Size = size
			AddressOf Me.Button3.TabIndex = 23
			AddressOf Me.Button3.Text = "Texter Evoro"
			AddressOf Me.Button3.UseVisualStyleBackColor = True
			AddressOf Me.CheckBox2.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.CheckBox2.AutoSize = True
			AddressOf Me.CheckBox2.Checked = True
			AddressOf Me.CheckBox2.CheckState = CheckState.Checked
			Dim arg_B72_0 As Control = AddressOf Me.CheckBox2
			location = New Point(40, 261)
			arg_B72_0.Location = location
			AddressOf Me.CheckBox2.Name = "CheckBox2"
			Dim arg_B9A_0 As Control = AddressOf Me.CheckBox2
			size = New Size(71, 17)
			arg_B9A_0.Size = size
			AddressOf Me.CheckBox2.TabIndex = 21
			AddressOf Me.CheckBox2.Text = "Statusbar"
			AddressOf Me.CheckBox2.UseVisualStyleBackColor = True
			AddressOf Me.CheckBox1.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.CheckBox1.AutoSize = True
			AddressOf Me.CheckBox1.Checked = True
			AddressOf Me.CheckBox1.CheckState = CheckState.Checked
			Dim arg_C0E_0 As Control = AddressOf Me.CheckBox1
			location = New Point(117, 261)
			arg_C0E_0.Location = location
			AddressOf Me.CheckBox1.Name = "CheckBox1"
			Dim arg_C36_0 As Control = AddressOf Me.CheckBox1
			size = New Size(62, 17)
			arg_C36_0.Size = size
			AddressOf Me.CheckBox1.TabIndex = 20
			AddressOf Me.CheckBox1.Text = "Toolbar"
			AddressOf Me.CheckBox1.UseVisualStyleBackColor = True
			AddressOf Me.Label1.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label1.AutoSize = True
			AddressOf Me.Label1.BackColor = Color.Red
			AddressOf Me.Label1.ForeColor = Color.White
			Dim arg_CB5_0 As Control = AddressOf Me.Label1
			location = New Point(1369, 579)
			arg_CB5_0.Location = location
			AddressOf Me.Label1.Name = "Label1"
			Dim arg_CDD_0 As Control = AddressOf Me.Label1
			size = New Size(13, 13)
			arg_CDD_0.Size = size
			AddressOf Me.Label1.TabIndex = 9
			AddressOf Me.Label1.Text = "F"
			AddressOf Me.Label2.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label2.AutoSize = True
			AddressOf Me.Label2.BackColor = Color.Red
			AddressOf Me.Label2.ForeColor = Color.White
			Dim arg_D50_0 As Control = AddressOf Me.Label2
			location = New Point(1350, 579)
			arg_D50_0.Location = location
			AddressOf Me.Label2.Name = "Label2"
			Dim arg_D78_0 As Control = AddressOf Me.Label2
			size = New Size(13, 13)
			arg_D78_0.Size = size
			AddressOf Me.Label2.TabIndex = 11
			AddressOf Me.Label2.Text = "F"
			AddressOf Me.Label3.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label3.AutoSize = True
			AddressOf Me.Label3.BackColor = Color.Red
			AddressOf Me.Label3.ForeColor = Color.White
			Dim arg_DEB_0 As Control = AddressOf Me.Label3
			location = New Point(1331, 579)
			arg_DEB_0.Location = location
			AddressOf Me.Label3.Name = "Label3"
			Dim arg_E13_0 As Control = AddressOf Me.Label3
			size = New Size(13, 13)
			arg_E13_0.Size = size
			AddressOf Me.Label3.TabIndex = 12
			AddressOf Me.Label3.Text = "F"
			AddressOf Me.Label4.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label4.AutoSize = True
			AddressOf Me.Label4.BackColor = Color.Red
			AddressOf Me.Label4.ForeColor = Color.White
			Dim arg_E86_0 As Control = AddressOf Me.Label4
			location = New Point(1312, 579)
			arg_E86_0.Location = location
			AddressOf Me.Label4.Name = "Label4"
			Dim arg_EAE_0 As Control = AddressOf Me.Label4
			size = New Size(13, 13)
			arg_EAE_0.Size = size
			AddressOf Me.Label4.TabIndex = 13
			AddressOf Me.Label4.Text = "F"
			AddressOf Me.Label5.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label5.AutoSize = True
			AddressOf Me.Label5.BackColor = Color.Red
			AddressOf Me.Label5.ForeColor = Color.White
			Dim arg_F21_0 As Control = AddressOf Me.Label5
			location = New Point(1293, 579)
			arg_F21_0.Location = location
			AddressOf Me.Label5.Name = "Label5"
			Dim arg_F49_0 As Control = AddressOf Me.Label5
			size = New Size(13, 13)
			arg_F49_0.Size = size
			AddressOf Me.Label5.TabIndex = 17
			AddressOf Me.Label5.Text = "F"
			AddressOf Me.Label8.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label8.AutoSize = True
			AddressOf Me.Label8.BackColor = Color.Red
			AddressOf Me.Label8.ForeColor = Color.White
			Dim arg_FBC_0 As Control = AddressOf Me.Label8
			location = New Point(1274, 579)
			arg_FBC_0.Location = location
			AddressOf Me.Label8.Name = "Label8"
			Dim arg_FE4_0 As Control = AddressOf Me.Label8
			size = New Size(13, 13)
			arg_FE4_0.Size = size
			AddressOf Me.Label8.TabIndex = 24
			AddressOf Me.Label8.Text = "F"
			AddressOf Me.Button1.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button1.BackColor = Color.Black
			AddressOf Me.Button1.BackgroundImage = AddressOf Resources.SkyVOSBig
			AddressOf Me.Button1.BackgroundImageLayout = ImageLayout.Zoom
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			AddressOf Me.Button1.ForeColor = Color.Black
			Dim arg_106F_0 As Control = AddressOf Me.Button1
			location = New Point(12, 516)
			arg_106F_0.Location = location
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_1097_0 As Control = AddressOf Me.Button1
			size = New Size(75, 75)
			arg_1097_0.Size = size
			AddressOf Me.Button1.TabIndex = 20
			AddressOf Me.Button1.UseVisualStyleBackColor = False
			AddressOf Me.PictureBox7.BackgroundImage = AddressOf Resources.Painter
			AddressOf Me.PictureBox7.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_10E5_0 As Control = AddressOf Me.PictureBox7
			location = New Point(3, 200)
			arg_10E5_0.Location = location
			AddressOf Me.PictureBox7.Name = "PictureBox7"
			Dim arg_110D_0 As Control = AddressOf Me.PictureBox7
			size = New Size(31, 25)
			arg_110D_0.Size = size
			AddressOf Me.PictureBox7.TabIndex = 36
			AddressOf Me.PictureBox7.TabStop = False
			AddressOf Me.PictureBox1.BackgroundImage = AddressOf Resources.Inet
			AddressOf Me.PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_1158_0 As Control = AddressOf Me.PictureBox1
			location = New Point(3, 45)
			arg_1158_0.Location = location
			AddressOf Me.PictureBox1.Name = "PictureBox1"
			Dim arg_1180_0 As Control = AddressOf Me.PictureBox1
			size = New Size(31, 25)
			arg_1180_0.Size = size
			AddressOf Me.PictureBox1.TabIndex = 27
			AddressOf Me.PictureBox1.TabStop = False
			AddressOf Me.Panel2.BackColor = Color.FromArgb(64, 64, 64)
			AddressOf Me.Panel2.BackgroundImage = AddressOf Resources.Farbverlauf
			AddressOf Me.Panel2.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Panel2.Controls.Add(AddressOf Me.Label7)
			AddressOf Me.Panel2.Controls.Add(AddressOf Me.Label6)
			Dim arg_120C_0 As Control = AddressOf Me.Panel2
			location = New Point(-1, -1)
			arg_120C_0.Location = location
			AddressOf Me.Panel2.Name = "Panel2"
			Dim arg_1237_0 As Control = AddressOf Me.Panel2
			size = New Size(266, 48)
			arg_1237_0.Size = size
			AddressOf Me.Panel2.TabIndex = 23
			AddressOf Me.Label7.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Label7.AutoSize = True
			AddressOf Me.Label7.BackColor = Color.Transparent
			AddressOf Me.Label7.Font = New Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Dim arg_12A0_0 As Control = AddressOf Me.Label7
			location = New Point(3, 21)
			arg_12A0_0.Location = location
			AddressOf Me.Label7.Name = "Label7"
			Dim arg_12C8_0 As Control = AddressOf Me.Label7
			size = New Size(95, 21)
			arg_12C8_0.Size = size
			AddressOf Me.Label7.TabIndex = 19
			AddressOf Me.Label7.Text = "Es ist ... Uhr."
			AddressOf Me.Label6.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Label6.AutoSize = True
			AddressOf Me.Label6.BackColor = Color.Transparent
			AddressOf Me.Label6.Font = New Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Dim arg_1340_0 As Control = AddressOf Me.Label6
			location = New Point(3, 0)
			arg_1340_0.Location = location
			AddressOf Me.Label6.Name = "Label6"
			Dim arg_136B_0 As Control = AddressOf Me.Label6
			size = New Size(146, 21)
			arg_136B_0.Size = size
			AddressOf Me.Label6.TabIndex = 18
			AddressOf Me.Label6.Text = "Willkommen, User!"
			AddressOf Me.PictureBox6.BackgroundImage = AddressOf Resources._Option
			AddressOf Me.PictureBox6.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_13BD_0 As Control = AddressOf Me.PictureBox6
			location = New Point(3, 230)
			arg_13BD_0.Location = location
			AddressOf Me.PictureBox6.Name = "PictureBox6"
			Dim arg_13E5_0 As Control = AddressOf Me.PictureBox6
			size = New Size(31, 25)
			arg_13E5_0.Size = size
			AddressOf Me.PictureBox6.TabIndex = 33
			AddressOf Me.PictureBox6.TabStop = False
			AddressOf Me.PictureBox5.BackgroundImage = AddressOf Resources.Player
			AddressOf Me.PictureBox5.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_1433_0 As Control = AddressOf Me.PictureBox5
			location = New Point(3, 169)
			arg_1433_0.Location = location
			AddressOf Me.PictureBox5.Name = "PictureBox5"
			Dim arg_145B_0 As Control = AddressOf Me.PictureBox5
			size = New Size(31, 25)
			arg_145B_0.Size = size
			AddressOf Me.PictureBox5.TabIndex = 31
			AddressOf Me.PictureBox5.TabStop = False
			AddressOf Me.PictureBox4.BackgroundImage = AddressOf Resources.SkyVOSBig
			AddressOf Me.PictureBox4.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_14A9_0 As Control = AddressOf Me.PictureBox4
			location = New Point(3, 138)
			arg_14A9_0.Location = location
			AddressOf Me.PictureBox4.Name = "PictureBox4"
			Dim arg_14D1_0 As Control = AddressOf Me.PictureBox4
			size = New Size(31, 25)
			arg_14D1_0.Size = size
			AddressOf Me.PictureBox4.TabIndex = 30
			AddressOf Me.PictureBox4.TabStop = False
			AddressOf Me.PictureBox3.BackgroundImage = AddressOf Resources.Open
			AddressOf Me.PictureBox3.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_151C_0 As Control = AddressOf Me.PictureBox3
			location = New Point(3, 107)
			arg_151C_0.Location = location
			AddressOf Me.PictureBox3.Name = "PictureBox3"
			Dim arg_1544_0 As Control = AddressOf Me.PictureBox3
			size = New Size(31, 25)
			arg_1544_0.Size = size
			AddressOf Me.PictureBox3.TabIndex = 29
			AddressOf Me.PictureBox3.TabStop = False
			AddressOf Me.PictureBox2.BackgroundImage = AddressOf Resources.Texter
			AddressOf Me.PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_158F_0 As Control = AddressOf Me.PictureBox2
			location = New Point(3, 76)
			arg_158F_0.Location = location
			AddressOf Me.PictureBox2.Name = "PictureBox2"
			Dim arg_15B7_0 As Control = AddressOf Me.PictureBox2
			size = New Size(31, 25)
			arg_15B7_0.Size = size
			AddressOf Me.PictureBox2.TabIndex = 28
			AddressOf Me.PictureBox2.TabStop = False
			AddressOf Me.ToolStrip.BackColor = Color.Black
			AddressOf Me.ToolStrip.BackgroundImage = AddressOf Resources.VerlaufGrau1
			AddressOf Me.ToolStrip.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.ToolStrip.Items.AddRange(New ToolStripItem()() { AddressOf Me.ToolStripButton1, AddressOf Me.ToolStripButton2, AddressOf Me.ToolStripButton3, AddressOf Me.ToolStripButton4, AddressOf Me.ToolStripButton5, AddressOf Me.ToolStripButton6 })
			Dim arg_1668_0 As Control = AddressOf Me.ToolStrip
			location = New Point(0, 28)
			arg_1668_0.Location = location
			AddressOf Me.ToolStrip.Name = "ToolStrip"
			Dim arg_1693_0 As Control = AddressOf Me.ToolStrip
			size = New Size(1394, 25)
			arg_1693_0.Size = size
			AddressOf Me.ToolStrip.TabIndex = 6
			AddressOf Me.ToolStrip.Text = "ToolStrip"
			AddressOf Me.ToolStripButton1.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), Image)
			AddressOf Me.ToolStripButton1.ImageTransparentColor = Color.Black
			AddressOf Me.ToolStripButton1.Name = "ToolStripButton1"
			Dim arg_170E_0 As ToolStripItem = AddressOf Me.ToolStripButton1
			size = New Size(23, 22)
			arg_170E_0.Size = size
			AddressOf Me.ToolStripButton1.Text = "SkyWeb Evoro"
			AddressOf Me.ToolStripButton2.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), Image)
			AddressOf Me.ToolStripButton2.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton2.Name = "ToolStripButton2"
			Dim arg_177D_0 As ToolStripItem = AddressOf Me.ToolStripButton2
			size = New Size(23, 22)
			arg_177D_0.Size = size
			AddressOf Me.ToolStripButton2.Text = "Texter Evoro"
			AddressOf Me.ToolStripButton3.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton3.Image = CType(resources.GetObject("ToolStripButton3.Image"), Image)
			AddressOf Me.ToolStripButton3.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton3.Name = "ToolStripButton3"
			Dim arg_17EC_0 As ToolStripItem = AddressOf Me.ToolStripButton3
			size = New Size(23, 22)
			arg_17EC_0.Size = size
			AddressOf Me.ToolStripButton3.Text = "Evoxplorer"
			AddressOf Me.ToolStripButton4.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton4.Image = AddressOf Resources.SkyVOSBig
			AddressOf Me.ToolStripButton4.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton4.Name = "ToolStripButton4"
			Dim arg_1850_0 As ToolStripItem = AddressOf Me.ToolStripButton4
			size = New Size(23, 22)
			arg_1850_0.Size = size
			AddressOf Me.ToolStripButton4.Text = "GreenStart"
			AddressOf Me.ToolStripButton5.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton5.Image = AddressOf Resources.Player
			AddressOf Me.ToolStripButton5.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton5.Name = "ToolStripButton5"
			Dim arg_18B4_0 As ToolStripItem = AddressOf Me.ToolStripButton5
			size = New Size(23, 22)
			arg_18B4_0.Size = size
			AddressOf Me.ToolStripButton5.Text = "Player"
			AddressOf Me.ToolStripButton6.DisplayStyle = ToolStripItemDisplayStyle.Image
			AddressOf Me.ToolStripButton6.Image = AddressOf Resources.Painter
			AddressOf Me.ToolStripButton6.ImageTransparentColor = Color.Magenta
			AddressOf Me.ToolStripButton6.Name = "ToolStripButton6"
			Dim arg_1918_0 As ToolStripItem = AddressOf Me.ToolStripButton6
			size = New Size(23, 22)
			arg_1918_0.Size = size
			AddressOf Me.ToolStripButton6.Text = "EvoPaint"
			AddressOf Me.MenuStrip.BackColor = Color.Transparent
			AddressOf Me.MenuStrip.BackgroundImage = AddressOf Resources.Farbverlauf3
			AddressOf Me.MenuStrip.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.MenuStrip.Items.AddRange(New ToolStripItem()() { AddressOf Me.ViewMenu, AddressOf Me.WindowsMenu, AddressOf Me.HelpMenu, AddressOf Me.ToolStripMenuItem2, AddressOf Me.BrowserToolStripMenuItem, AddressOf Me.TexteditorToolStripMenuItem, AddressOf Me.Ansicht2ToolStripMenuItem })
			Dim arg_19C9_0 As Control = AddressOf Me.MenuStrip
			location = New Point(0, 0)
			arg_19C9_0.Location = location
			AddressOf Me.MenuStrip.MdiWindowListItem = AddressOf Me.WindowsMenu
			AddressOf Me.MenuStrip.Name = "MenuStrip"
			Dim arg_1A05_0 As Control = AddressOf Me.MenuStrip
			size = New Size(1394, 28)
			arg_1A05_0.Size = size
			AddressOf Me.MenuStrip.TabIndex = 5
			AddressOf Me.MenuStrip.Text = "MenuStrip"
			AddressOf Me.ViewMenu.BackColor = Color.Transparent
			AddressOf Me.ViewMenu.DropDownItems.AddRange(New ToolStripItem()() { AddressOf Me.ToolBarToolStripMenuItem, AddressOf Me.StatusBarToolStripMenuItem, AddressOf Me.StartmenüToolStripMenuItem })
			AddressOf Me.ViewMenu.Font = New Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.ViewMenu.ForeColor = Color.White
			AddressOf Me.ViewMenu.Name = "ViewMenu"
			Dim arg_1ABE_0 As ToolStripItem = AddressOf Me.ViewMenu
			size = New Size(74, 24)
			arg_1ABE_0.Size = size
			AddressOf Me.ViewMenu.Text = "&Ansicht"
			AddressOf Me.ToolBarToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.ToolBarToolStripMenuItem.Checked = True
			AddressOf Me.ToolBarToolStripMenuItem.CheckOnClick = True
			AddressOf Me.ToolBarToolStripMenuItem.CheckState = CheckState.Checked
			AddressOf Me.ToolBarToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.ToolBarToolStripMenuItem.Name = "ToolBarToolStripMenuItem"
			Dim arg_1B3D_0 As ToolStripItem = AddressOf Me.ToolBarToolStripMenuItem
			size = New Size(166, 24)
			arg_1B3D_0.Size = size
			AddressOf Me.ToolBarToolStripMenuItem.Text = "&Symbolleiste"
			AddressOf Me.StatusBarToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.StatusBarToolStripMenuItem.Checked = True
			AddressOf Me.StatusBarToolStripMenuItem.CheckOnClick = True
			AddressOf Me.StatusBarToolStripMenuItem.CheckState = CheckState.Checked
			AddressOf Me.StatusBarToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.StatusBarToolStripMenuItem.Name = "StatusBarToolStripMenuItem"
			Dim arg_1BBC_0 As ToolStripItem = AddressOf Me.StatusBarToolStripMenuItem
			size = New Size(166, 24)
			arg_1BBC_0.Size = size
			AddressOf Me.StatusBarToolStripMenuItem.Text = "Status&leiste"
			AddressOf Me.StartmenüToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.StartmenüToolStripMenuItem.Checked = True
			AddressOf Me.StartmenüToolStripMenuItem.CheckOnClick = True
			AddressOf Me.StartmenüToolStripMenuItem.CheckState = CheckState.Checked
			AddressOf Me.StartmenüToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.StartmenüToolStripMenuItem.Name = "StartmenüToolStripMenuItem"
			Dim arg_1C3B_0 As ToolStripItem = AddressOf Me.StartmenüToolStripMenuItem
			size = New Size(166, 24)
			arg_1C3B_0.Size = size
			AddressOf Me.StartmenüToolStripMenuItem.Text = "Startmenü"
			AddressOf Me.WindowsMenu.BackColor = Color.Transparent
			AddressOf Me.WindowsMenu.DropDownItems.AddRange(New ToolStripItem()() { AddressOf Me.NewWindowToolStripMenuItem, AddressOf Me.CascadeToolStripMenuItem, AddressOf Me.TileVerticalToolStripMenuItem, AddressOf Me.TileHorizontalToolStripMenuItem, AddressOf Me.CloseAllToolStripMenuItem, AddressOf Me.ArrangeIconsToolStripMenuItem })
			AddressOf Me.WindowsMenu.Font = New Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.WindowsMenu.ForeColor = Color.White
			AddressOf Me.WindowsMenu.Name = "WindowsMenu"
			Dim arg_1D06_0 As ToolStripItem = AddressOf Me.WindowsMenu
			size = New Size(73, 24)
			arg_1D06_0.Size = size
			AddressOf Me.WindowsMenu.Text = "&Fenster"
			AddressOf Me.NewWindowToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.NewWindowToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.NewWindowToolStripMenuItem.Name = "NewWindowToolStripMenuItem"
			Dim arg_1D61_0 As ToolStripItem = AddressOf Me.NewWindowToolStripMenuItem
			size = New Size(215, 24)
			arg_1D61_0.Size = size
			AddressOf Me.NewWindowToolStripMenuItem.Text = "&Neues Fenster"
			AddressOf Me.CascadeToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.CascadeToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.CascadeToolStripMenuItem.Name = "CascadeToolStripMenuItem"
			Dim arg_1DBC_0 As ToolStripItem = AddressOf Me.CascadeToolStripMenuItem
			size = New Size(215, 24)
			arg_1DBC_0.Size = size
			AddressOf Me.CascadeToolStripMenuItem.Text = "Ü&berlappend"
			AddressOf Me.TileVerticalToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.TileVerticalToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.TileVerticalToolStripMenuItem.Name = "TileVerticalToolStripMenuItem"
			Dim arg_1E17_0 As ToolStripItem = AddressOf Me.TileVerticalToolStripMenuItem
			size = New Size(215, 24)
			arg_1E17_0.Size = size
			AddressOf Me.TileVerticalToolStripMenuItem.Text = "&Nebeneinander"
			AddressOf Me.TileHorizontalToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.TileHorizontalToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.TileHorizontalToolStripMenuItem.Name = "TileHorizontalToolStripMenuItem"
			Dim arg_1E72_0 As ToolStripItem = AddressOf Me.TileHorizontalToolStripMenuItem
			size = New Size(215, 24)
			arg_1E72_0.Size = size
			AddressOf Me.TileHorizontalToolStripMenuItem.Text = "&Untereinander"
			AddressOf Me.CloseAllToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.CloseAllToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.CloseAllToolStripMenuItem.Name = "CloseAllToolStripMenuItem"
			Dim arg_1ECD_0 As ToolStripItem = AddressOf Me.CloseAllToolStripMenuItem
			size = New Size(215, 24)
			arg_1ECD_0.Size = size
			AddressOf Me.CloseAllToolStripMenuItem.Text = "&Alle schließen"
			AddressOf Me.ArrangeIconsToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.ArrangeIconsToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.ArrangeIconsToolStripMenuItem.Name = "ArrangeIconsToolStripMenuItem"
			Dim arg_1F28_0 As ToolStripItem = AddressOf Me.ArrangeIconsToolStripMenuItem
			size = New Size(215, 24)
			arg_1F28_0.Size = size
			AddressOf Me.ArrangeIconsToolStripMenuItem.Text = "Symbole &anordnen"
			AddressOf Me.HelpMenu.BackColor = Color.Transparent
			AddressOf Me.HelpMenu.DropDownItems.AddRange(New ToolStripItem()() { AddressOf Me.ContentsToolStripMenuItem, AddressOf Me.IndexToolStripMenuItem, AddressOf Me.SearchToolStripMenuItem, AddressOf Me.ToolStripSeparator8, AddressOf Me.AboutToolStripMenuItem })
			AddressOf Me.HelpMenu.Font = New Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.HelpMenu.ForeColor = Color.White
			AddressOf Me.HelpMenu.Name = "HelpMenu"
			Dim arg_1FE9_0 As ToolStripItem = AddressOf Me.HelpMenu
			size = New Size(52, 24)
			arg_1FE9_0.Size = size
			AddressOf Me.HelpMenu.Text = "&Hilfe"
			AddressOf Me.ContentsToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.ContentsToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.ContentsToolStripMenuItem.Name = "ContentsToolStripMenuItem"
			AddressOf Me.ContentsToolStripMenuItem.ShortcutKeys = CType(131184, Keys)
			Dim arg_2054_0 As ToolStripItem = AddressOf Me.ContentsToolStripMenuItem
			size = New Size(179, 24)
			arg_2054_0.Size = size
			AddressOf Me.ContentsToolStripMenuItem.Text = "&Inhalt"
			AddressOf Me.IndexToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.IndexToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.IndexToolStripMenuItem.Image = CType(resources.GetObject("IndexToolStripMenuItem.Image"), Image)
			AddressOf Me.IndexToolStripMenuItem.ImageTransparentColor = Color.Black
			AddressOf Me.IndexToolStripMenuItem.Name = "IndexToolStripMenuItem"
			Dim arg_20DA_0 As ToolStripItem = AddressOf Me.IndexToolStripMenuItem
			size = New Size(179, 24)
			arg_20DA_0.Size = size
			AddressOf Me.IndexToolStripMenuItem.Text = "&Index"
			AddressOf Me.SearchToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.SearchToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.SearchToolStripMenuItem.Image = CType(resources.GetObject("SearchToolStripMenuItem.Image"), Image)
			AddressOf Me.SearchToolStripMenuItem.ImageTransparentColor = Color.Black
			AddressOf Me.SearchToolStripMenuItem.Name = "SearchToolStripMenuItem"
			Dim arg_2160_0 As ToolStripItem = AddressOf Me.SearchToolStripMenuItem
			size = New Size(179, 24)
			arg_2160_0.Size = size
			AddressOf Me.SearchToolStripMenuItem.Text = "&Suchen"
			AddressOf Me.ToolStripSeparator8.BackColor = Color.Black
			AddressOf Me.ToolStripSeparator8.ForeColor = Color.White
			AddressOf Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
			Dim arg_21BA_0 As ToolStripItem = AddressOf Me.ToolStripSeparator8
			size = New Size(176, 6)
			arg_21BA_0.Size = size
			AddressOf Me.AboutToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.AboutToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
			Dim arg_2205_0 As ToolStripItem = AddressOf Me.AboutToolStripMenuItem
			size = New Size(179, 24)
			arg_2205_0.Size = size
			AddressOf Me.AboutToolStripMenuItem.Text = "&Info..."
			AddressOf Me.ToolStripMenuItem2.BackColor = Color.Transparent
			AddressOf Me.ToolStripMenuItem2.Font = New Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.ToolStripMenuItem2.ForeColor = Color.White
			AddressOf Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
			Dim arg_227A_0 As ToolStripItem = AddressOf Me.ToolStripMenuItem2
			size = New Size(115, 24)
			arg_227A_0.Size = size
			AddressOf Me.ToolStripMenuItem2.Text = "&Einstellungen"
			AddressOf Me.BrowserToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem()() { AddressOf Me.LosToolStripMenuItem, AddressOf Me.ToolStripSeparator1, AddressOf Me.NächsteSeiteToolStripMenuItem, AddressOf Me.VorherigeSeiteToolStripMenuItem, AddressOf Me.NeuLadenToolStripMenuItem, AddressOf Me.LadenAnhaltenToolStripMenuItem })
			AddressOf Me.BrowserToolStripMenuItem.Font = New Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.BrowserToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.BrowserToolStripMenuItem.Name = "BrowserToolStripMenuItem"
			Dim arg_2335_0 As ToolStripItem = AddressOf Me.BrowserToolStripMenuItem
			size = New Size(80, 24)
			arg_2335_0.Size = size
			AddressOf Me.BrowserToolStripMenuItem.Text = "&Browser"
			AddressOf Me.BrowserToolStripMenuItem.Visible = False
			AddressOf Me.LosToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.LosToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.LosToolStripMenuItem.Name = "LosToolStripMenuItem"
			AddressOf Me.LosToolStripMenuItem.ShortcutKeys = CType(131155, Keys)
			Dim arg_23AC_0 As ToolStripItem = AddressOf Me.LosToolStripMenuItem
			size = New Size(193, 24)
			arg_23AC_0.Size = size
			AddressOf Me.LosToolStripMenuItem.Text = "Suchen"
			AddressOf Me.ToolStripSeparator1.BackColor = Color.Black
			AddressOf Me.ToolStripSeparator1.ForeColor = Color.White
			AddressOf Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
			Dim arg_2406_0 As ToolStripItem = AddressOf Me.ToolStripSeparator1
			size = New Size(190, 6)
			arg_2406_0.Size = size
			AddressOf Me.NächsteSeiteToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.NächsteSeiteToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.NächsteSeiteToolStripMenuItem.Name = "NächsteSeiteToolStripMenuItem"
			Dim arg_2451_0 As ToolStripItem = AddressOf Me.NächsteSeiteToolStripMenuItem
			size = New Size(193, 24)
			arg_2451_0.Size = size
			AddressOf Me.NächsteSeiteToolStripMenuItem.Text = "Nächste Seite"
			AddressOf Me.VorherigeSeiteToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.VorherigeSeiteToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.VorherigeSeiteToolStripMenuItem.Name = "VorherigeSeiteToolStripMenuItem"
			Dim arg_24AC_0 As ToolStripItem = AddressOf Me.VorherigeSeiteToolStripMenuItem
			size = New Size(193, 24)
			arg_24AC_0.Size = size
			AddressOf Me.VorherigeSeiteToolStripMenuItem.Text = "Vorherige Seite"
			AddressOf Me.NeuLadenToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.NeuLadenToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.NeuLadenToolStripMenuItem.Name = "NeuLadenToolStripMenuItem"
			Dim arg_2507_0 As ToolStripItem = AddressOf Me.NeuLadenToolStripMenuItem
			size = New Size(193, 24)
			arg_2507_0.Size = size
			AddressOf Me.NeuLadenToolStripMenuItem.Text = "Neu Laden"
			AddressOf Me.LadenAnhaltenToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.LadenAnhaltenToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.LadenAnhaltenToolStripMenuItem.Name = "LadenAnhaltenToolStripMenuItem"
			Dim arg_2562_0 As ToolStripItem = AddressOf Me.LadenAnhaltenToolStripMenuItem
			size = New Size(193, 24)
			arg_2562_0.Size = size
			AddressOf Me.LadenAnhaltenToolStripMenuItem.Text = "Laden anhalten"
			AddressOf Me.TexteditorToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem()() { AddressOf Me.RückgängigToolStripMenuItem, AddressOf Me.WiederholenToolStripMenuItem, AddressOf Me.ToolStripSeparator2, AddressOf Me.KopierenToolStripMenuItem, AddressOf Me.EinfügenToolStripMenuItem, AddressOf Me.AusschneidenToolStripMenuItem, AddressOf Me.ToolStripMenuItem1, AddressOf Me.AllesAuswählenToolStripMenuItem })
			AddressOf Me.TexteditorToolStripMenuItem.Font = New Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.TexteditorToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.TexteditorToolStripMenuItem.Name = "TexteditorToolStripMenuItem"
			Dim arg_2631_0 As ToolStripItem = AddressOf Me.TexteditorToolStripMenuItem
			size = New Size(91, 24)
			arg_2631_0.Size = size
			AddressOf Me.TexteditorToolStripMenuItem.Text = "&Texteditor"
			AddressOf Me.TexteditorToolStripMenuItem.Visible = False
			AddressOf Me.RückgängigToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.RückgängigToolStripMenuItem.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.RückgängigToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.RückgängigToolStripMenuItem.Name = "RückgängigToolStripMenuItem"
			Dim arg_26A4_0 As ToolStripItem = AddressOf Me.RückgängigToolStripMenuItem
			size = New Size(195, 24)
			arg_26A4_0.Size = size
			AddressOf Me.RückgängigToolStripMenuItem.Text = "Rückgängig"
			AddressOf Me.WiederholenToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.WiederholenToolStripMenuItem.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.WiederholenToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.WiederholenToolStripMenuItem.Name = "WiederholenToolStripMenuItem"
			Dim arg_270B_0 As ToolStripItem = AddressOf Me.WiederholenToolStripMenuItem
			size = New Size(195, 24)
			arg_270B_0.Size = size
			AddressOf Me.WiederholenToolStripMenuItem.Text = "Wiederholen"
			AddressOf Me.ToolStripSeparator2.BackColor = Color.Black
			AddressOf Me.ToolStripSeparator2.ForeColor = Color.White
			AddressOf Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
			Dim arg_2765_0 As ToolStripItem = AddressOf Me.ToolStripSeparator2
			size = New Size(192, 6)
			arg_2765_0.Size = size
			AddressOf Me.KopierenToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.KopierenToolStripMenuItem.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.KopierenToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.KopierenToolStripMenuItem.Name = "KopierenToolStripMenuItem"
			Dim arg_27BC_0 As ToolStripItem = AddressOf Me.KopierenToolStripMenuItem
			size = New Size(195, 24)
			arg_27BC_0.Size = size
			AddressOf Me.KopierenToolStripMenuItem.Text = "Kopieren"
			AddressOf Me.EinfügenToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.EinfügenToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.EinfügenToolStripMenuItem.Name = "EinfügenToolStripMenuItem"
			Dim arg_2817_0 As ToolStripItem = AddressOf Me.EinfügenToolStripMenuItem
			size = New Size(195, 24)
			arg_2817_0.Size = size
			AddressOf Me.EinfügenToolStripMenuItem.Text = "Einfügen"
			AddressOf Me.AusschneidenToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.AusschneidenToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.AusschneidenToolStripMenuItem.Name = "AusschneidenToolStripMenuItem"
			Dim arg_2872_0 As ToolStripItem = AddressOf Me.AusschneidenToolStripMenuItem
			size = New Size(195, 24)
			arg_2872_0.Size = size
			AddressOf Me.AusschneidenToolStripMenuItem.Text = "Ausschneiden"
			AddressOf Me.ToolStripMenuItem1.BackColor = Color.Black
			AddressOf Me.ToolStripMenuItem1.ForeColor = Color.White
			AddressOf Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
			Dim arg_28CC_0 As ToolStripItem = AddressOf Me.ToolStripMenuItem1
			size = New Size(192, 6)
			arg_28CC_0.Size = size
			AddressOf Me.AllesAuswählenToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.AllesAuswählenToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.AllesAuswählenToolStripMenuItem.Name = "AllesAuswählenToolStripMenuItem"
			Dim arg_2917_0 As ToolStripItem = AddressOf Me.AllesAuswählenToolStripMenuItem
			size = New Size(195, 24)
			arg_2917_0.Size = size
			AddressOf Me.AllesAuswählenToolStripMenuItem.Text = "Alles auswählen"
			AddressOf Me.StatusStrip.BackColor = Color.Black
			AddressOf Me.StatusStrip.BackgroundImage = AddressOf Resources.VerlaufGrau1
			AddressOf Me.StatusStrip.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.StatusStrip.Items.AddRange(New ToolStripItem()() { AddressOf Me.ToolStripStatusLabel1, AddressOf Me.ToolStripStatusLabel })
			Dim arg_299A_0 As Control = AddressOf Me.StatusStrip
			location = New Point(0, 579)
			arg_299A_0.Location = location
			AddressOf Me.StatusStrip.Name = "StatusStrip"
			Dim arg_29C5_0 As Control = AddressOf Me.StatusStrip
			size = New Size(1394, 22)
			arg_29C5_0.Size = size
			AddressOf Me.StatusStrip.TabIndex = 7
			AddressOf Me.StatusStrip.Text = "StatusStrip"
			AddressOf Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
			Dim arg_2A0C_0 As ToolStripItem = AddressOf Me.ToolStripStatusLabel1
			size = New Size(142, 17)
			arg_2A0C_0.Size = size
			AddressOf Me.ToolStripStatusLabel1.Text = "                                          " & ChrW(9658)
			AddressOf Me.ToolStripStatusLabel.BackColor = Color.Transparent
			AddressOf Me.ToolStripStatusLabel.ForeColor = Color.White
			AddressOf Me.ToolStripStatusLabel.Name = "ToolStripStatusLabel"
			Dim arg_2A64_0 As ToolStripItem = AddressOf Me.ToolStripStatusLabel
			size = New Size(39, 17)
			arg_2A64_0.Size = size
			AddressOf Me.ToolStripStatusLabel.Text = "Status"
			AddressOf Me.Ansicht2ToolStripMenuItem.Font = New Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.Ansicht2ToolStripMenuItem.ForeColor = Color.White
			AddressOf Me.Ansicht2ToolStripMenuItem.Name = "Ansicht2ToolStripMenuItem"
			Dim arg_2AC9_0 As ToolStripItem = AddressOf Me.Ansicht2ToolStripMenuItem
			size = New Size(86, 24)
			arg_2AC9_0.Size = size
			AddressOf Me.Ansicht2ToolStripMenuItem.Text = "&Ansicht 2"
			Dim autoScaleDimensions As SizeF = New SizeF(6F, 13F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			Me.BackgroundImageLayout = ImageLayout.Stretch
			size = New Size(1394, 601)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.Label8)
			Me.Controls.Add(AddressOf Me.Button1)
			Me.Controls.Add(AddressOf Me.Panel1)
			Me.Controls.Add(AddressOf Me.Label5)
			Me.Controls.Add(AddressOf Me.Label4)
			Me.Controls.Add(AddressOf Me.Label3)
			Me.Controls.Add(AddressOf Me.Label2)
			Me.Controls.Add(AddressOf Me.Label1)
			Me.Controls.Add(AddressOf Me.ToolStrip)
			Me.Controls.Add(AddressOf Me.MenuStrip)
			Me.Controls.Add(AddressOf Me.StatusStrip)
			Me.DoubleBuffered = True
			Me.ForeColor = Color.White
			Me.Icon = CType(resources.GetObject("$this.Icon"), Icon)
			Me.IsMdiContainer = True
			Me.MainMenuStrip = AddressOf Me.MenuStrip
			Me.Name = "MDIParent1"
			Me.Text = "EvoroAMI"
			AddressOf Me.Panel1.ResumeLayout(False)
			AddressOf Me.Panel1.PerformLayout()
			(CType(AddressOf Me.PictureBox7, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).EndInit()
			AddressOf Me.Panel2.ResumeLayout(False)
			AddressOf Me.Panel2.PerformLayout()
			(CType(AddressOf Me.PictureBox6, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox5, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox4, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox3, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).EndInit()
			AddressOf Me.ToolStrip.ResumeLayout(False)
			AddressOf Me.ToolStrip.PerformLayout()
			AddressOf Me.MenuStrip.ResumeLayout(False)
			AddressOf Me.MenuStrip.PerformLayout()
			AddressOf Me.StatusStrip.ResumeLayout(False)
			AddressOf Me.StatusStrip.PerformLayout()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		Private Sub ShowNewForm(sender As Object, e As EventArgs)
			Dim ChildForm As Form = New Form()
			ChildForm.MdiParent = Me
			' The following expression was wrapped in a checked-statement
			Me.m_ChildFormNumber += 1
			ChildForm.Text = "Fenster " + Conversions.ToString(Me.m_ChildFormNumber)
			ChildForm.Show()
		End Sub

		Private Sub OpenFile(sender As Object, e As EventArgs)
			Dim OpenFileDialog As OpenFileDialog = New OpenFileDialog()
			OpenFileDialog.InitialDirectory = AddressOf MyProject.Computer.FileSystem.SpecialDirectories.MyDocuments
			OpenFileDialog.Filter = "Textdateien (*.txt)|*.txt|Alle Dateien (*.*)|*.*"
			If OpenFileDialog.ShowDialog(Me) = DialogResult.OK Then
				Dim FileName As String = OpenFileDialog.FileName
			End If
		End Sub

		Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Dim SaveFileDialog As SaveFileDialog = New SaveFileDialog()
			SaveFileDialog.InitialDirectory = AddressOf MyProject.Computer.FileSystem.SpecialDirectories.MyDocuments
			SaveFileDialog.Filter = "Textdateien (*.txt)|*.txt|Alle Dateien (*.*)|*.*"
			If SaveFileDialog.ShowDialog(Me) = DialogResult.OK Then
				Dim FileName As String = SaveFileDialog.FileName
			End If
		End Sub

		Private Sub ExitToolsStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub

		Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub ToolBarToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf Me.ToolStrip.Visible = AddressOf Me.ToolBarToolStripMenuItem.Checked
			AddressOf Me.CheckBox1.Checked = AddressOf Me.ToolBarToolStripMenuItem.Checked
		End Sub

		Private Sub StatusBarToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf Me.StatusStrip.Visible = AddressOf Me.StatusBarToolStripMenuItem.Checked
		End Sub

		Private Sub CascadeToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.LayoutMdi(MdiLayout.Cascade)
		End Sub

		Private Sub TileVerticalToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.LayoutMdi(MdiLayout.TileVertical)
		End Sub

		Private Sub TileHorizontalToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.LayoutMdi(MdiLayout.TileHorizontal)
		End Sub

		Private Sub ArrangeIconsToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.LayoutMdi(MdiLayout.ArrangeIcons)
		End Sub

		Private Sub CloseAllToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Dim mdiChildren As Form() = Me.MdiChildren
			' The following expression was wrapped in a checked-statement
			For i As Integer = 0 To mdiChildren.Length - 1
				Dim ChildForm As Form = mdiChildren(i)
				ChildForm.Close()
			Next
		End Sub

		Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label1.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Browser.MdiParent = Me
				AddressOf Me.BrowserToolStripMenuItem.Visible = True
				AddressOf AddressOf MyProject.Forms.Browser.Show()
				AddressOf Me.Label1.Text = "T"
				AddressOf Me.Label1.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("SkyWeb Evoro")
			Else
				AddressOf Me.Label1.Text = "T"
				AddressOf AddressOf MyProject.Forms.Browser.MdiParent = Me
				AddressOf Me.BrowserToolStripMenuItem.Visible = False
				AddressOf AddressOf MyProject.Forms.Browser.Hide()
				AddressOf Me.Label1.Text = "F"
				AddressOf Me.Label1.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("SkyWeb Evoro")
				Catch expr_103 As Exception
					ProjectData.SetProjectError(expr_103)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub OptionsToolStripMenuItem_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub NächsteSeiteToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Browser.WebBrowser1.GoForward()
		End Sub

		Private Sub VorherigeSeiteToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Browser.WebBrowser1.GoBack()
		End Sub

		Private Sub NeuLadenToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Browser.WebBrowser1.Refresh()
		End Sub

		Private Sub LadenAnhaltenToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Browser.WebBrowser1.[Stop]()
		End Sub

		Private Sub LosToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Browser.WebBrowser1.Navigate(AddressOf AddressOf AddressOf MyProject.Forms.Browser.TextBox1.Text)
		End Sub

		Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label2.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = Me
				AddressOf Me.TexteditorToolStripMenuItem.Visible = True
				AddressOf AddressOf MyProject.Forms.Texteditor.Show()
				AddressOf Me.Label2.Text = "T"
				AddressOf Me.Label2.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("Texter Evoro")
			Else
				AddressOf Me.Label2.Text = "T"
				AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = Me
				AddressOf Me.TexteditorToolStripMenuItem.Visible = False
				AddressOf AddressOf MyProject.Forms.Texteditor.Hide()
				AddressOf Me.Label2.Text = "F"
				AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.Clear()
				AddressOf Me.Label2.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("Texter Evoro")
				Catch expr_117 As Exception
					ProjectData.SetProjectError(expr_117)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label3.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Explorer.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Explorer.Show()
				AddressOf Me.Label3.Text = "T"
				AddressOf Me.Label3.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("Evoxplorer")
			Else
				AddressOf Me.Label3.Text = "T"
				AddressOf AddressOf MyProject.Forms.Explorer.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Explorer.Hide()
				AddressOf Me.Label3.Text = "F"
				AddressOf Me.Label3.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("Evoxplorer")
				Catch expr_E8 As Exception
					ProjectData.SetProjectError(expr_E8)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub ToolStripButton4_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label4.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.GreenStart.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.GreenStart.Show()
				AddressOf Me.Label4.Text = "T"
				AddressOf Me.Label4.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("GreenStart")
			Else
				AddressOf Me.Label4.Text = "T"
				AddressOf AddressOf MyProject.Forms.GreenStart.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.GreenStart.Hide()
				AddressOf Me.Label4.Text = "F"
				AddressOf Me.Label4.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("GreenStart")
				Catch expr_E8 As Exception
					ProjectData.SetProjectError(expr_E8)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub WiederholenToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.Redo()
		End Sub

		Private Sub RückgängigToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.Undo()
		End Sub

		Private Sub KopierenToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.Copy()
		End Sub

		Private Sub EinfügenToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.Paste()
		End Sub

		Private Sub AusschneidenToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.Cut()
		End Sub

		Private Sub AllesAuswählenToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.SelectAll()
		End Sub

		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			AddressOf Me.Label7.Text = "Es ist " + Conversions.ToString(DateAndTime.TimeOfDay) + " Uhr."
			If Not AddressOf AddressOf MyProject.Forms.Texteditor.Visible Then
				AddressOf Me.Label2.Text = "F"
				AddressOf Me.Label2.BackColor = Color.Red
			End If
			If Not AddressOf AddressOf MyProject.Forms.Browser.Visible Then
				AddressOf Me.Label1.Text = "F"
				AddressOf Me.Label1.BackColor = Color.Red
			End If
			If Not AddressOf AddressOf MyProject.Forms.Explorer.Visible Then
				AddressOf Me.Label3.Text = "F"
				AddressOf Me.Label3.BackColor = Color.Red
			End If
			If Not AddressOf AddressOf MyProject.Forms.GreenStart.Visible Then
				AddressOf Me.Label4.Text = "F"
				AddressOf Me.Label4.BackColor = Color.Red
			End If
			AddressOf Me.Label6.Text = "Willkommen " + AddressOf AddressOf MySettingsProperty.Settings.Username + "!"
		End Sub

		Private Sub Timer2_Tick(sender As Object, e As EventArgs)
			AddressOf Me.ToolTip1.SetToolTip(AddressOf Me.Label1, "SkyWeb Evoro")
			AddressOf Me.ToolTip.SetToolTip(AddressOf Me.Label2, "Texter Evoro")
			AddressOf Me.ToolTip2.SetToolTip(AddressOf Me.Label3, "Evoxplorer")
			AddressOf Me.ToolTip3.SetToolTip(AddressOf Me.Label4, "GreenStart")
			AddressOf Me.ToolTip4.SetToolTip(AddressOf Me.Label5, "Player")
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.Form2.Show()
		End Sub

		Private Sub ToolStripButton5_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label5.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Form2.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Form2.Show()
				AddressOf Me.Label5.Text = "T"
				AddressOf Me.Label5.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("EvoPlayer")
			Else
				If Operators.CompareString(AddressOf Me.Label5.Text, "T", False) = 0 Then
					AddressOf AddressOf MyProject.Forms.Form2.MdiParent = Me
					AddressOf AddressOf MyProject.Forms.Form2.Hide()
					AddressOf Me.Label5.Text = "F"
					AddressOf Me.Label5.BackColor = Color.Red
					Try
						AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("EvoPlayer")
					Catch expr_F4 As Exception
						ProjectData.SetProjectError(expr_F4)
						ProjectData.ClearProjectError()
					End Try
				End If
			End If
		End Sub

		Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Interaction.MsgBox("Enthällt:   Evoro Loader; Evoxplorer; EvoPlay; GMmods GreenStart; Texter Evoro; SkyWeb Evoro                                                                 Copyright © 2014 by Sky Super; Alias Mil Gaspar (sky.super.lp@gmail.com)", MsgBoxStyle.OkOnly, Nothing)
		End Sub

		Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.Options.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Options.Show()
		End Sub

		Private Sub MDIParent1_Load(sender As Object, e As EventArgs)
			Cursor.Show()
			AddressOf Me.Label1.Text = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label1.Text
			AddressOf Me.Label2.Text = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label2.Text
			AddressOf Me.Label3.Text = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label3.Text
			AddressOf Me.Label4.Text = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label4.Text
			AddressOf Me.Label5.Text = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label5.Text
			AddressOf Me.Label8.Text = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label8.Text
			AddressOf Me.Label1.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label1.BackColor
			AddressOf Me.Label2.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label2.BackColor
			AddressOf Me.Label3.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label3.BackColor
			AddressOf Me.Label4.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label4.BackColor
			AddressOf Me.Label5.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label5.BackColor
			AddressOf Me.Label8.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.Ansicht2.Label8.BackColor
			AddressOf AddressOf MyProject.Forms.Painter.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Explorer.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.GreenStart.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Options.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Form2.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = Me
		End Sub

		Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs)
			AddressOf Me.ToolStrip.Visible = AddressOf Me.CheckBox1.Checked
			AddressOf Me.ToolBarToolStripMenuItem.Checked = AddressOf Me.CheckBox1.Checked
		End Sub

		Private Sub Button1_Click_1(sender As Object, e As EventArgs)
			If Not AddressOf Me.Panel1.Visible Then
				AddressOf Me.Panel1.Visible = True
			Else
				AddressOf Me.Panel1.Visible = False
			End If
		End Sub

		Private Sub MDIParent1_MouseHover(sender As Object, e As EventArgs)
			AddressOf Me.Panel1.Visible = False
			AddressOf Me.StatusBarToolStripMenuItem.Checked = False
		End Sub

		Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs)
			AddressOf Me.StatusStrip.Visible = AddressOf Me.CheckBox2.Checked
			AddressOf Me.ToolBarToolStripMenuItem.Checked = AddressOf Me.CheckBox2.Checked
		End Sub

		Private Sub Button2_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label1.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Browser.MdiParent = Me
				AddressOf Me.BrowserToolStripMenuItem.Visible = True
				AddressOf AddressOf MyProject.Forms.Browser.Show()
				AddressOf Me.Label1.Text = "T"
				AddressOf Me.Label1.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("SkyWeb Evoro")
			Else
				AddressOf Me.Label1.Text = "T"
				AddressOf AddressOf MyProject.Forms.Browser.MdiParent = Me
				AddressOf Me.BrowserToolStripMenuItem.Visible = False
				AddressOf AddressOf MyProject.Forms.Browser.Hide()
				AddressOf Me.Label1.Text = "F"
				AddressOf Me.Label1.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("SkyWeb Evoro")
				Catch expr_103 As Exception
					ProjectData.SetProjectError(expr_103)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub Button3_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label2.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = Me
				AddressOf Me.TexteditorToolStripMenuItem.Visible = True
				AddressOf AddressOf MyProject.Forms.Texteditor.Show()
				AddressOf Me.Label2.Text = "T"
				AddressOf Me.Label2.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("Texter Evoro")
			Else
				AddressOf Me.Label2.Text = "T"
				AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = Me
				AddressOf Me.TexteditorToolStripMenuItem.Visible = False
				AddressOf AddressOf MyProject.Forms.Texteditor.Hide()
				AddressOf Me.Label2.Text = "F"
				AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.Clear()
				AddressOf Me.Label2.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("Texter Evoro")
				Catch expr_117 As Exception
					ProjectData.SetProjectError(expr_117)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub Button4_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label3.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Explorer.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Explorer.Show()
				AddressOf Me.Label3.Text = "T"
				AddressOf Me.Label3.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("Evoxplorer")
			Else
				AddressOf Me.Label3.Text = "T"
				AddressOf AddressOf MyProject.Forms.Explorer.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Explorer.Hide()
				AddressOf Me.Label3.Text = "F"
				AddressOf Me.Label3.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("Evoxplorer")
				Catch expr_E8 As Exception
					ProjectData.SetProjectError(expr_E8)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub Button5_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label4.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.GreenStart.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.GreenStart.Show()
				AddressOf Me.Label4.Text = "T"
				AddressOf Me.Label4.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("GreenStart")
			Else
				AddressOf Me.Label4.Text = "T"
				AddressOf AddressOf MyProject.Forms.GreenStart.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.GreenStart.Hide()
				AddressOf Me.Label4.Text = "F"
				AddressOf Me.Label4.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("GreenStart")
				Catch expr_E8 As Exception
					ProjectData.SetProjectError(expr_E8)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub Button6_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label5.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Form2.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Form2.Show()
				AddressOf Me.Label5.Text = "T"
				AddressOf Me.Label5.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("EvoPlayer")
			Else
				If Operators.CompareString(AddressOf Me.Label5.Text, "T", False) = 0 Then
					AddressOf AddressOf MyProject.Forms.Form2.MdiParent = Me
					AddressOf AddressOf MyProject.Forms.Form2.Hide()
					AddressOf Me.Label5.Text = "F"
					AddressOf Me.Label5.BackColor = Color.Red
					Try
						AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("EvoPlayer")
					Catch expr_F4 As Exception
						ProjectData.SetProjectError(expr_F4)
						ProjectData.ClearProjectError()
					End Try
				End If
			End If
		End Sub

		Private Sub Button7_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.Options.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Options.Show()
		End Sub

		Private Sub StartmenüToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf Me.Button1.Visible = AddressOf Me.StartmenüToolStripMenuItem.Checked
			AddressOf Me.CheckBox3.Checked = AddressOf Me.StartmenüToolStripMenuItem.Checked
			AddressOf Me.Panel1.Visible = False
		End Sub

		Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs)
			AddressOf Me.Button1.Visible = AddressOf Me.CheckBox3.Checked
			AddressOf Me.StartmenüToolStripMenuItem.Checked = AddressOf Me.CheckBox3.Checked
			AddressOf Me.Panel1.Visible = False
		End Sub

		<MethodImpl(MethodImplOptions.NoInlining Or MethodImplOptions.NoOptimization)>
		Private Sub Button8_Click(sender As Object, e As EventArgs)
			ProjectData.EndApp()
		End Sub

		Private Sub ContentsToolStripMenuItem_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub Button9_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.Painter.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Painter.Show()
		End Sub

		Private Sub ToolStripButton6_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label5.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Painter.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Painter.Show()
				AddressOf Me.Label6.Text = "T"
				AddressOf Me.Label6.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("EvoPainter")
			Else
				If Operators.CompareString(AddressOf Me.Label6.Text, "T", False) = 0 Then
					AddressOf AddressOf MyProject.Forms.Painter.MdiParent = Me
					AddressOf AddressOf MyProject.Forms.Painter.Hide()
					AddressOf Me.Label6.Text = "F"
					AddressOf Me.Label6.BackColor = Color.Red
					Try
						AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("EvoPainter")
					Catch expr_F4 As Exception
						ProjectData.SetProjectError(expr_F4)
						ProjectData.ClearProjectError()
					End Try
				End If
			End If
		End Sub

		Private Sub Button9_Click_1(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label6.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Painter.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Painter.Show()
				AddressOf Me.Label6.Text = "T"
				AddressOf Me.Label6.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("EvoPainter")
			Else
				If Operators.CompareString(AddressOf Me.Label6.Text, "T", False) = 0 Then
					AddressOf AddressOf MyProject.Forms.Painter.MdiParent = Me
					AddressOf AddressOf MyProject.Forms.Painter.Hide()
					AddressOf Me.Label6.Text = "F"
					AddressOf Me.Label6.BackColor = Color.Red
					Try
						AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("EvoPainter")
					Catch expr_F4 As Exception
						ProjectData.SetProjectError(expr_F4)
						ProjectData.ClearProjectError()
					End Try
				End If
			End If
		End Sub

		Private Sub Ansicht2ToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.Ansicht2.Show()
			Me.Close()
			AddressOf AddressOf MyProject.Forms.Painter.MdiParent = AddressOf AddressOf MyProject.Forms.Ansicht2
			AddressOf AddressOf MyProject.Forms.Explorer.MdiParent = AddressOf AddressOf MyProject.Forms.Ansicht2
			AddressOf AddressOf MyProject.Forms.GreenStart.MdiParent = AddressOf AddressOf MyProject.Forms.Ansicht2
			AddressOf AddressOf MyProject.Forms.Options.MdiParent = AddressOf AddressOf MyProject.Forms.Ansicht2
			AddressOf AddressOf MyProject.Forms.Form2.MdiParent = AddressOf AddressOf MyProject.Forms.Ansicht2
			AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = AddressOf AddressOf MyProject.Forms.Ansicht2
		End Sub
	End Class
End Namespace
