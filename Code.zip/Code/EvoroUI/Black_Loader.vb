Imports EvoroUI.My
Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Black_Loader
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("TextBox1")>
		Private _TextBox1 As TextBox

		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		<AccessedThroughProperty("Button2")>
		Private _Button2 As Button

		<AccessedThroughProperty("Timer2")>
		Private _Timer2 As Timer

		<AccessedThroughProperty("PictureBox1")>
		Private _PictureBox1 As PictureBox

		<AccessedThroughProperty("PictureBox2")>
		Private _PictureBox2 As PictureBox

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button1_Click
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.Click, value2
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property TextBox1() As TextBox
			Get
				Return Me._TextBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim value2 As EventHandler = AddressOf Me.TextBox1_TextChanged
				If Me._TextBox1 IsNot Nothing Then
					RemoveHandler Me._TextBox1.TextChanged, value2
				End If
				Me._TextBox1 = value
				If Me._TextBox1 IsNot Nothing Then
					AddHandler Me._TextBox1.TextChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property Label1() As Label
			Get
				Return Me._Label1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		Friend Overridable Property Timer1() As Timer
			Get
				Return Me._Timer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer1_Tick
				If Me._Timer1 IsNot Nothing Then
					RemoveHandler Me._Timer1.Tick, value2
				End If
				Me._Timer1 = value
				If Me._Timer1 IsNot Nothing Then
					AddHandler Me._Timer1.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button2() As Button
			Get
				Return Me._Button2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button2_Click
				If Me._Button2 IsNot Nothing Then
					RemoveHandler Me._Button2.Click, value2
				End If
				Me._Button2 = value
				If Me._Button2 IsNot Nothing Then
					AddHandler Me._Button2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Timer2() As Timer
			Get
				Return Me._Timer2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer2_Tick
				If Me._Timer2 IsNot Nothing Then
					RemoveHandler Me._Timer2.Tick, value2
				End If
				Me._Timer2 = value
				If Me._Timer2 IsNot Nothing Then
					AddHandler Me._Timer2.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property PictureBox1() As PictureBox
			Get
				Return Me._PictureBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox1 = value
			End Set
		End Property

		Friend Overridable Property PictureBox2() As PictureBox
			Get
				Return Me._PictureBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox2 = value
			End Set
		End Property

		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.Black_Loader_Load
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Container()
			AddressOf Me.TextBox1 = New TextBox()
			AddressOf Me.Label1 = New Label()
			AddressOf Me.Timer1 = New Timer(Me.components)
			AddressOf Me.Button2 = New Button()
			AddressOf Me.Timer2 = New Timer(Me.components)
			AddressOf Me.PictureBox1 = New PictureBox()
			AddressOf Me.Button1 = New Button()
			AddressOf Me.PictureBox2 = New PictureBox()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).BeginInit()
			Me.SuspendLayout()
			AddressOf Me.TextBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.TextBox1.Font = New Font("Century Gothic", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Dim arg_CD_0 As Control = AddressOf Me.TextBox1
			Dim location As Point = New Point(692, 589)
			arg_CD_0.Location = location
			Dim arg_E1_0 As Control = AddressOf Me.TextBox1
			Dim margin As Padding = New Padding(5)
			arg_E1_0.Margin = margin
			AddressOf Me.TextBox1.Name = "TextBox1"
			AddressOf Me.TextBox1.PasswordChar = ChrW(9675)
			Dim arg_11C_0 As Control = AddressOf Me.TextBox1
			Dim size As Size = New Size(213, 31)
			arg_11C_0.Size = size
			AddressOf Me.TextBox1.TabIndex = 1
			AddressOf Me.Label1.AutoSize = True
			Dim arg_151_0 As Control = AddressOf Me.Label1
			location = New Point(688, 562)
			arg_151_0.Location = location
			AddressOf Me.Label1.Name = "Label1"
			Dim arg_17C_0 As Control = AddressOf Me.Label1
			size = New Size(224, 21)
			arg_17C_0.Size = size
			AddressOf Me.Label1.TabIndex = 2
			AddressOf Me.Label1.Text = "Please enter your password!"
			AddressOf Me.Timer1.Interval = 5000
			AddressOf Me.Button2.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button2.FlatStyle = FlatStyle.Flat
			Dim arg_1DE_0 As Control = AddressOf Me.Button2
			location = New Point(692, 588)
			arg_1DE_0.Location = location
			AddressOf Me.Button2.Name = "Button2"
			Dim arg_209_0 As Control = AddressOf Me.Button2
			size = New Size(213, 31)
			arg_209_0.Size = size
			AddressOf Me.Button2.TabIndex = 3
			AddressOf Me.Button2.Text = "Stop"
			AddressOf Me.Button2.UseVisualStyleBackColor = True
			AddressOf Me.Button2.Visible = False
			AddressOf Me.Timer2.Interval = 1000
			AddressOf Me.PictureBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.PictureBox1.BackgroundImage = AddressOf Resources.SkyVOSBig
			AddressOf Me.PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_293_0 As Control = AddressOf Me.PictureBox1
			location = New Point(692, 473)
			arg_293_0.Location = location
			AddressOf Me.PictureBox1.Name = "PictureBox1"
			Dim arg_2BE_0 As Control = AddressOf Me.PictureBox1
			size = New Size(213, 86)
			arg_2BE_0.Size = size
			AddressOf Me.PictureBox1.TabIndex = 4
			AddressOf Me.PictureBox1.TabStop = False
			AddressOf Me.Button1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Button1.BackgroundImage = AddressOf Resources.Up
			AddressOf Me.Button1.BackgroundImageLayout = ImageLayout.Zoom
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			Dim arg_328_0 As Control = AddressOf Me.Button1
			location = New Point(873, 588)
			arg_328_0.Location = location
			Dim arg_33C_0 As Control = AddressOf Me.Button1
			margin = New Padding(5)
			arg_33C_0.Margin = margin
			Dim arg_354_0 As Control = AddressOf Me.Button1
			size = New Size(32, 32)
			arg_354_0.MaximumSize = size
			Dim arg_36C_0 As Control = AddressOf Me.Button1
			size = New Size(32, 32)
			arg_36C_0.MinimumSize = size
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_394_0 As Control = AddressOf Me.Button1
			size = New Size(32, 32)
			arg_394_0.Size = size
			AddressOf Me.Button1.TabIndex = 0
			AddressOf Me.Button1.UseVisualStyleBackColor = True
			AddressOf Me.PictureBox2.Image = AddressOf Resources.ajax_loader__5_
			Dim arg_3D9_0 As Control = AddressOf Me.PictureBox2
			location = New Point(647, 587)
			arg_3D9_0.Location = location
			AddressOf Me.PictureBox2.Name = "PictureBox2"
			Dim arg_401_0 As Control = AddressOf Me.PictureBox2
			size = New Size(39, 32)
			arg_401_0.Size = size
			AddressOf Me.PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
			AddressOf Me.PictureBox2.TabIndex = 5
			AddressOf Me.PictureBox2.TabStop = False
			AddressOf Me.PictureBox2.Visible = False
			Dim autoScaleDimensions As SizeF = New SizeF(10F, 21F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			size = New Size(1500, 809)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.PictureBox2)
			Me.Controls.Add(AddressOf Me.PictureBox1)
			Me.Controls.Add(AddressOf Me.Button2)
			Me.Controls.Add(AddressOf Me.Label1)
			Me.Controls.Add(AddressOf Me.Button1)
			Me.Controls.Add(AddressOf Me.TextBox1)
			Me.Font = New Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Me.ForeColor = Color.White
			Me.FormBorderStyle = FormBorderStyle.None
			margin = New Padding(5)
			Me.Margin = margin
			Me.Name = "Black_Loader"
			Me.ShowInTaskbar = False
			Me.StartPosition = FormStartPosition.CenterScreen
			Me.Text = "Black_Loader"
			Me.WindowState = FormWindowState.Maximized
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.TextBox1.Text, AddressOf AddressOf MySettingsProperty.Settings.Passwort, False) = 0 Then
				AddressOf Me.Label1.Text = "Correct Passwort. You will be Logged in now."
				AddressOf Me.PictureBox1.Hide()
				AddressOf Me.PictureBox2.Show()
				AddressOf Me.TextBox1.Enabled = False
				AddressOf Me.TextBox1.Hide()
				AddressOf Me.Button1.Enabled = False
				AddressOf Me.Button1.Hide()
				AddressOf Me.Button2.Show()
				AddressOf Me.Timer1.Start()
			Else
				If Operators.CompareString(AddressOf Me.TextBox1.Text, "End", False) = 0 Then
					AddressOf Me.Label1.Text = "EvoroAMI will be closed in a few seconds. Please wait..."
					AddressOf Me.PictureBox1.Hide()
					AddressOf Me.PictureBox2.Show()
					AddressOf Me.TextBox1.Enabled = False
					AddressOf Me.TextBox1.Hide()
					AddressOf Me.Button1.Enabled = False
					AddressOf Me.Button1.Hide()
					AddressOf Me.Timer2.Start()
				Else
					AddressOf Me.Label1.Text = "Incorrect Passwort!"
					AddressOf Me.Label1.ForeColor = Color.Red
				End If
			End If
		End Sub

		Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)
			AddressOf Me.Label1.Text = "Please enter your password!"
			AddressOf Me.Label1.ForeColor = Color.White
		End Sub

		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.Ansicht2.Show()
			AddressOf Me.TextBox1.Clear()
			Me.Close()
			AddressOf Me.Timer1.[Stop]()
		End Sub

		Private Sub Black_Loader_Load(sender As Object, e As EventArgs)
			AddressOf Me.Button2.Hide()
		End Sub

		Private Sub Button2_Click(sender As Object, e As EventArgs)
			AddressOf Me.Label1.Text = "Please enter your password!"
			AddressOf Me.PictureBox1.Show()
			AddressOf Me.PictureBox2.Hide()
			AddressOf Me.TextBox1.Enabled = True
			AddressOf Me.TextBox1.Show()
			AddressOf Me.Button1.Enabled = True
			AddressOf Me.Button1.Show()
			AddressOf Me.Button2.Hide()
			AddressOf Me.Timer1.[Stop]()
		End Sub

		<MethodImpl(MethodImplOptions.NoInlining Or MethodImplOptions.NoOptimization)>
		Private Sub Timer2_Tick(sender As Object, e As EventArgs)
			ProjectData.EndApp()
		End Sub
	End Class
End Namespace
