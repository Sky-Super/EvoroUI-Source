Imports AxSystemMonitor
Imports EvoroUI.My
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Options
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("GroupBox1")>
		Private _GroupBox1 As GroupBox

		<AccessedThroughProperty("TextBox1")>
		Private _TextBox1 As TextBox

		<AccessedThroughProperty("TextBox2")>
		Private _TextBox2 As TextBox

		<AccessedThroughProperty("GroupBox2")>
		Private _GroupBox2 As GroupBox

		<AccessedThroughProperty("AxSystemMonitor1")>
		Private _AxSystemMonitor1 As AxSystemMonitor

		<AccessedThroughProperty("GroupBox3")>
		Private _GroupBox3 As GroupBox

		<AccessedThroughProperty("ListBox1")>
		Private _ListBox1 As ListBox

		<AccessedThroughProperty("Button2")>
		Private _Button2 As Button

		<AccessedThroughProperty("GroupBox4")>
		Private _GroupBox4 As GroupBox

		<AccessedThroughProperty("RadioButton2")>
		Private _RadioButton2 As RadioButton

		<AccessedThroughProperty("RadioButton1")>
		Private _RadioButton1 As RadioButton

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button1_Click
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.Click, value2
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property GroupBox1() As GroupBox
			Get
				Return Me._GroupBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox1 = value
			End Set
		End Property

		Friend Overridable Property TextBox1() As TextBox
			Get
				Return Me._TextBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox1 = value
			End Set
		End Property

		Friend Overridable Property TextBox2() As TextBox
			Get
				Return Me._TextBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox2 = value
			End Set
		End Property

		Friend Overridable Property GroupBox2() As GroupBox
			Get
				Return Me._GroupBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox2 = value
			End Set
		End Property

		Friend Overridable Property AxSystemMonitor1() As AxSystemMonitor
			Get
				Return Me._AxSystemMonitor1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As AxSystemMonitor)
				Me._AxSystemMonitor1 = value
			End Set
		End Property

		Friend Overridable Property GroupBox3() As GroupBox
			Get
				Return Me._GroupBox3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox3 = value
			End Set
		End Property

		Friend Overridable Property ListBox1() As ListBox
			Get
				Return Me._ListBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Me._ListBox1 = value
			End Set
		End Property

		Friend Overridable Property Button2() As Button
			Get
				Return Me._Button2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button2_Click
				If Me._Button2 IsNot Nothing Then
					RemoveHandler Me._Button2.Click, value2
				End If
				Me._Button2 = value
				If Me._Button2 IsNot Nothing Then
					AddHandler Me._Button2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property GroupBox4() As GroupBox
			Get
				Return Me._GroupBox4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox4 = value
			End Set
		End Property

		Friend Overridable Property RadioButton2() As RadioButton
			Get
				Return Me._RadioButton2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Dim value2 As EventHandler = AddressOf Me.RadioButton2_CheckedChanged
				If Me._RadioButton2 IsNot Nothing Then
					RemoveHandler Me._RadioButton2.CheckedChanged, value2
				End If
				Me._RadioButton2 = value
				If Me._RadioButton2 IsNot Nothing Then
					AddHandler Me._RadioButton2.CheckedChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property RadioButton1() As RadioButton
			Get
				Return Me._RadioButton1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Dim value2 As EventHandler = AddressOf Me.RadioButton1_CheckedChanged
				If Me._RadioButton1 IsNot Nothing Then
					RemoveHandler Me._RadioButton1.CheckedChanged, value2
				End If
				Me._RadioButton1 = value
				If Me._RadioButton1 IsNot Nothing Then
					AddHandler Me._RadioButton1.CheckedChanged, value2
				End If
			End Set
		End Property

		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.Options_Load
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Dim resources As ComponentResourceManager = New ComponentResourceManager(GetType(Options))
			AddressOf Me.Button1 = New Button()
			AddressOf Me.GroupBox1 = New GroupBox()
			AddressOf Me.TextBox1 = New TextBox()
			AddressOf Me.TextBox2 = New TextBox()
			AddressOf Me.GroupBox2 = New GroupBox()
			AddressOf Me.AxSystemMonitor1 = New AxSystemMonitor()
			AddressOf Me.GroupBox3 = New GroupBox()
			AddressOf Me.ListBox1 = New ListBox()
			AddressOf Me.Button2 = New Button()
			AddressOf Me.GroupBox4 = New GroupBox()
			AddressOf Me.RadioButton1 = New RadioButton()
			AddressOf Me.RadioButton2 = New RadioButton()
			AddressOf Me.GroupBox1.SuspendLayout()
			AddressOf Me.GroupBox2.SuspendLayout()
			(CType(AddressOf Me.AxSystemMonitor1, ISupportInitialize)).BeginInit()
			AddressOf Me.GroupBox3.SuspendLayout()
			AddressOf Me.GroupBox4.SuspendLayout()
			Me.SuspendLayout()
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			Dim arg_EE_0 As Control = AddressOf Me.Button1
			Dim location As Point = New Point(7, 14)
			arg_EE_0.Location = location
			Dim arg_106_0 As Control = AddressOf Me.Button1
			Dim padding As Padding = New Padding(3, 4, 3, 4)
			arg_106_0.Margin = padding
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_12E_0 As Control = AddressOf Me.Button1
			Dim size As Size = New Size(113, 53)
			arg_12E_0.Size = size
			AddressOf Me.Button1.TabIndex = 1
			AddressOf Me.Button1.Text = "Save"
			AddressOf Me.Button1.UseVisualStyleBackColor = True
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.TextBox1)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.TextBox2)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.Button1)
			AddressOf Me.GroupBox1.ForeColor = Color.White
			Dim arg_1BF_0 As Control = AddressOf Me.GroupBox1
			location = New Point(14, 15)
			arg_1BF_0.Location = location
			Dim arg_1D7_0 As Control = AddressOf Me.GroupBox1
			padding = New Padding(3, 4, 3, 4)
			arg_1D7_0.Margin = padding
			AddressOf Me.GroupBox1.Name = "GroupBox1"
			Dim arg_1FF_0 As Control = AddressOf Me.GroupBox1
			padding = New Padding(3, 4, 3, 4)
			arg_1FF_0.Padding = padding
			Dim arg_21A_0 As Control = AddressOf Me.GroupBox1
			size = New Size(378, 75)
			arg_21A_0.Size = size
			AddressOf Me.GroupBox1.TabIndex = 2
			AddressOf Me.GroupBox1.TabStop = False
			AddressOf Me.GroupBox1.Text = "Password"
			AddressOf Me.TextBox1.BackColor = Color.Black
			AddressOf Me.TextBox1.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.TextBox1.Font = New Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.TextBox1.ForeColor = Color.White
			Dim arg_2A2_0 As Control = AddressOf Me.TextBox1
			location = New Point(127, 14)
			arg_2A2_0.Location = location
			Dim arg_2BA_0 As Control = AddressOf Me.TextBox1
			padding = New Padding(3, 4, 3, 4)
			arg_2BA_0.Margin = padding
			AddressOf Me.TextBox1.Name = "TextBox1"
			Dim arg_2E5_0 As Control = AddressOf Me.TextBox1
			size = New Size(245, 21)
			arg_2E5_0.Size = size
			AddressOf Me.TextBox1.TabIndex = 2
			AddressOf Me.TextBox1.Text = "Username"
			AddressOf Me.TextBox2.BackColor = Color.Black
			AddressOf Me.TextBox2.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.TextBox2.Font = New Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.TextBox2.ForeColor = Color.White
			Dim arg_361_0 As Control = AddressOf Me.TextBox2
			location = New Point(127, 46)
			arg_361_0.Location = location
			Dim arg_379_0 As Control = AddressOf Me.TextBox2
			padding = New Padding(3, 4, 3, 4)
			arg_379_0.Margin = padding
			AddressOf Me.TextBox2.Name = "TextBox2"
			Dim arg_3A4_0 As Control = AddressOf Me.TextBox2
			size = New Size(245, 21)
			arg_3A4_0.Size = size
			AddressOf Me.TextBox2.TabIndex = 3
			AddressOf Me.TextBox2.Text = "Password"
			AddressOf Me.GroupBox2.Controls.Add(AddressOf Me.AxSystemMonitor1)
			AddressOf Me.GroupBox2.ForeColor = Color.White
			Dim arg_400_0 As Control = AddressOf Me.GroupBox2
			location = New Point(398, 15)
			arg_400_0.Location = location
			AddressOf Me.GroupBox2.Name = "GroupBox2"
			Dim arg_42E_0 As Control = AddressOf Me.GroupBox2
			size = New Size(369, 416)
			arg_42E_0.Size = size
			AddressOf Me.GroupBox2.TabIndex = 3
			AddressOf Me.GroupBox2.TabStop = False
			AddressOf Me.GroupBox2.Text = "Recourcenmonitor"
			AddressOf Me.AxSystemMonitor1.Enabled = True
			Dim arg_478_0 As Control = AddressOf Me.AxSystemMonitor1
			location = New Point(6, 14)
			arg_478_0.Location = location
			AddressOf Me.AxSystemMonitor1.Name = "AxSystemMonitor1"
			AddressOf Me.AxSystemMonitor1.OcxState = CType(resources.GetObject("AxSystemMonitor1.OcxState"), AxHost.State)
			Dim arg_4C1_0 As Control = AddressOf Me.AxSystemMonitor1
			size = New Size(357, 394)
			arg_4C1_0.Size = size
			AddressOf Me.AxSystemMonitor1.TabIndex = 15
			AddressOf Me.GroupBox3.Controls.Add(AddressOf Me.ListBox1)
			AddressOf Me.GroupBox3.ForeColor = Color.White
			Dim arg_50B_0 As Control = AddressOf Me.GroupBox3
			location = New Point(14, 98)
			arg_50B_0.Location = location
			Dim arg_523_0 As Control = AddressOf Me.GroupBox3
			padding = New Padding(3, 4, 3, 4)
			arg_523_0.Margin = padding
			AddressOf Me.GroupBox3.Name = "GroupBox3"
			Dim arg_54B_0 As Control = AddressOf Me.GroupBox3
			padding = New Padding(3, 4, 3, 4)
			arg_54B_0.Padding = padding
			Dim arg_569_0 As Control = AddressOf Me.GroupBox3
			size = New Size(378, 251)
			arg_569_0.Size = size
			AddressOf Me.GroupBox3.TabIndex = 4
			AddressOf Me.GroupBox3.TabStop = False
			AddressOf Me.GroupBox3.Text = "Activated Software"
			AddressOf Me.ListBox1.BackColor = Color.Black
			AddressOf Me.ListBox1.ForeColor = Color.White
			AddressOf Me.ListBox1.FormattingEnabled = True
			AddressOf Me.ListBox1.ItemHeight = 16
			Dim arg_5E0_0 As Control = AddressOf Me.ListBox1
			location = New Point(7, 14)
			arg_5E0_0.Location = location
			AddressOf Me.ListBox1.Name = "ListBox1"
			Dim arg_60E_0 As Control = AddressOf Me.ListBox1
			size = New Size(365, 228)
			arg_60E_0.Size = size
			AddressOf Me.ListBox1.TabIndex = 2
			AddressOf Me.Button2.FlatStyle = FlatStyle.Flat
			Dim arg_640_0 As Control = AddressOf Me.Button2
			location = New Point(14, 407)
			arg_640_0.Location = location
			Dim arg_658_0 As Control = AddressOf Me.Button2
			padding = New Padding(3, 4, 3, 4)
			arg_658_0.Margin = padding
			AddressOf Me.Button2.Name = "Button2"
			Dim arg_683_0 As Control = AddressOf Me.Button2
			size = New Size(378, 24)
			arg_683_0.Size = size
			AddressOf Me.Button2.TabIndex = 5
			AddressOf Me.Button2.Text = "Update"
			AddressOf Me.Button2.UseVisualStyleBackColor = True
			AddressOf Me.GroupBox4.Controls.Add(AddressOf Me.RadioButton2)
			AddressOf Me.GroupBox4.Controls.Add(AddressOf Me.RadioButton1)
			AddressOf Me.GroupBox4.ForeColor = Color.White
			Dim arg_701_0 As Control = AddressOf Me.GroupBox4
			location = New Point(14, 357)
			arg_701_0.Location = location
			Dim arg_719_0 As Control = AddressOf Me.GroupBox4
			padding = New Padding(3, 4, 3, 4)
			arg_719_0.Margin = padding
			AddressOf Me.GroupBox4.Name = "GroupBox4"
			Dim arg_741_0 As Control = AddressOf Me.GroupBox4
			padding = New Padding(3, 4, 3, 4)
			arg_741_0.Padding = padding
			Dim arg_75C_0 As Control = AddressOf Me.GroupBox4
			size = New Size(378, 42)
			arg_75C_0.Size = size
			AddressOf Me.GroupBox4.TabIndex = 6
			AddressOf Me.GroupBox4.TabStop = False
			AddressOf Me.GroupBox4.Text = "Startscreen"
			AddressOf Me.RadioButton1.AutoSize = True
			Dim arg_7A6_0 As Control = AddressOf Me.RadioButton1
			location = New Point(7, 15)
			arg_7A6_0.Location = location
			AddressOf Me.RadioButton1.Name = "RadioButton1"
			Dim arg_7CE_0 As Control = AddressOf Me.RadioButton1
			size = New Size(69, 20)
			arg_7CE_0.Size = size
			AddressOf Me.RadioButton1.TabIndex = 0
			AddressOf Me.RadioButton1.Text = "Desktop"
			AddressOf Me.RadioButton1.UseVisualStyleBackColor = True
			AddressOf Me.RadioButton2.AutoSize = True
			AddressOf Me.RadioButton2.Checked = True
			Dim arg_828_0 As Control = AddressOf Me.RadioButton2
			location = New Point(229, 15)
			arg_828_0.Location = location
			AddressOf Me.RadioButton2.Name = "RadioButton2"
			Dim arg_850_0 As Control = AddressOf Me.RadioButton2
			size = New Size(78, 20)
			arg_850_0.Size = size
			AddressOf Me.RadioButton2.TabIndex = 1
			AddressOf Me.RadioButton2.TabStop = True
			AddressOf Me.RadioButton2.Text = "Standard"
			AddressOf Me.RadioButton2.UseVisualStyleBackColor = True
			Dim autoScaleDimensions As SizeF = New SizeF(7F, 16F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			size = New Size(779, 444)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.GroupBox4)
			Me.Controls.Add(AddressOf Me.Button2)
			Me.Controls.Add(AddressOf Me.GroupBox3)
			Me.Controls.Add(AddressOf Me.GroupBox2)
			Me.Controls.Add(AddressOf Me.GroupBox1)
			Me.DoubleBuffered = True
			Me.Font = New Font("Century Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Me.ForeColor = Color.White
			Me.FormBorderStyle = FormBorderStyle.FixedToolWindow
			padding = New Padding(3, 4, 3, 4)
			Me.Margin = padding
			Me.MaximizeBox = False
			Me.Name = "Options"
			Me.Text = "Settings"
			AddressOf Me.GroupBox1.ResumeLayout(False)
			AddressOf Me.GroupBox1.PerformLayout()
			AddressOf Me.GroupBox2.ResumeLayout(False)
			(CType(AddressOf Me.AxSystemMonitor1, ISupportInitialize)).EndInit()
			AddressOf Me.GroupBox3.ResumeLayout(False)
			AddressOf Me.GroupBox4.ResumeLayout(False)
			AddressOf Me.GroupBox4.PerformLayout()
			Me.ResumeLayout(False)
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.TextBox2.Text, "End", False) = 0 Then
				Interaction.MsgBox("'End' is not Enabled", MsgBoxStyle.Critical, Nothing)
			Else
				AddressOf AddressOf MySettingsProperty.Settings.Username = AddressOf Me.TextBox1.Text
				AddressOf AddressOf MySettingsProperty.Settings.Passwort = AddressOf Me.TextBox2.Text
			End If
		End Sub

		Private Sub Button2_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.Updater.Show()
		End Sub

		Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs)
			AddressOf AddressOf MySettingsProperty.Settings.StandartStartfenster = "MDIParent1"
		End Sub

		Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs)
			AddressOf AddressOf MySettingsProperty.Settings.StandartStartfenster = "Desktop"
		End Sub

		Private Sub Options_Load(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf AddressOf MySettingsProperty.Settings.StandartStartfenster, "MDIParent1", False) = 0 Then
				AddressOf Me.RadioButton2.Checked = True
				AddressOf Me.RadioButton1.Checked = False
			Else
				AddressOf Me.RadioButton2.Checked = False
				AddressOf Me.RadioButton1.Checked = True
			End If
		End Sub
	End Class
End Namespace
