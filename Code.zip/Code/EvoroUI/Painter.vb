Imports EvoroUI.My
Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Painter
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("MenuStrip1")>
		Private _MenuStrip1 As MenuStrip

		<AccessedThroughProperty("DateiImageToolStripMenuItem")>
		Private _DateiImageToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("BildToolStripMenuItem")>
		Private _BildToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("RadiereBTN")>
		Private _RadiereBTN As RadioButton

		<AccessedThroughProperty("BleistiftBTN")>
		Private _BleistiftBTN As RadioButton

		<AccessedThroughProperty("RechteckBTN")>
		Private _RechteckBTN As RadioButton

		<AccessedThroughProperty("DreieckBTN")>
		Private _DreieckBTN As RadioButton

		<AccessedThroughProperty("KreisBTN")>
		Private _KreisBTN As RadioButton

		<AccessedThroughProperty("HalbkreisBTN")>
		Private _HalbkreisBTN As RadioButton

		<AccessedThroughProperty("VieleckBTN")>
		Private _VieleckBTN As RadioButton

		<AccessedThroughProperty("FüllBTN")>
		Private _FüllBTN As RadioButton

		<AccessedThroughProperty("ParaleollogrammBTN")>
		Private _ParaleollogrammBTN As RadioButton

		<AccessedThroughProperty("TextBTN")>
		Private _TextBTN As RadioButton

		<AccessedThroughProperty("GroupBox1")>
		Private _GroupBox1 As GroupBox

		<AccessedThroughProperty("TrackBar1")>
		Private _TrackBar1 As TrackBar

		<AccessedThroughProperty("P4BTN")>
		Private _P4BTN As RadioButton

		<AccessedThroughProperty("P3BTN")>
		Private _P3BTN As RadioButton

		<AccessedThroughProperty("P2BTN")>
		Private _P2BTN As RadioButton

		<AccessedThroughProperty("P1BTN")>
		Private _P1BTN As RadioButton

		<AccessedThroughProperty("FontButton")>
		Private _FontButton As Button

		<AccessedThroughProperty("Color1BTN")>
		Private _Color1BTN As Button

		<AccessedThroughProperty("Color2BTN")>
		Private _Color2BTN As Button

		<AccessedThroughProperty("PictureBox1")>
		Private _PictureBox1 As PictureBox

		<AccessedThroughProperty("ColorDialog1")>
		Private _ColorDialog1 As ColorDialog

		<AccessedThroughProperty("FontDialog1")>
		Private _FontDialog1 As FontDialog

		<AccessedThroughProperty("SaveFileDialog1")>
		Private _SaveFileDialog1 As SaveFileDialog

		<AccessedThroughProperty("LöschenToolStripMenuItem")>
		Private _LöschenToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("NeuToolStripMenuItem")>
		Private _NeuToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("SpeichernToolStripMenuItem")>
		Private _SpeichernToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("SpeichernAlsToolStripMenuItem")>
		Private _SpeichernAlsToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("ToolStripMenuItem1")>
		Private _ToolStripMenuItem1 As ToolStripSeparator

		<AccessedThroughProperty("SchließenToolStripMenuItem")>
		Private _SchließenToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("M1ToolStripMenuItem")>
		Private _M1ToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("M2ToolStripMenuItem")>
		Private _M2ToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("M3ToolStripMenuItem")>
		Private _M3ToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("M4ToolStripMenuItem")>
		Private _M4ToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("ToolStripMenuItem2")>
		Private _ToolStripMenuItem2 As ToolStripSeparator

		<AccessedThroughProperty("S1ToolStripMenuItem")>
		Private _S1ToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("S2ToolStripMenuItem")>
		Private _S2ToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("S3ToolStripMenuItem")>
		Private _S3ToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("S4ToolStripMenuItem")>
		Private _S4ToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("InfoToolStripMenuItem")>
		Private _InfoToolStripMenuItem As ToolStripMenuItem

		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		<AccessedThroughProperty("PictureBox2")>
		Private _PictureBox2 As PictureBox

		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		<AccessedThroughProperty("TextBox1")>
		Private _TextBox1 As TextBox

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("TimerMover")>
		Private _TimerMover As Timer

		Private g As Graphics

		Private PenWidth As Single

		Private PenPoint As Pen

		Private SavedFileAddress As String

		Private CurrentFont As Font

		Private startLocation As Point

		Private endLocation As Point

		Private TempLocation As Point

		Private TempLocation2 As Point

		Private NumberOfAngle As Integer

		Private drawing As Boolean

		Private CurrentColor As Color

		Private CurrentColor2 As Color

		Private LastImage As Bitmap

		Private M1 As Bitmap

		Private M2 As Bitmap

		Private M3 As Bitmap

		Private M4 As Bitmap

		Friend Overridable Property MenuStrip1() As MenuStrip
			Get
				Return Me._MenuStrip1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MenuStrip)
				Me._MenuStrip1 = value
			End Set
		End Property

		Friend Overridable Property DateiImageToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._DateiImageToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.DateiImageToolStripMenuItem_Click
				If Me._DateiImageToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._DateiImageToolStripMenuItem.Click, value2
				End If
				Me._DateiImageToolStripMenuItem = value
				If Me._DateiImageToolStripMenuItem IsNot Nothing Then
					AddHandler Me._DateiImageToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property BildToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._BildToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.BildToolStripMenuItem_Click
				If Me._BildToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._BildToolStripMenuItem.Click, value2
				End If
				Me._BildToolStripMenuItem = value
				If Me._BildToolStripMenuItem IsNot Nothing Then
					AddHandler Me._BildToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property RadiereBTN() As RadioButton
			Get
				Return Me._RadiereBTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._RadiereBTN = value
			End Set
		End Property

		Friend Overridable Property BleistiftBTN() As RadioButton
			Get
				Return Me._BleistiftBTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._BleistiftBTN = value
			End Set
		End Property

		Friend Overridable Property RechteckBTN() As RadioButton
			Get
				Return Me._RechteckBTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._RechteckBTN = value
			End Set
		End Property

		Friend Overridable Property DreieckBTN() As RadioButton
			Get
				Return Me._DreieckBTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._DreieckBTN = value
			End Set
		End Property

		Friend Overridable Property KreisBTN() As RadioButton
			Get
				Return Me._KreisBTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._KreisBTN = value
			End Set
		End Property

		Friend Overridable Property HalbkreisBTN() As RadioButton
			Get
				Return Me._HalbkreisBTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._HalbkreisBTN = value
			End Set
		End Property

		Friend Overridable Property VieleckBTN() As RadioButton
			Get
				Return Me._VieleckBTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._VieleckBTN = value
			End Set
		End Property

		Friend Overridable Property FüllBTN() As RadioButton
			Get
				Return Me._FüllBTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._FüllBTN = value
			End Set
		End Property

		Friend Overridable Property ParaleollogrammBTN() As RadioButton
			Get
				Return Me._ParaleollogrammBTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._ParaleollogrammBTN = value
			End Set
		End Property

		Friend Overridable Property TextBTN() As RadioButton
			Get
				Return Me._TextBTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._TextBTN = value
			End Set
		End Property

		Friend Overridable Property GroupBox1() As GroupBox
			Get
				Return Me._GroupBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox1 = value
			End Set
		End Property

		Friend Overridable Property TrackBar1() As TrackBar
			Get
				Return Me._TrackBar1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TrackBar)
				Dim value2 As EventHandler = AddressOf Me.TrackBar1_Scroll
				If Me._TrackBar1 IsNot Nothing Then
					RemoveHandler Me._TrackBar1.Scroll, value2
				End If
				Me._TrackBar1 = value
				If Me._TrackBar1 IsNot Nothing Then
					AddHandler Me._TrackBar1.Scroll, value2
				End If
			End Set
		End Property

		Friend Overridable Property P4BTN() As RadioButton
			Get
				Return Me._P4BTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Me._P4BTN = value
			End Set
		End Property

		Friend Overridable Property P3BTN() As RadioButton
			Get
				Return Me._P3BTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Dim value2 As EventHandler = AddressOf Me.P3BTN_CheckedChanged
				If Me._P3BTN IsNot Nothing Then
					RemoveHandler Me._P3BTN.CheckedChanged, value2
				End If
				Me._P3BTN = value
				If Me._P3BTN IsNot Nothing Then
					AddHandler Me._P3BTN.CheckedChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property P2BTN() As RadioButton
			Get
				Return Me._P2BTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Dim value2 As EventHandler = AddressOf Me.P2BTN_CheckedChanged
				If Me._P2BTN IsNot Nothing Then
					RemoveHandler Me._P2BTN.CheckedChanged, value2
				End If
				Me._P2BTN = value
				If Me._P2BTN IsNot Nothing Then
					AddHandler Me._P2BTN.CheckedChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property P1BTN() As RadioButton
			Get
				Return Me._P1BTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As RadioButton)
				Dim value2 As EventHandler = AddressOf Me.P1BTN_CheckedChanged
				If Me._P1BTN IsNot Nothing Then
					RemoveHandler Me._P1BTN.CheckedChanged, value2
				End If
				Me._P1BTN = value
				If Me._P1BTN IsNot Nothing Then
					AddHandler Me._P1BTN.CheckedChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property FontButton() As Button
			Get
				Return Me._FontButton
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._FontButton = value
			End Set
		End Property

		Friend Overridable Property Color1BTN() As Button
			Get
				Return Me._Color1BTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Color1BTN_Click
				If Me._Color1BTN IsNot Nothing Then
					RemoveHandler Me._Color1BTN.Click, value2
				End If
				Me._Color1BTN = value
				If Me._Color1BTN IsNot Nothing Then
					AddHandler Me._Color1BTN.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Color2BTN() As Button
			Get
				Return Me._Color2BTN
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Color2BTN_Click
				If Me._Color2BTN IsNot Nothing Then
					RemoveHandler Me._Color2BTN.Click, value2
				End If
				Me._Color2BTN = value
				If Me._Color2BTN IsNot Nothing Then
					AddHandler Me._Color2BTN.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property PictureBox1() As PictureBox
			Get
				Return Me._PictureBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Dim value2 As MouseEventHandler = AddressOf Me.PictureBox1_MouseUp
				Dim value3 As MouseEventHandler = AddressOf Me.PictureBox1_MouseMove
				Dim value4 As MouseEventHandler = AddressOf Me.PictureBox1_MouseDown
				If Me._PictureBox1 IsNot Nothing Then
					RemoveHandler Me._PictureBox1.MouseUp, value2
					RemoveHandler Me._PictureBox1.MouseMove, value3
					RemoveHandler Me._PictureBox1.MouseDown, value4
				End If
				Me._PictureBox1 = value
				If Me._PictureBox1 IsNot Nothing Then
					AddHandler Me._PictureBox1.MouseUp, value2
					AddHandler Me._PictureBox1.MouseMove, value3
					AddHandler Me._PictureBox1.MouseDown, value4
				End If
			End Set
		End Property

		Friend Overridable Property ColorDialog1() As ColorDialog
			Get
				Return Me._ColorDialog1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ColorDialog)
				Me._ColorDialog1 = value
			End Set
		End Property

		Friend Overridable Property FontDialog1() As FontDialog
			Get
				Return Me._FontDialog1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As FontDialog)
				Me._FontDialog1 = value
			End Set
		End Property

		Friend Overridable Property SaveFileDialog1() As SaveFileDialog
			Get
				Return Me._SaveFileDialog1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As SaveFileDialog)
				Me._SaveFileDialog1 = value
			End Set
		End Property

		Friend Overridable Property LöschenToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._LöschenToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.ClearToolStripMenuItem_Click
				If Me._LöschenToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._LöschenToolStripMenuItem.Click, value2
				End If
				Me._LöschenToolStripMenuItem = value
				If Me._LöschenToolStripMenuItem IsNot Nothing Then
					AddHandler Me._LöschenToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property NeuToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._NeuToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.NeuToolStripMenuItem_Click
				If Me._NeuToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._NeuToolStripMenuItem.Click, value2
				End If
				Me._NeuToolStripMenuItem = value
				If Me._NeuToolStripMenuItem IsNot Nothing Then
					AddHandler Me._NeuToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property SpeichernToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._SpeichernToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.SpeichernToolStripMenuItem_Click
				If Me._SpeichernToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._SpeichernToolStripMenuItem.Click, value2
				End If
				Me._SpeichernToolStripMenuItem = value
				If Me._SpeichernToolStripMenuItem IsNot Nothing Then
					AddHandler Me._SpeichernToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property SpeichernAlsToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._SpeichernAlsToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.SpeichernAlsToolStripMenuItem_Click
				If Me._SpeichernAlsToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._SpeichernAlsToolStripMenuItem.Click, value2
				End If
				Me._SpeichernAlsToolStripMenuItem = value
				If Me._SpeichernAlsToolStripMenuItem IsNot Nothing Then
					AddHandler Me._SpeichernAlsToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripMenuItem1() As ToolStripSeparator
			Get
				Return Me._ToolStripMenuItem1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripSeparator)
				Me._ToolStripMenuItem1 = value
			End Set
		End Property

		Friend Overridable Property SchließenToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._SchließenToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Me._SchließenToolStripMenuItem = value
			End Set
		End Property

		Friend Overridable Property M1ToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._M1ToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.M1ToolStripMenuItem_Click_1
				Dim value3 As EventHandler = AddressOf Me.M1ToolStripMenuItem_Click
				If Me._M1ToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._M1ToolStripMenuItem.Click, value2
					RemoveHandler Me._M1ToolStripMenuItem.Click, value3
				End If
				Me._M1ToolStripMenuItem = value
				If Me._M1ToolStripMenuItem IsNot Nothing Then
					AddHandler Me._M1ToolStripMenuItem.Click, value2
					AddHandler Me._M1ToolStripMenuItem.Click, value3
				End If
			End Set
		End Property

		Friend Overridable Property M2ToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._M2ToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.M2ToolStripMenuItem_Click
				If Me._M2ToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._M2ToolStripMenuItem.Click, value2
				End If
				Me._M2ToolStripMenuItem = value
				If Me._M2ToolStripMenuItem IsNot Nothing Then
					AddHandler Me._M2ToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property M3ToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._M3ToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.M3ToolStripMenuItem_Click
				If Me._M3ToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._M3ToolStripMenuItem.Click, value2
				End If
				Me._M3ToolStripMenuItem = value
				If Me._M3ToolStripMenuItem IsNot Nothing Then
					AddHandler Me._M3ToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property M4ToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._M4ToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.M4ToolStripMenuItem_Click
				If Me._M4ToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._M4ToolStripMenuItem.Click, value2
				End If
				Me._M4ToolStripMenuItem = value
				If Me._M4ToolStripMenuItem IsNot Nothing Then
					AddHandler Me._M4ToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ToolStripMenuItem2() As ToolStripSeparator
			Get
				Return Me._ToolStripMenuItem2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripSeparator)
				Me._ToolStripMenuItem2 = value
			End Set
		End Property

		Friend Overridable Property S1ToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._S1ToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.S1ToolStripMenuItem_Click
				If Me._S1ToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._S1ToolStripMenuItem.Click, value2
				End If
				Me._S1ToolStripMenuItem = value
				If Me._S1ToolStripMenuItem IsNot Nothing Then
					AddHandler Me._S1ToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property S2ToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._S2ToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.S2ToolStripMenuItem_Click
				If Me._S2ToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._S2ToolStripMenuItem.Click, value2
				End If
				Me._S2ToolStripMenuItem = value
				If Me._S2ToolStripMenuItem IsNot Nothing Then
					AddHandler Me._S2ToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property S3ToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._S3ToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.S3ToolStripMenuItem_Click
				If Me._S3ToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._S3ToolStripMenuItem.Click, value2
				End If
				Me._S3ToolStripMenuItem = value
				If Me._S3ToolStripMenuItem IsNot Nothing Then
					AddHandler Me._S3ToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property S4ToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._S4ToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.S4ToolStripMenuItem_Click
				If Me._S4ToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._S4ToolStripMenuItem.Click, value2
				End If
				Me._S4ToolStripMenuItem = value
				If Me._S4ToolStripMenuItem IsNot Nothing Then
					AddHandler Me._S4ToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property InfoToolStripMenuItem() As ToolStripMenuItem
			Get
				Return Me._InfoToolStripMenuItem
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ToolStripMenuItem)
				Dim value2 As EventHandler = AddressOf Me.InfoToolStripMenuItem_Click
				If Me._InfoToolStripMenuItem IsNot Nothing Then
					RemoveHandler Me._InfoToolStripMenuItem.Click, value2
				End If
				Me._InfoToolStripMenuItem = value
				If Me._InfoToolStripMenuItem IsNot Nothing Then
					AddHandler Me._InfoToolStripMenuItem.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Label1() As Label
			Get
				Return Me._Label1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		Friend Overridable Property PictureBox2() As PictureBox
			Get
				Return Me._PictureBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox2 = value
			End Set
		End Property

		Friend Overridable Property Label2() As Label
			Get
				Return Me._Label2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		Friend Overridable Property TextBox1() As TextBox
			Get
				Return Me._TextBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox1 = value
			End Set
		End Property

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As DragEventHandler = AddressOf Me.Button1_DragDrop
				Dim value3 As EventHandler = AddressOf Me.Button1_Click
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.DragDrop, value2
					RemoveHandler Me._Button1.Click, value3
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.DragDrop, value2
					AddHandler Me._Button1.Click, value3
				End If
			End Set
		End Property

		Friend Overridable Property TimerMover() As Timer
			Get
				Return Me._TimerMover
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.TimerMover_Tick
				If Me._TimerMover IsNot Nothing Then
					RemoveHandler Me._TimerMover.Tick, value2
				End If
				Me._TimerMover = value
				If Me._TimerMover IsNot Nothing Then
					AddHandler Me._TimerMover.Tick, value2
				End If
			End Set
		End Property

		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.Painter_Load
			Me.PenWidth = 1F
			Me.SavedFileAddress = ""
			Me.TempLocation = New Point(-1, -1)
			Me.TempLocation2 = New Point(-1, -1)
			Me.NumberOfAngle = 0
			Me.drawing = False
			Me.CurrentColor = Color.Blue
			Me.CurrentColor2 = Color.LightSkyBlue
			Me.LastImage = New Bitmap(501, 501)
			Me.M1 = New Bitmap(501, 501)
			Me.M2 = New Bitmap(501, 501)
			Me.M3 = New Bitmap(501, 501)
			Me.M4 = New Bitmap(501, 501)
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Container()
			AddressOf Me.MenuStrip1 = New MenuStrip()
			AddressOf Me.DateiImageToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.LöschenToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.NeuToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.SpeichernToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.SpeichernAlsToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.ToolStripMenuItem1 = New ToolStripSeparator()
			AddressOf Me.SchließenToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.BildToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.M1ToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.M2ToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.M3ToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.M4ToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.ToolStripMenuItem2 = New ToolStripSeparator()
			AddressOf Me.S1ToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.S2ToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.S3ToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.S4ToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.InfoToolStripMenuItem = New ToolStripMenuItem()
			AddressOf Me.RadiereBTN = New RadioButton()
			AddressOf Me.BleistiftBTN = New RadioButton()
			AddressOf Me.RechteckBTN = New RadioButton()
			AddressOf Me.DreieckBTN = New RadioButton()
			AddressOf Me.KreisBTN = New RadioButton()
			AddressOf Me.HalbkreisBTN = New RadioButton()
			AddressOf Me.VieleckBTN = New RadioButton()
			AddressOf Me.FüllBTN = New RadioButton()
			AddressOf Me.ParaleollogrammBTN = New RadioButton()
			AddressOf Me.TextBTN = New RadioButton()
			AddressOf Me.GroupBox1 = New GroupBox()
			AddressOf Me.TrackBar1 = New TrackBar()
			AddressOf Me.P4BTN = New RadioButton()
			AddressOf Me.P3BTN = New RadioButton()
			AddressOf Me.P2BTN = New RadioButton()
			AddressOf Me.P1BTN = New RadioButton()
			AddressOf Me.FontButton = New Button()
			AddressOf Me.Color1BTN = New Button()
			AddressOf Me.Color2BTN = New Button()
			AddressOf Me.ColorDialog1 = New ColorDialog()
			AddressOf Me.FontDialog1 = New FontDialog()
			AddressOf Me.SaveFileDialog1 = New SaveFileDialog()
			AddressOf Me.PictureBox1 = New PictureBox()
			AddressOf Me.Label1 = New Label()
			AddressOf Me.PictureBox2 = New PictureBox()
			AddressOf Me.Label2 = New Label()
			AddressOf Me.TextBox1 = New TextBox()
			AddressOf Me.Button1 = New Button()
			AddressOf Me.TimerMover = New Timer(Me.components)
			AddressOf Me.MenuStrip1.SuspendLayout()
			AddressOf Me.GroupBox1.SuspendLayout()
			(CType(AddressOf Me.TrackBar1, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).BeginInit()
			Me.SuspendLayout()
			AddressOf Me.MenuStrip1.BackColor = Color.Black
			AddressOf Me.MenuStrip1.BackgroundImage = AddressOf Resources.Farbverlauf3
			AddressOf Me.MenuStrip1.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.MenuStrip1.Items.AddRange(New ToolStripItem()() { AddressOf Me.DateiImageToolStripMenuItem, AddressOf Me.BildToolStripMenuItem, AddressOf Me.InfoToolStripMenuItem })
			Dim arg_2CD_0 As Control = AddressOf Me.MenuStrip1
			Dim location As Point = New Point(0, 0)
			arg_2CD_0.Location = location
			AddressOf Me.MenuStrip1.Name = "MenuStrip1"
			Dim arg_2F8_0 As Control = AddressOf Me.MenuStrip1
			Dim size As Size = New Size(902, 28)
			arg_2F8_0.Size = size
			AddressOf Me.MenuStrip1.TabIndex = 0
			AddressOf Me.MenuStrip1.Text = "MenuStrip1"
			AddressOf Me.DateiImageToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem()() { AddressOf Me.LöschenToolStripMenuItem, AddressOf Me.NeuToolStripMenuItem, AddressOf Me.SpeichernToolStripMenuItem, AddressOf Me.SpeichernAlsToolStripMenuItem, AddressOf Me.ToolStripMenuItem1, AddressOf Me.SchließenToolStripMenuItem })
			AddressOf Me.DateiImageToolStripMenuItem.Font = New Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.DateiImageToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.DateiImageToolStripMenuItem.Name = "DateiImageToolStripMenuItem"
			Dim arg_3B7_0 As ToolStripItem = AddressOf Me.DateiImageToolStripMenuItem
			size = New Size(60, 24)
			arg_3B7_0.Size = size
			AddressOf Me.DateiImageToolStripMenuItem.Text = "Datei"
			AddressOf Me.LöschenToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.LöschenToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.LöschenToolStripMenuItem.Name = "LöschenToolStripMenuItem"
			Dim arg_412_0 As ToolStripItem = AddressOf Me.LöschenToolStripMenuItem
			size = New Size(186, 24)
			arg_412_0.Size = size
			AddressOf Me.LöschenToolStripMenuItem.Text = "Löschen"
			AddressOf Me.NeuToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.NeuToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.NeuToolStripMenuItem.Name = "NeuToolStripMenuItem"
			Dim arg_46D_0 As ToolStripItem = AddressOf Me.NeuToolStripMenuItem
			size = New Size(186, 24)
			arg_46D_0.Size = size
			AddressOf Me.NeuToolStripMenuItem.Text = "Neu"
			AddressOf Me.SpeichernToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.SpeichernToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.SpeichernToolStripMenuItem.Name = "SpeichernToolStripMenuItem"
			Dim arg_4C8_0 As ToolStripItem = AddressOf Me.SpeichernToolStripMenuItem
			size = New Size(186, 24)
			arg_4C8_0.Size = size
			AddressOf Me.SpeichernToolStripMenuItem.Text = "Speichern"
			AddressOf Me.SpeichernAlsToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.SpeichernAlsToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.SpeichernAlsToolStripMenuItem.Name = "SpeichernAlsToolStripMenuItem"
			Dim arg_523_0 As ToolStripItem = AddressOf Me.SpeichernAlsToolStripMenuItem
			size = New Size(186, 24)
			arg_523_0.Size = size
			AddressOf Me.SpeichernAlsToolStripMenuItem.Text = "Speichern als..."
			AddressOf Me.ToolStripMenuItem1.BackColor = Color.Black
			AddressOf Me.ToolStripMenuItem1.ForeColor = Color.Lime
			AddressOf Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
			Dim arg_57D_0 As ToolStripItem = AddressOf Me.ToolStripMenuItem1
			size = New Size(183, 6)
			arg_57D_0.Size = size
			AddressOf Me.SchließenToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.SchließenToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.SchließenToolStripMenuItem.Name = "SchließenToolStripMenuItem"
			Dim arg_5C8_0 As ToolStripItem = AddressOf Me.SchließenToolStripMenuItem
			size = New Size(186, 24)
			arg_5C8_0.Size = size
			AddressOf Me.SchließenToolStripMenuItem.Text = "Schließen"
			AddressOf Me.BildToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem()() { AddressOf Me.M1ToolStripMenuItem, AddressOf Me.M2ToolStripMenuItem, AddressOf Me.M3ToolStripMenuItem, AddressOf Me.M4ToolStripMenuItem, AddressOf Me.ToolStripMenuItem2, AddressOf Me.S1ToolStripMenuItem, AddressOf Me.S2ToolStripMenuItem, AddressOf Me.S3ToolStripMenuItem, AddressOf Me.S4ToolStripMenuItem })
			AddressOf Me.BildToolStripMenuItem.Font = New Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.BildToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.BildToolStripMenuItem.Name = "BildToolStripMenuItem"
			Dim arg_697_0 As ToolStripItem = AddressOf Me.BildToolStripMenuItem
			size = New Size(46, 24)
			arg_697_0.Size = size
			AddressOf Me.BildToolStripMenuItem.Text = "Bild"
			AddressOf Me.M1ToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.M1ToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.M1ToolStripMenuItem.Name = "M1ToolStripMenuItem"
			Dim arg_6EF_0 As ToolStripItem = AddressOf Me.M1ToolStripMenuItem
			size = New Size(101, 24)
			arg_6EF_0.Size = size
			AddressOf Me.M1ToolStripMenuItem.Text = "M1"
			AddressOf Me.M2ToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.M2ToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.M2ToolStripMenuItem.Name = "M2ToolStripMenuItem"
			Dim arg_747_0 As ToolStripItem = AddressOf Me.M2ToolStripMenuItem
			size = New Size(101, 24)
			arg_747_0.Size = size
			AddressOf Me.M2ToolStripMenuItem.Text = "M2"
			AddressOf Me.M3ToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.M3ToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.M3ToolStripMenuItem.Name = "M3ToolStripMenuItem"
			Dim arg_79F_0 As ToolStripItem = AddressOf Me.M3ToolStripMenuItem
			size = New Size(101, 24)
			arg_79F_0.Size = size
			AddressOf Me.M3ToolStripMenuItem.Text = "M3"
			AddressOf Me.M4ToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.M4ToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.M4ToolStripMenuItem.Name = "M4ToolStripMenuItem"
			Dim arg_7F7_0 As ToolStripItem = AddressOf Me.M4ToolStripMenuItem
			size = New Size(101, 24)
			arg_7F7_0.Size = size
			AddressOf Me.M4ToolStripMenuItem.Text = "M4"
			AddressOf Me.ToolStripMenuItem2.BackColor = Color.Black
			AddressOf Me.ToolStripMenuItem2.ForeColor = Color.Lime
			AddressOf Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
			Dim arg_84E_0 As ToolStripItem = AddressOf Me.ToolStripMenuItem2
			size = New Size(98, 6)
			arg_84E_0.Size = size
			AddressOf Me.S1ToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.S1ToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.S1ToolStripMenuItem.Name = "S1ToolStripMenuItem"
			Dim arg_896_0 As ToolStripItem = AddressOf Me.S1ToolStripMenuItem
			size = New Size(101, 24)
			arg_896_0.Size = size
			AddressOf Me.S1ToolStripMenuItem.Text = "S1"
			AddressOf Me.S2ToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.S2ToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.S2ToolStripMenuItem.Name = "S2ToolStripMenuItem"
			Dim arg_8EE_0 As ToolStripItem = AddressOf Me.S2ToolStripMenuItem
			size = New Size(101, 24)
			arg_8EE_0.Size = size
			AddressOf Me.S2ToolStripMenuItem.Text = "S2"
			AddressOf Me.S3ToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.S3ToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.S3ToolStripMenuItem.Name = "S3ToolStripMenuItem"
			Dim arg_946_0 As ToolStripItem = AddressOf Me.S3ToolStripMenuItem
			size = New Size(101, 24)
			arg_946_0.Size = size
			AddressOf Me.S3ToolStripMenuItem.Text = "S3"
			AddressOf Me.S4ToolStripMenuItem.BackColor = Color.Black
			AddressOf Me.S4ToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.S4ToolStripMenuItem.Name = "S4ToolStripMenuItem"
			Dim arg_99E_0 As ToolStripItem = AddressOf Me.S4ToolStripMenuItem
			size = New Size(101, 24)
			arg_99E_0.Size = size
			AddressOf Me.S4ToolStripMenuItem.Text = "S4"
			AddressOf Me.InfoToolStripMenuItem.Font = New Font("Century Gothic", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.InfoToolStripMenuItem.ForeColor = Color.Lime
			AddressOf Me.InfoToolStripMenuItem.Name = "InfoToolStripMenuItem"
			Dim arg_A03_0 As ToolStripItem = AddressOf Me.InfoToolStripMenuItem
			size = New Size(50, 24)
			arg_A03_0.Size = size
			AddressOf Me.InfoToolStripMenuItem.Text = "Info"
			AddressOf Me.RadiereBTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.RadiereBTN.AutoSize = True
			Dim arg_A46_0 As Control = AddressOf Me.RadiereBTN
			location = New Point(798, 120)
			arg_A46_0.Location = location
			AddressOf Me.RadiereBTN.Name = "RadiereBTN"
			Dim arg_A6E_0 As Control = AddressOf Me.RadiereBTN
			size = New Size(65, 17)
			arg_A6E_0.Size = size
			AddressOf Me.RadiereBTN.TabIndex = 1
			AddressOf Me.RadiereBTN.TabStop = True
			AddressOf Me.RadiereBTN.Text = "Radierer"
			AddressOf Me.RadiereBTN.UseVisualStyleBackColor = True
			AddressOf Me.BleistiftBTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.BleistiftBTN.AutoSize = True
			Dim arg_AD8_0 As Control = AddressOf Me.BleistiftBTN
			location = New Point(798, 143)
			arg_AD8_0.Location = location
			AddressOf Me.BleistiftBTN.Name = "BleistiftBTN"
			Dim arg_B00_0 As Control = AddressOf Me.BleistiftBTN
			size = New Size(58, 17)
			arg_B00_0.Size = size
			AddressOf Me.BleistiftBTN.TabIndex = 2
			AddressOf Me.BleistiftBTN.TabStop = True
			AddressOf Me.BleistiftBTN.Text = "Bleistift"
			AddressOf Me.BleistiftBTN.UseVisualStyleBackColor = True
			AddressOf Me.RechteckBTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.RechteckBTN.AutoSize = True
			Dim arg_B6A_0 As Control = AddressOf Me.RechteckBTN
			location = New Point(699, 143)
			arg_B6A_0.Location = location
			AddressOf Me.RechteckBTN.Name = "RechteckBTN"
			Dim arg_B92_0 As Control = AddressOf Me.RechteckBTN
			size = New Size(72, 17)
			arg_B92_0.Size = size
			AddressOf Me.RechteckBTN.TabIndex = 3
			AddressOf Me.RechteckBTN.TabStop = True
			AddressOf Me.RechteckBTN.Text = "Rechteck"
			AddressOf Me.RechteckBTN.UseVisualStyleBackColor = True
			AddressOf Me.DreieckBTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.DreieckBTN.AutoSize = True
			Dim arg_BF9_0 As Control = AddressOf Me.DreieckBTN
			location = New Point(699, 120)
			arg_BF9_0.Location = location
			AddressOf Me.DreieckBTN.Name = "DreieckBTN"
			Dim arg_C21_0 As Control = AddressOf Me.DreieckBTN
			size = New Size(62, 17)
			arg_C21_0.Size = size
			AddressOf Me.DreieckBTN.TabIndex = 4
			AddressOf Me.DreieckBTN.TabStop = True
			AddressOf Me.DreieckBTN.Text = "Dreieck"
			AddressOf Me.DreieckBTN.UseVisualStyleBackColor = True
			AddressOf Me.KreisBTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.KreisBTN.AutoSize = True
			Dim arg_C8B_0 As Control = AddressOf Me.KreisBTN
			location = New Point(699, 189)
			arg_C8B_0.Location = location
			AddressOf Me.KreisBTN.Name = "KreisBTN"
			Dim arg_CB3_0 As Control = AddressOf Me.KreisBTN
			size = New Size(48, 17)
			arg_CB3_0.Size = size
			AddressOf Me.KreisBTN.TabIndex = 5
			AddressOf Me.KreisBTN.TabStop = True
			AddressOf Me.KreisBTN.Text = "Kreis"
			AddressOf Me.KreisBTN.UseVisualStyleBackColor = True
			AddressOf Me.HalbkreisBTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.HalbkreisBTN.AutoSize = True
			Dim arg_D1D_0 As Control = AddressOf Me.HalbkreisBTN
			location = New Point(699, 212)
			arg_D1D_0.Location = location
			AddressOf Me.HalbkreisBTN.Name = "HalbkreisBTN"
			Dim arg_D45_0 As Control = AddressOf Me.HalbkreisBTN
			size = New Size(69, 17)
			arg_D45_0.Size = size
			AddressOf Me.HalbkreisBTN.TabIndex = 6
			AddressOf Me.HalbkreisBTN.TabStop = True
			AddressOf Me.HalbkreisBTN.Text = "Halbkreis"
			AddressOf Me.HalbkreisBTN.UseVisualStyleBackColor = True
			AddressOf Me.VieleckBTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.VieleckBTN.AutoSize = True
			Dim arg_DAF_0 As Control = AddressOf Me.VieleckBTN
			location = New Point(699, 166)
			arg_DAF_0.Location = location
			AddressOf Me.VieleckBTN.Name = "VieleckBTN"
			Dim arg_DD7_0 As Control = AddressOf Me.VieleckBTN
			size = New Size(60, 17)
			arg_DD7_0.Size = size
			AddressOf Me.VieleckBTN.TabIndex = 7
			AddressOf Me.VieleckBTN.TabStop = True
			AddressOf Me.VieleckBTN.Text = "Vieleck"
			AddressOf Me.VieleckBTN.UseVisualStyleBackColor = True
			AddressOf Me.FüllBTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.FüllBTN.AutoSize = True
			Dim arg_E41_0 As Control = AddressOf Me.FüllBTN
			location = New Point(798, 166)
			arg_E41_0.Location = location
			AddressOf Me.FüllBTN.Name = "FüllBTN"
			Dim arg_E69_0 As Control = AddressOf Me.FüllBTN
			size = New Size(93, 17)
			arg_E69_0.Size = size
			AddressOf Me.FüllBTN.TabIndex = 8
			AddressOf Me.FüllBTN.TabStop = True
			AddressOf Me.FüllBTN.Text = "Füll-Werkzeug"
			AddressOf Me.FüllBTN.UseVisualStyleBackColor = True
			AddressOf Me.ParaleollogrammBTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.ParaleollogrammBTN.AutoSize = True
			Dim arg_ED3_0 As Control = AddressOf Me.ParaleollogrammBTN
			location = New Point(798, 189)
			arg_ED3_0.Location = location
			AddressOf Me.ParaleollogrammBTN.Name = "ParaleollogrammBTN"
			Dim arg_EFB_0 As Control = AddressOf Me.ParaleollogrammBTN
			size = New Size(96, 17)
			arg_EFB_0.Size = size
			AddressOf Me.ParaleollogrammBTN.TabIndex = 9
			AddressOf Me.ParaleollogrammBTN.TabStop = True
			AddressOf Me.ParaleollogrammBTN.Text = "Paralellogramm"
			AddressOf Me.ParaleollogrammBTN.UseVisualStyleBackColor = True
			AddressOf Me.TextBTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.TextBTN.AutoSize = True
			Dim arg_F66_0 As Control = AddressOf Me.TextBTN
			location = New Point(697, 404)
			arg_F66_0.Location = location
			AddressOf Me.TextBTN.Name = "TextBTN"
			Dim arg_F8E_0 As Control = AddressOf Me.TextBTN
			size = New Size(46, 17)
			arg_F8E_0.Size = size
			AddressOf Me.TextBTN.TabIndex = 10
			AddressOf Me.TextBTN.TabStop = True
			AddressOf Me.TextBTN.Text = "Text"
			AddressOf Me.TextBTN.UseVisualStyleBackColor = True
			AddressOf Me.GroupBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.TrackBar1)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.P4BTN)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.P3BTN)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.P2BTN)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.P1BTN)
			AddressOf Me.GroupBox1.FlatStyle = FlatStyle.Flat
			AddressOf Me.GroupBox1.ForeColor = Color.Lime
			Dim arg_1077_0 As Control = AddressOf Me.GroupBox1
			location = New Point(697, 234)
			arg_1077_0.Location = location
			AddressOf Me.GroupBox1.Name = "GroupBox1"
			Dim arg_10A5_0 As Control = AddressOf Me.GroupBox1
			size = New Size(200, 164)
			arg_10A5_0.Size = size
			AddressOf Me.GroupBox1.TabIndex = 11
			AddressOf Me.GroupBox1.TabStop = False
			AddressOf Me.GroupBox1.Text = "Stifte"
			Dim arg_10E4_0 As Control = AddressOf Me.TrackBar1
			location = New Point(6, 111)
			arg_10E4_0.Location = location
			AddressOf Me.TrackBar1.Name = "TrackBar1"
			Dim arg_110F_0 As Control = AddressOf Me.TrackBar1
			size = New Size(188, 45)
			arg_110F_0.Size = size
			AddressOf Me.TrackBar1.TabIndex = 15
			AddressOf Me.P4BTN.AutoSize = True
			Dim arg_113E_0 As Control = AddressOf Me.P4BTN
			location = New Point(6, 88)
			arg_113E_0.Location = location
			AddressOf Me.P4BTN.Name = "P4BTN"
			Dim arg_1166_0 As Control = AddressOf Me.P4BTN
			size = New Size(82, 17)
			arg_1166_0.Size = size
			AddressOf Me.P4BTN.TabIndex = 14
			AddressOf Me.P4BTN.TabStop = True
			AddressOf Me.P4BTN.Text = "Eigener Stift"
			AddressOf Me.P4BTN.UseVisualStyleBackColor = True
			AddressOf Me.P3BTN.AutoSize = True
			Dim arg_11BD_0 As Control = AddressOf Me.P3BTN
			location = New Point(6, 65)
			arg_11BD_0.Location = location
			AddressOf Me.P3BTN.Name = "P3BTN"
			Dim arg_11E5_0 As Control = AddressOf Me.P3BTN
			size = New Size(52, 17)
			arg_11E5_0.Size = size
			AddressOf Me.P3BTN.TabIndex = 13
			AddressOf Me.P3BTN.TabStop = True
			AddressOf Me.P3BTN.Text = "Stift 3"
			AddressOf Me.P3BTN.UseVisualStyleBackColor = True
			AddressOf Me.P2BTN.AutoSize = True
			Dim arg_123C_0 As Control = AddressOf Me.P2BTN
			location = New Point(6, 42)
			arg_123C_0.Location = location
			AddressOf Me.P2BTN.Name = "P2BTN"
			Dim arg_1264_0 As Control = AddressOf Me.P2BTN
			size = New Size(52, 17)
			arg_1264_0.Size = size
			AddressOf Me.P2BTN.TabIndex = 12
			AddressOf Me.P2BTN.TabStop = True
			AddressOf Me.P2BTN.Text = "Stift 2"
			AddressOf Me.P2BTN.UseVisualStyleBackColor = True
			AddressOf Me.P1BTN.AutoSize = True
			Dim arg_12BB_0 As Control = AddressOf Me.P1BTN
			location = New Point(6, 19)
			arg_12BB_0.Location = location
			AddressOf Me.P1BTN.Name = "P1BTN"
			Dim arg_12E3_0 As Control = AddressOf Me.P1BTN
			size = New Size(52, 17)
			arg_12E3_0.Size = size
			AddressOf Me.P1BTN.TabIndex = 11
			AddressOf Me.P1BTN.TabStop = True
			AddressOf Me.P1BTN.Text = "Stift 1"
			AddressOf Me.P1BTN.UseVisualStyleBackColor = True
			AddressOf Me.FontButton.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.FontButton.BackColor = Color.Black
			AddressOf Me.FontButton.FlatStyle = FlatStyle.Flat
			Dim arg_135E_0 As Control = AddressOf Me.FontButton
			location = New Point(697, 427)
			arg_135E_0.Location = location
			AddressOf Me.FontButton.Name = "FontButton"
			Dim arg_1389_0 As Control = AddressOf Me.FontButton
			size = New Size(200, 23)
			arg_1389_0.Size = size
			AddressOf Me.FontButton.TabIndex = 12
			AddressOf Me.FontButton.Text = "Schrift"
			AddressOf Me.FontButton.UseVisualStyleBackColor = False
			AddressOf Me.Color1BTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Color1BTN.BackColor = Color.Black
			AddressOf Me.Color1BTN.FlatStyle = FlatStyle.Flat
			Dim arg_13F5_0 As Control = AddressOf Me.Color1BTN
			location = New Point(697, 27)
			arg_13F5_0.Location = location
			AddressOf Me.Color1BTN.Name = "Color1BTN"
			Dim arg_141D_0 As Control = AddressOf Me.Color1BTN
			size = New Size(89, 69)
			arg_141D_0.Size = size
			AddressOf Me.Color1BTN.TabIndex = 14
			AddressOf Me.Color1BTN.Text = "Farbe 1"
			AddressOf Me.Color1BTN.UseVisualStyleBackColor = False
			AddressOf Me.Color2BTN.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Color2BTN.BackColor = Color.Black
			AddressOf Me.Color2BTN.FlatStyle = FlatStyle.Flat
			Dim arg_1489_0 As Control = AddressOf Me.Color2BTN
			location = New Point(802, 27)
			arg_1489_0.Location = location
			AddressOf Me.Color2BTN.Name = "Color2BTN"
			Dim arg_14B1_0 As Control = AddressOf Me.Color2BTN
			size = New Size(89, 69)
			arg_14B1_0.Size = size
			AddressOf Me.Color2BTN.TabIndex = 15
			AddressOf Me.Color2BTN.Text = "Farbe 2"
			AddressOf Me.Color2BTN.UseVisualStyleBackColor = False
			AddressOf Me.SaveFileDialog1.FileName = "Bild"
			AddressOf Me.PictureBox1.BackColor = Color.White
			Dim arg_1511_0 As Control = AddressOf Me.PictureBox1
			location = New Point(12, 27)
			arg_1511_0.Location = location
			AddressOf Me.PictureBox1.Name = "PictureBox1"
			Dim arg_153F_0 As Control = AddressOf Me.PictureBox1
			size = New Size(521, 473)
			arg_153F_0.Size = size
			AddressOf Me.PictureBox1.TabIndex = 16
			AddressOf Me.PictureBox1.TabStop = False
			AddressOf Me.Label1.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Label1.AutoSize = True
			Dim arg_158B_0 As Control = AddressOf Me.Label1
			location = New Point(700, 104)
			arg_158B_0.Location = location
			AddressOf Me.Label1.Name = "Label1"
			Dim arg_15B3_0 As Control = AddressOf Me.Label1
			size = New Size(42, 13)
			arg_15B3_0.Size = size
			AddressOf Me.Label1.TabIndex = 17
			AddressOf Me.Label1.Text = "Formen"
			AddressOf Me.PictureBox2.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.PictureBox2.BackColor = Color.Lime
			Dim arg_1607_0 As Control = AddressOf Me.PictureBox2
			location = New Point(782, 104)
			arg_1607_0.Location = location
			AddressOf Me.PictureBox2.Name = "PictureBox2"
			Dim arg_162F_0 As Control = AddressOf Me.PictureBox2
			size = New Size(10, 125)
			arg_162F_0.Size = size
			AddressOf Me.PictureBox2.TabIndex = 18
			AddressOf Me.PictureBox2.TabStop = False
			AddressOf Me.Label2.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Label2.AutoSize = True
			Dim arg_167B_0 As Control = AddressOf Me.Label2
			location = New Point(795, 104)
			arg_167B_0.Location = location
			AddressOf Me.Label2.Name = "Label2"
			Dim arg_16A3_0 As Control = AddressOf Me.Label2
			size = New Size(53, 13)
			arg_16A3_0.Size = size
			AddressOf Me.Label2.TabIndex = 19
			AddressOf Me.Label2.Text = "Sonstiges"
			AddressOf Me.TextBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.TextBox1.BackColor = Color.Black
			AddressOf Me.TextBox1.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.TextBox1.ForeColor = Color.Lime
			Dim arg_1716_0 As Control = AddressOf Me.TextBox1
			location = New Point(697, 456)
			arg_1716_0.Location = location
			AddressOf Me.TextBox1.Multiline = True
			AddressOf Me.TextBox1.Name = "TextBox1"
			Dim arg_174D_0 As Control = AddressOf Me.TextBox1
			size = New Size(200, 44)
			arg_174D_0.Size = size
			AddressOf Me.TextBox1.TabIndex = 20
			AddressOf Me.TextBox1.Text = "Ihr Text"
			AddressOf Me.Button1.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button1.BackColor = Color.Black
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			Dim arg_17AC_0 As Control = AddressOf Me.Button1
			location = New Point(870, 0)
			arg_17AC_0.Location = location
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_17D4_0 As Control = AddressOf Me.Button1
			size = New Size(21, 21)
			arg_17D4_0.Size = size
			AddressOf Me.Button1.TabIndex = 21
			AddressOf Me.Button1.Text = "+"
			AddressOf Me.Button1.UseVisualStyleBackColor = False
			AddressOf Me.Button1.Visible = False
			AddressOf Me.TimerMover.Interval = 1
			Dim autoScaleDimensions As SizeF = New SizeF(6F, 13F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			size = New Size(902, 506)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.Button1)
			Me.Controls.Add(AddressOf Me.TextBox1)
			Me.Controls.Add(AddressOf Me.Label2)
			Me.Controls.Add(AddressOf Me.PictureBox2)
			Me.Controls.Add(AddressOf Me.Label1)
			Me.Controls.Add(AddressOf Me.PictureBox1)
			Me.Controls.Add(AddressOf Me.Color2BTN)
			Me.Controls.Add(AddressOf Me.Color1BTN)
			Me.Controls.Add(AddressOf Me.FontButton)
			Me.Controls.Add(AddressOf Me.GroupBox1)
			Me.Controls.Add(AddressOf Me.TextBTN)
			Me.Controls.Add(AddressOf Me.ParaleollogrammBTN)
			Me.Controls.Add(AddressOf Me.FüllBTN)
			Me.Controls.Add(AddressOf Me.VieleckBTN)
			Me.Controls.Add(AddressOf Me.HalbkreisBTN)
			Me.Controls.Add(AddressOf Me.KreisBTN)
			Me.Controls.Add(AddressOf Me.DreieckBTN)
			Me.Controls.Add(AddressOf Me.RechteckBTN)
			Me.Controls.Add(AddressOf Me.BleistiftBTN)
			Me.Controls.Add(AddressOf Me.RadiereBTN)
			Me.Controls.Add(AddressOf Me.MenuStrip1)
			Me.DoubleBuffered = True
			Me.ForeColor = Color.Lime
			Me.FormBorderStyle = FormBorderStyle.SizableToolWindow
			Me.MainMenuStrip = AddressOf Me.MenuStrip1
			Me.Name = "Painter"
			Me.Text = "Painter"
			AddressOf Me.MenuStrip1.ResumeLayout(False)
			AddressOf Me.MenuStrip1.PerformLayout()
			AddressOf Me.GroupBox1.ResumeLayout(False)
			AddressOf Me.GroupBox1.PerformLayout()
			(CType(AddressOf Me.TrackBar1, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).EndInit()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		Private Sub Painter_Load(sender As Object, e As EventArgs)
			Me.CurrentFont = Me.Font
			AddressOf Me.FontButton.Text = Me.CurrentFont.ToString()
			AddressOf Me.Color1BTN.BackColor = Color.Blue
			AddressOf Me.Color2BTN.BackColor = Color.DeepSkyBlue
			Me.g = Graphics.FromImage(Me.LastImage)
			Me.g.Clear(Color.White)
			Me.UpdateImage()
			Me.ReloadPen(Me.PenWidth, Me.CurrentColor)
		End Sub

		Public Function UpPixelHaseSameColor(X As Integer, Y As Integer, Col As Color) As Boolean
			Dim result As Boolean = False
			' The following expression was wrapped in a checked-expression
			If Y > 0 AndAlso Me.LastImage.GetPixel(X, Y - 1) = Col Then
				result = True
			End If
			Return result
		End Function

		Public Function DownPixelHaseSameColor(X As Integer, Y As Integer, Col As Color) As Boolean
			Dim result As Boolean = False
			' The following expression was wrapped in a checked-expression
			If Y < Me.LastImage.Height - 1 AndAlso Me.LastImage.GetPixel(X, Y + 1) = Col Then
				result = True
			End If
			Return result
		End Function

		Public Function RightPixelHaseSameColor(X As Integer, Y As Integer, Col As Color) As Boolean
			Dim result As Boolean = False
			' The following expression was wrapped in a checked-expression
			If X < Me.LastImage.Width - 1 AndAlso Me.LastImage.GetPixel(X + 1, Y) = Col Then
				result = True
			End If
			Return result
		End Function

		Public Function LeftPixelHaseSameColor(X As Integer, Y As Integer, Col As Color) As Boolean
			Dim result As Boolean = False
			' The following expression was wrapped in a checked-expression
			If X > 0 AndAlso Me.LastImage.GetPixel(X - 1, Y) = Col Then
				result = True
			End If
			Return result
		End Function

		Public Function FillRegion(X As Integer, Y As Integer, FillCol As Color) As Boolean
			If X < 0 Or X > Me.LastImage.Width Or Y < 0 Or Y > Me.LastImage.Height Then
				Return False
			End If
			Application.DoEvents()
			Dim points As Stack = New Stack()
			Dim arg_47_0 As Stack = points
			Dim point As Point = New Point(X, Y)
			arg_47_0.Push(point)
			Dim Pointcolor As Color = Me.LastImage.GetPixel(X, Y)
			' The following expression was wrapped in a checked-statement
			Do
				Dim expr_60 As Object = points.Pop()
				Dim point2 As Point
				Dim p As Point = If((expr_60 IsNot Nothing), (CType(expr_60, Point)), point2)
				Me.LastImage.SetPixel(p.X, p.Y, FillCol)
				If Me.UpPixelHaseSameColor(p.X, p.Y, Pointcolor) Then
					Dim arg_C3_0 As Stack = points
					point = New Point(p.X, p.Y - 1)
					arg_C3_0.Push(point)
				End If
				If Me.DownPixelHaseSameColor(p.X, p.Y, Pointcolor) Then
					Dim arg_FE_0 As Stack = points
					point = New Point(p.X, p.Y + 1)
					arg_FE_0.Push(point)
				End If
				If Me.RightPixelHaseSameColor(p.X, p.Y, Pointcolor) Then
					Dim arg_139_0 As Stack = points
					point = New Point(p.X + 1, p.Y)
					arg_139_0.Push(point)
				End If
				If Me.LeftPixelHaseSameColor(p.X, p.Y, Pointcolor) Then
					Dim arg_174_0 As Stack = points
					point = New Point(p.X - 1, p.Y)
					arg_174_0.Push(point)
				End If
			Loop While points.Count > 0
			Return True
		End Function

		Public Sub UpdateImage()
			Me.g = Graphics.FromImage(Me.LastImage)
			AddressOf Me.PictureBox1.Image = Me.LastImage
		End Sub

		Public Sub ReloadPen(PenWd As Single, CurColor As Color)
			Me.PenPoint = New Pen(CurColor, PenWd)
		End Sub

		Private Sub PictureBox1_MouseDown(sender As Object, e As MouseEventArgs)
			' The following expression was wrapped in a checked-statement
			If e.Button = MouseButtons.Left Then
				If Not Me.drawing Then
					Me.startLocation = e.Location
					Me.drawing = True
					If AddressOf Me.VieleckBTN.Checked Then
						If Me.TempLocation.X = -1 Then
							Me.TempLocation = Me.startLocation
							Me.TempLocation2 = Me.startLocation
						End If
						Me.endLocation = e.Location
						Me.g.DrawLine(Me.PenPoint, Me.TempLocation, Me.endLocation)
						Me.TempLocation = Me.endLocation
					Else
						If AddressOf Me.DreieckBTN.Checked Then
							If Me.TempLocation.X = -1 Then
								Me.TempLocation = Me.startLocation
								Me.TempLocation2 = Me.startLocation
							End If
							If Me.NumberOfAngle <= 2 Then
								Me.endLocation = e.Location
								Me.g.DrawLine(Me.PenPoint, Me.TempLocation, Me.endLocation)
								Me.TempLocation = Me.endLocation
								If Me.NumberOfAngle = 2 Then
									Me.g.DrawLine(Me.PenPoint, Me.TempLocation, Me.TempLocation2)
									Me.TempLocation = New Point(-1, -1)
									Me.NumberOfAngle = 0
								Else
									Me.NumberOfAngle += 1
								End If
							End If
						End If
					End If
				End If
			Else
				If e.Button = MouseButtons.Right AndAlso AddressOf Me.VieleckBTN.Checked AndAlso Me.TempLocation.X <> -1 Then
					Me.endLocation = e.Location
					Me.g.DrawLine(Me.PenPoint, Me.TempLocation, Me.TempLocation2)
					Me.TempLocation = New Point(-1, -1)
				End If
			End If
		End Sub

		Private Sub PictureBox1_MouseMove(sender As Object, e As MouseEventArgs)
			If Me.drawing Then
				If AddressOf Me.BleistiftBTN.Checked Then
					Me.g.DrawLine(Me.PenPoint, Me.startLocation.X, Me.startLocation.Y, e.X, e.Y)
					Me.startLocation = e.Location
					Me.UpdateImage()
				Else
					If AddressOf Me.RadiereBTN.Checked Then
						Dim p As Pen = New Pen(Color.White, Me.PenWidth)
						Me.g.DrawLine(p, Me.startLocation.X, Me.startLocation.Y, e.X, e.Y)
						Me.startLocation = e.Location
						Me.UpdateImage()
					End If
				End If
			End If
		End Sub

		Private Sub PictureBox1_MouseUp(sender As Object, e As MouseEventArgs)
			' The following expression was wrapped in a checked-statement
			If Me.drawing Then
				If AddressOf Me.RechteckBTN.Checked Then
					Me.endLocation = e.Location
					Dim s As Point
					s.X = Me.endLocation.X - Me.startLocation.X
					If s.X < 0 Then
						Me.startLocation.X = Me.endLocation.X
					End If
					s.Y = Me.endLocation.Y - Me.startLocation.Y
					If s.Y < 0 Then
						Me.startLocation.Y = Me.endLocation.Y
					End If
					s.X = Math.Abs(s.X)
					s.Y = Math.Abs(s.Y)
					Dim arg_EA_0 As Graphics = Me.g
					Dim arg_EA_1 As Pen = Me.PenPoint
					Dim rect As Rectangle = New Rectangle(Me.startLocation, CType(s, Size))
					arg_EA_0.DrawRectangle(arg_EA_1, rect)
				Else
					If AddressOf Me.KreisBTN.Checked Then
						Me.endLocation = e.Location
						Dim s2 As Point
						s2.X = Me.endLocation.X - Me.startLocation.X
						If s2.X < 0 Then
							Me.startLocation.X = Me.endLocation.X
						End If
						s2.Y = Me.endLocation.Y - Me.startLocation.Y
						If s2.Y < 0 Then
							Me.startLocation.Y = Me.endLocation.Y
						End If
						s2.X = Math.Abs(s2.X)
						s2.Y = Math.Abs(s2.Y)
						If s2.X > s2.Y Then
							s2.Y = s2.X
						Else
							s2.X = s2.Y
						End If
						Dim arg_201_0 As Graphics = Me.g
						Dim arg_201_1 As Pen = Me.PenPoint
						Dim rect As Rectangle = New Rectangle(Me.startLocation, CType(s2, Size))
						arg_201_0.DrawEllipse(arg_201_1, rect)
					Else
						If AddressOf Me.HalbkreisBTN.Checked Then
							Me.endLocation = e.Location
							Dim s3 As Point
							s3.X = Me.endLocation.X - Me.startLocation.X
							If s3.X < 0 Then
								Me.startLocation.X = Me.endLocation.X
							End If
							s3.Y = Me.endLocation.Y - Me.startLocation.Y
							If s3.Y < 0 Then
								Me.startLocation.Y = Me.endLocation.Y
							End If
							s3.X = Math.Abs(s3.X)
							s3.Y = Math.Abs(s3.Y)
							If s3.X > s3.Y Then
								s3.Y = s3.X
							Else
								s3.X = s3.Y
							End If
							Dim arg_322_0 As Graphics = Me.g
							Dim arg_322_1 As Pen = Me.PenPoint
							Dim rect As Rectangle = New Rectangle(Me.startLocation, CType(s3, Size))
							arg_322_0.DrawArc(arg_322_1, rect, 0F, -180F)
						Else
							If AddressOf Me.ParaleollogrammBTN.Checked Then
								Me.endLocation = e.Location
								Dim s4 As Point
								s4.X = Me.endLocation.X - Me.startLocation.X
								If s4.X < 0 Then
									Dim tmp As Integer = Me.startLocation.X
									Me.startLocation.X = Me.endLocation.X
									Me.endLocation.X = tmp
								End If
								s4.Y = Me.endLocation.Y - Me.startLocation.Y
								If s4.Y < 0 Then
									Dim tmp2 As Integer = Me.startLocation.Y
									Me.startLocation.Y = Me.endLocation.Y
									Me.endLocation.Y = tmp2
								End If
								s4.X = Math.Abs(s4.X)
								s4.Y = Math.Abs(s4.Y)
								Dim p As Point() = New Point(4 - 1) {}
								' The following expression was wrapped in a unchecked-expression
								p(0) = New Point(CInt(Math.Round(CDec(Me.startLocation.X) + CDec(s4.X) / 5.0)), Me.startLocation.Y)
								p(1) = New Point(Me.startLocation.X + s4.X, Me.startLocation.Y)
								' The following expression was wrapped in a unchecked-expression
								p(2) = New Point(CInt(Math.Round(CDec(Me.endLocation.X) - CDec(s4.X) / 5.0)), Me.endLocation.Y)
								p(3) = New Point(Me.endLocation.X - s4.X, Me.endLocation.Y)
								Me.g.DrawPolygon(Me.PenPoint, p)
							Else
								If AddressOf Me.FüllBTN.Checked Then
									Me.FillRegion(e.X, e.Y, Me.CurrentColor)
								Else
									If AddressOf Me.TextBTN.Checked Then
										Dim txt As String = AddressOf Me.TextBox1.Text
										Me.g.DrawString(txt, Me.CurrentFont, New HatchBrush(HatchStyle.BackwardDiagonal, Me.CurrentColor), CSng(e.X), CSng(e.Y))
									End If
								End If
							End If
						End If
					End If
				End If
			End If
			Me.drawing = False
			Me.UpdateImage()
		End Sub

		Private Sub TriangleRadioButton_CheckedChanged(sender As Object, e As EventArgs)
			Me.TempLocation = New Point(-1, -1)
		End Sub

		Private Sub Color1BTN_Click(sender As Object, e As EventArgs)
			If AddressOf Me.ColorDialog1.ShowDialog() = DialogResult.OK Then
				Me.CurrentColor = AddressOf Me.ColorDialog1.Color
				AddressOf Me.Color1BTN.BackColor = Me.CurrentColor
				Me.ReloadPen(Me.PenWidth, Me.CurrentColor)
			End If
		End Sub

		Private Sub Color2BTN_Click(sender As Object, e As EventArgs)
			If AddressOf Me.ColorDialog1.ShowDialog() = DialogResult.OK Then
				Me.CurrentColor2 = AddressOf Me.ColorDialog1.Color
				AddressOf Me.Color2BTN.BackColor = Me.CurrentColor2
			End If
		End Sub

		Private Sub P1BTN_CheckedChanged(sender As Object, e As EventArgs)
			Me.PenWidth = 1F
			Me.ReloadPen(Me.PenWidth, Me.CurrentColor)
		End Sub

		Private Sub P2BTN_CheckedChanged(sender As Object, e As EventArgs)
			Me.PenWidth = 5F
			Me.ReloadPen(Me.PenWidth, Me.CurrentColor)
		End Sub

		Private Sub P3BTN_CheckedChanged(sender As Object, e As EventArgs)
			Me.PenWidth = 10F
			Me.ReloadPen(Me.PenWidth, Me.CurrentColor)
		End Sub

		Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs)
			If AddressOf Me.P4BTN.Checked Then
				Me.PenWidth = CSng(AddressOf Me.TrackBar1.Value)
				Me.ReloadPen(Me.PenWidth, Me.CurrentColor)
			End If
		End Sub

		Private Sub ClearToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.ClearScreen()
		End Sub

		Public Sub ClearScreen()
			Me.g = Graphics.FromImage(Me.LastImage)
			Me.g.Clear(Color.White)
			Me.UpdateImage()
		End Sub

		Private Sub NeuToolStripMenuItem_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(Me.SavedFileAddress, "", False) = 0 Then
				Dim result As Integer = CInt(Interaction.MsgBox("Wollen sie dieses Bild speichern?", MsgBoxStyle.YesNo, Nothing))
				If result = 6 Then
					AddressOf Me.SaveFileDialog1.Filter = "Bitmap File (*.bmp)|*.bmp"
					If AddressOf Me.SaveFileDialog1.ShowDialog() = DialogResult.OK Then
						Me.SavedFileAddress = AddressOf Me.SaveFileDialog1.FileName
						Me.LastImage.Save(Me.SavedFileAddress)
						Me.Text = AddressOf Me.SaveFileDialog1.FileName
					End If
				End If
			End If
			Me.g.Clear(Color.White)
			Me.UpdateImage()
			Me.SavedFileAddress = ""
		End Sub

		Private Sub SpeichernToolStripMenuItem_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(Me.SavedFileAddress, "", False) = 0 Then
				AddressOf Me.SaveFileDialog1.Filter = "Bitmap File (*.bmp)|*.bmp"
				If AddressOf Me.SaveFileDialog1.ShowDialog() = DialogResult.OK Then
					Me.SavedFileAddress = AddressOf Me.SaveFileDialog1.FileName
					Me.LastImage.Save(Me.SavedFileAddress)
					Me.Text = AddressOf Me.SaveFileDialog1.FileName
				End If
			Else
				Me.LastImage.Save(Me.SavedFileAddress)
				Me.Text = AddressOf Me.SaveFileDialog1.FileName
			End If
		End Sub

		Private Sub SpeichernAlsToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf Me.SaveFileDialog1.Filter = "Bitmap File (*.bmp)|*.bmp"
			If AddressOf Me.SaveFileDialog1.ShowDialog() = DialogResult.OK Then
				Me.SavedFileAddress = AddressOf Me.SaveFileDialog1.FileName
				Me.LastImage.Save(Me.SavedFileAddress)
				Me.Text = AddressOf Me.SaveFileDialog1.FileName
			End If
		End Sub

		Private Sub M1ToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.M1 = CType(Me.LastImage.Clone(), Bitmap)
		End Sub

		Private Sub M2ToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.M2 = CType(Me.LastImage.Clone(), Bitmap)
		End Sub

		Private Sub M3ToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.M3 = CType(Me.LastImage.Clone(), Bitmap)
		End Sub

		Private Sub M4ToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.M4 = CType(Me.LastImage.Clone(), Bitmap)
		End Sub

		Private Sub S1ToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.LastImage = CType(Me.M1.Clone(), Bitmap)
			Me.UpdateImage()
		End Sub

		Private Sub S2ToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.LastImage = CType(Me.M2.Clone(), Bitmap)
			Me.UpdateImage()
		End Sub

		Private Sub S3ToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.LastImage = CType(Me.M3.Clone(), Bitmap)
			Me.UpdateImage()
		End Sub

		Private Sub S4ToolStripMenuItem_Click(sender As Object, e As EventArgs)
			Me.LastImage = CType(Me.M4.Clone(), Bitmap)
			Me.UpdateImage()
		End Sub

		Private Sub M1ToolStripMenuItem_Click_1(sender As Object, e As EventArgs)
		End Sub

		Private Sub InfoToolStripMenuItem_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.PainterInfo.MdiParent = AddressOf AddressOf MyProject.Forms.MDIParent1
			AddressOf AddressOf MyProject.Forms.PainterInfo.Show()
		End Sub

		Private Sub BildToolStripMenuItem_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub DateiImageToolStripMenuItem_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			AddressOf Me.TimerMover.Start()
		End Sub

		Private Sub Button1_DragDrop(sender As Object, e As DragEventArgs)
		End Sub

		Private Sub TimerMover_Tick(sender As Object, e As EventArgs)
		End Sub
	End Class
End Namespace
