Imports EvoroUI.My
Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class GreenStart
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("ListBox1")>
		Private _ListBox1 As ListBox

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("Button2")>
		Private _Button2 As Button

		<AccessedThroughProperty("Button3")>
		Private _Button3 As Button

		<AccessedThroughProperty("Panel1")>
		Private _Panel1 As Panel

		<AccessedThroughProperty("TextBox1")>
		Private _TextBox1 As TextBox

		<AccessedThroughProperty("Button4")>
		Private _Button4 As Button

		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		<AccessedThroughProperty("SplitContainer1")>
		Private _SplitContainer1 As SplitContainer

		<AccessedThroughProperty("Button5")>
		Private _Button5 As Button

		<AccessedThroughProperty("Panel2")>
		Private _Panel2 As Panel

		<AccessedThroughProperty("TextBox2")>
		Private _TextBox2 As TextBox

		<AccessedThroughProperty("Button6")>
		Private _Button6 As Button

		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		<AccessedThroughProperty("RAM_Bar")>
		Private _RAM_Bar As PictureBox

		<AccessedThroughProperty("PictureBox4")>
		Private _PictureBox4 As PictureBox

		<AccessedThroughProperty("Aktualisieren")>
		Private _Aktualisieren As Timer

		<AccessedThroughProperty("GroupBox1")>
		Private _GroupBox1 As GroupBox

		Private pfad As String

		Private PerCPU As PerformanceCounter

		Friend Overridable Property ListBox1() As ListBox
			Get
				Return Me._ListBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Me._ListBox1 = value
			End Set
		End Property

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button1_Click_1
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.Click, value2
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button2() As Button
			Get
				Return Me._Button2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button2_Click
				If Me._Button2 IsNot Nothing Then
					RemoveHandler Me._Button2.Click, value2
				End If
				Me._Button2 = value
				If Me._Button2 IsNot Nothing Then
					AddHandler Me._Button2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button3() As Button
			Get
				Return Me._Button3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button3_Click
				If Me._Button3 IsNot Nothing Then
					RemoveHandler Me._Button3.Click, value2
				End If
				Me._Button3 = value
				If Me._Button3 IsNot Nothing Then
					AddHandler Me._Button3.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Panel1() As Panel
			Get
				Return Me._Panel1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._Panel1 = value
			End Set
		End Property

		Friend Overridable Property TextBox1() As TextBox
			Get
				Return Me._TextBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Me._TextBox1 = value
			End Set
		End Property

		Friend Overridable Property Button4() As Button
			Get
				Return Me._Button4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button4_Click
				If Me._Button4 IsNot Nothing Then
					RemoveHandler Me._Button4.Click, value2
				End If
				Me._Button4 = value
				If Me._Button4 IsNot Nothing Then
					AddHandler Me._Button4.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Timer1() As Timer
			Get
				Return Me._Timer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer1_Tick
				If Me._Timer1 IsNot Nothing Then
					RemoveHandler Me._Timer1.Tick, value2
				End If
				Me._Timer1 = value
				If Me._Timer1 IsNot Nothing Then
					AddHandler Me._Timer1.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property SplitContainer1() As SplitContainer
			Get
				Return Me._SplitContainer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As SplitContainer)
				Me._SplitContainer1 = value
			End Set
		End Property

		Friend Overridable Property Button5() As Button
			Get
				Return Me._Button5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button5_Click
				If Me._Button5 IsNot Nothing Then
					RemoveHandler Me._Button5.Click, value2
				End If
				Me._Button5 = value
				If Me._Button5 IsNot Nothing Then
					AddHandler Me._Button5.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Panel2() As Panel
			Get
				Return Me._Panel2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._Panel2 = value
			End Set
		End Property

		Friend Overridable Property TextBox2() As TextBox
			Get
				Return Me._TextBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As TextBox)
				Dim value2 As EventHandler = AddressOf Me.TextBox2_TextChanged
				If Me._TextBox2 IsNot Nothing Then
					RemoveHandler Me._TextBox2.TextChanged, value2
				End If
				Me._TextBox2 = value
				If Me._TextBox2 IsNot Nothing Then
					AddHandler Me._TextBox2.TextChanged, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button6() As Button
			Get
				Return Me._Button6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button6_Click
				If Me._Button6 IsNot Nothing Then
					RemoveHandler Me._Button6.Click, value2
				End If
				Me._Button6 = value
				If Me._Button6 IsNot Nothing Then
					AddHandler Me._Button6.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Label2() As Label
			Get
				Return Me._Label2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		Friend Overridable Property RAM_Bar() As PictureBox
			Get
				Return Me._RAM_Bar
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._RAM_Bar = value
			End Set
		End Property

		Friend Overridable Property PictureBox4() As PictureBox
			Get
				Return Me._PictureBox4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox4 = value
			End Set
		End Property

		Friend Overridable Property Aktualisieren() As Timer
			Get
				Return Me._Aktualisieren
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Aktualisieren_Tick
				If Me._Aktualisieren IsNot Nothing Then
					RemoveHandler Me._Aktualisieren.Tick, value2
				End If
				Me._Aktualisieren = value
				If Me._Aktualisieren IsNot Nothing Then
					AddHandler Me._Aktualisieren.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property GroupBox1() As GroupBox
			Get
				Return Me._GroupBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Me._GroupBox1 = value
			End Set
		End Property

		Public Sub New()
			AddHandler MyBase.MouseHover, AddressOf Me.Form2_MouseHover
			AddHandler MyBase.Load, AddressOf Me.Form2_Load
			Me.PerCPU = New PerformanceCounter()
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Container()
			AddressOf Me.ListBox1 = New ListBox()
			AddressOf Me.Button1 = New Button()
			AddressOf Me.Button2 = New Button()
			AddressOf Me.Button3 = New Button()
			AddressOf Me.Panel1 = New Panel()
			AddressOf Me.TextBox1 = New TextBox()
			AddressOf Me.Button4 = New Button()
			AddressOf Me.Timer1 = New Timer(Me.components)
			AddressOf Me.SplitContainer1 = New SplitContainer()
			AddressOf Me.GroupBox1 = New GroupBox()
			AddressOf Me.RAM_Bar = New PictureBox()
			AddressOf Me.Label2 = New Label()
			AddressOf Me.PictureBox4 = New PictureBox()
			AddressOf Me.Button5 = New Button()
			AddressOf Me.Panel2 = New Panel()
			AddressOf Me.TextBox2 = New TextBox()
			AddressOf Me.Button6 = New Button()
			AddressOf Me.Aktualisieren = New Timer(Me.components)
			AddressOf Me.Panel1.SuspendLayout()
			(CType(AddressOf Me.SplitContainer1, ISupportInitialize)).BeginInit()
			AddressOf Me.SplitContainer1.Panel1.SuspendLayout()
			AddressOf Me.SplitContainer1.Panel2.SuspendLayout()
			AddressOf Me.SplitContainer1.SuspendLayout()
			AddressOf Me.GroupBox1.SuspendLayout()
			(CType(AddressOf Me.RAM_Bar, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox4, ISupportInitialize)).BeginInit()
			AddressOf Me.Panel2.SuspendLayout()
			Me.SuspendLayout()
			AddressOf Me.ListBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.ListBox1.BackColor = Color.FromArgb(50, 50, 50)
			AddressOf Me.ListBox1.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.ListBox1.Font = New Font("Courier New", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.ListBox1.ForeColor = Color.Lime
			AddressOf Me.ListBox1.FormattingEnabled = True
			AddressOf Me.ListBox1.ItemHeight = 23
			Dim arg_1D5_0 As Control = AddressOf Me.ListBox1
			Dim location As Point = New Point(6, 5)
			arg_1D5_0.Location = location
			Dim arg_1ED_0 As Control = AddressOf Me.ListBox1
			Dim margin As Padding = New Padding(6, 5, 6, 5)
			arg_1ED_0.Margin = margin
			AddressOf Me.ListBox1.Name = "ListBox1"
			Dim arg_21B_0 As Control = AddressOf Me.ListBox1
			Dim size As Size = New Size(545, 462)
			arg_21B_0.Size = size
			AddressOf Me.ListBox1.TabIndex = 0
			AddressOf Me.Button1.Cursor = Cursors.Hand
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			Dim arg_258_0 As Control = AddressOf Me.Button1
			location = New Point(6, 5)
			arg_258_0.Location = location
			Dim arg_270_0 As Control = AddressOf Me.Button1
			margin = New Padding(6, 5, 6, 5)
			arg_270_0.Margin = margin
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_29B_0 As Control = AddressOf Me.Button1
			size = New Size(228, 53)
			arg_29B_0.Size = size
			AddressOf Me.Button1.TabIndex = 1
			AddressOf Me.Button1.Text = "Ausführen"
			AddressOf Me.Button1.UseVisualStyleBackColor = True
			AddressOf Me.Button2.Cursor = Cursors.Hand
			AddressOf Me.Button2.FlatStyle = FlatStyle.Flat
			Dim arg_2F5_0 As Control = AddressOf Me.Button2
			location = New Point(6, 68)
			arg_2F5_0.Location = location
			Dim arg_30D_0 As Control = AddressOf Me.Button2
			margin = New Padding(6, 5, 6, 5)
			arg_30D_0.Margin = margin
			AddressOf Me.Button2.Name = "Button2"
			Dim arg_338_0 As Control = AddressOf Me.Button2
			size = New Size(228, 53)
			arg_338_0.Size = size
			AddressOf Me.Button2.TabIndex = 2
			AddressOf Me.Button2.Text = "Laden..."
			AddressOf Me.Button2.UseVisualStyleBackColor = True
			AddressOf Me.Button3.Cursor = Cursors.Hand
			AddressOf Me.Button3.FlatStyle = FlatStyle.Flat
			Dim arg_395_0 As Control = AddressOf Me.Button3
			location = New Point(6, 131)
			arg_395_0.Location = location
			Dim arg_3AD_0 As Control = AddressOf Me.Button3
			margin = New Padding(6, 5, 6, 5)
			arg_3AD_0.Margin = margin
			AddressOf Me.Button3.Name = "Button3"
			Dim arg_3D8_0 As Control = AddressOf Me.Button3
			size = New Size(228, 53)
			arg_3D8_0.Size = size
			AddressOf Me.Button3.TabIndex = 3
			AddressOf Me.Button3.Text = "Anderer Ordner..."
			AddressOf Me.Button3.UseVisualStyleBackColor = True
			AddressOf Me.Panel1.BackColor = Color.FromArgb(50, 50, 50)
			AddressOf Me.Panel1.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.TextBox1)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button4)
			Dim arg_46B_0 As Control = AddressOf Me.Panel1
			location = New Point(211, 131)
			arg_46B_0.Location = location
			AddressOf Me.Panel1.Name = "Panel1"
			Dim arg_496_0 As Control = AddressOf Me.Panel1
			size = New Size(334, 110)
			arg_496_0.Size = size
			AddressOf Me.Panel1.TabIndex = 4
			AddressOf Me.Panel1.Visible = False
			AddressOf Me.TextBox1.BackColor = Color.FromArgb(64, 64, 64)
			AddressOf Me.TextBox1.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.TextBox1.ForeColor = Color.Lime
			Dim arg_4F7_0 As Control = AddressOf Me.TextBox1
			location = New Point(32, 71)
			arg_4F7_0.Location = location
			AddressOf Me.TextBox1.Name = "TextBox1"
			Dim arg_522_0 As Control = AddressOf Me.TextBox1
			size = New Size(294, 29)
			arg_522_0.Size = size
			AddressOf Me.TextBox1.TabIndex = 3
			AddressOf Me.TextBox1.Text = "C:\Users\"
			AddressOf Me.Button4.Cursor = Cursors.Hand
			AddressOf Me.Button4.FlatStyle = FlatStyle.Flat
			Dim arg_571_0 As Control = AddressOf Me.Button4
			location = New Point(32, 10)
			arg_571_0.Location = location
			Dim arg_589_0 As Control = AddressOf Me.Button4
			margin = New Padding(6, 5, 6, 5)
			arg_589_0.Margin = margin
			AddressOf Me.Button4.Name = "Button4"
			Dim arg_5B4_0 As Control = AddressOf Me.Button4
			size = New Size(294, 53)
			arg_5B4_0.Size = size
			AddressOf Me.Button4.TabIndex = 2
			AddressOf Me.Button4.Text = "Laden..."
			AddressOf Me.Button4.UseVisualStyleBackColor = True
			AddressOf Me.SplitContainer1.Dock = DockStyle.Fill
			Dim arg_5FD_0 As Control = AddressOf Me.SplitContainer1
			location = New Point(0, 0)
			arg_5FD_0.Location = location
			AddressOf Me.SplitContainer1.Name = "SplitContainer1"
			AddressOf Me.SplitContainer1.Panel1.Controls.Add(AddressOf Me.ListBox1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.GroupBox1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button3)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Panel1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button5)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Panel2)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button1)
			AddressOf Me.SplitContainer1.Panel2.Controls.Add(AddressOf Me.Button2)
			Dim arg_703_0 As Control = AddressOf Me.SplitContainer1
			size = New Size(1193, 470)
			arg_703_0.Size = size
			AddressOf Me.SplitContainer1.SplitterDistance = 557
			AddressOf Me.SplitContainer1.TabIndex = 5
			AddressOf Me.GroupBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.RAM_Bar)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.Label2)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.PictureBox4)
			AddressOf Me.GroupBox1.Cursor = Cursors.No
			AddressOf Me.GroupBox1.ForeColor = Color.Lime
			Dim arg_7A8_0 As Control = AddressOf Me.GroupBox1
			location = New Point(260, 12)
			arg_7A8_0.Location = location
			AddressOf Me.GroupBox1.Name = "GroupBox1"
			Dim arg_7D3_0 As Control = AddressOf Me.GroupBox1
			size = New Size(360, 59)
			arg_7D3_0.Size = size
			AddressOf Me.GroupBox1.TabIndex = 13
			AddressOf Me.GroupBox1.TabStop = False
			AddressOf Me.GroupBox1.Text = "RamCounter V.A.01"
			AddressOf Me.RAM_Bar.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.RAM_Bar.BackgroundImage = AddressOf Resources.CPU_Bar_Inner_1
			AddressOf Me.RAM_Bar.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.RAM_Bar.Cursor = Cursors.No
			Dim arg_84F_0 As Control = AddressOf Me.RAM_Bar
			location = New Point(138, 27)
			arg_84F_0.Location = location
			AddressOf Me.RAM_Bar.Name = "RAM_Bar"
			Dim arg_87A_0 As Control = AddressOf Me.RAM_Bar
			size = New Size(200, 20)
			arg_87A_0.Size = size
			AddressOf Me.RAM_Bar.TabIndex = 10
			AddressOf Me.RAM_Bar.TabStop = False
			AddressOf Me.Label2.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Label2.AutoSize = True
			Dim arg_8C2_0 As Control = AddressOf Me.Label2
			location = New Point(6, 27)
			arg_8C2_0.Location = location
			AddressOf Me.Label2.Name = "Label2"
			Dim arg_8EA_0 As Control = AddressOf Me.Label2
			size = New Size(98, 21)
			arg_8EA_0.Size = size
			AddressOf Me.Label2.TabIndex = 12
			AddressOf Me.Label2.Text = "RAM: 0 %"
			AddressOf Me.PictureBox4.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.PictureBox4.BackColor = Color.Black
			AddressOf Me.PictureBox4.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.PictureBox4.Cursor = Cursors.No
			Dim arg_95A_0 As Control = AddressOf Me.PictureBox4
			location = New Point(133, 22)
			arg_95A_0.Location = location
			AddressOf Me.PictureBox4.Name = "PictureBox4"
			Dim arg_985_0 As Control = AddressOf Me.PictureBox4
			size = New Size(210, 30)
			arg_985_0.Size = size
			AddressOf Me.PictureBox4.TabIndex = 9
			AddressOf Me.PictureBox4.TabStop = False
			AddressOf Me.Button5.Cursor = Cursors.Hand
			AddressOf Me.Button5.FlatStyle = FlatStyle.Flat
			Dim arg_9D3_0 As Control = AddressOf Me.Button5
			location = New Point(6, 194)
			arg_9D3_0.Location = location
			Dim arg_9EB_0 As Control = AddressOf Me.Button5
			margin = New Padding(6, 5, 6, 5)
			arg_9EB_0.Margin = margin
			AddressOf Me.Button5.Name = "Button5"
			Dim arg_A16_0 As Control = AddressOf Me.Button5
			size = New Size(228, 53)
			arg_A16_0.Size = size
			AddressOf Me.Button5.TabIndex = 5
			AddressOf Me.Button5.Text = "Anderes Programm..."
			AddressOf Me.Button5.UseVisualStyleBackColor = True
			AddressOf Me.Panel2.BackColor = Color.FromArgb(50, 50, 50)
			AddressOf Me.Panel2.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.Panel2.Controls.Add(AddressOf Me.TextBox2)
			AddressOf Me.Panel2.Controls.Add(AddressOf Me.Button6)
			Dim arg_AA9_0 As Control = AddressOf Me.Panel2
			location = New Point(211, 194)
			arg_AA9_0.Location = location
			AddressOf Me.Panel2.Name = "Panel2"
			Dim arg_AD4_0 As Control = AddressOf Me.Panel2
			size = New Size(334, 110)
			arg_AD4_0.Size = size
			AddressOf Me.Panel2.TabIndex = 6
			AddressOf Me.Panel2.Visible = False
			AddressOf Me.TextBox2.BackColor = Color.FromArgb(64, 64, 64)
			AddressOf Me.TextBox2.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.TextBox2.ForeColor = Color.Lime
			Dim arg_B35_0 As Control = AddressOf Me.TextBox2
			location = New Point(32, 71)
			arg_B35_0.Location = location
			AddressOf Me.TextBox2.Name = "TextBox2"
			Dim arg_B60_0 As Control = AddressOf Me.TextBox2
			size = New Size(294, 29)
			arg_B60_0.Size = size
			AddressOf Me.TextBox2.TabIndex = 3
			AddressOf Me.TextBox2.Text = "(Bitte Namen eingeben...)"
			AddressOf Me.Button6.Cursor = Cursors.Hand
			AddressOf Me.Button6.FlatStyle = FlatStyle.Flat
			Dim arg_BAF_0 As Control = AddressOf Me.Button6
			location = New Point(32, 10)
			arg_BAF_0.Location = location
			Dim arg_BC7_0 As Control = AddressOf Me.Button6
			margin = New Padding(6, 5, 6, 5)
			arg_BC7_0.Margin = margin
			AddressOf Me.Button6.Name = "Button6"
			Dim arg_BF2_0 As Control = AddressOf Me.Button6
			size = New Size(294, 53)
			arg_BF2_0.Size = size
			AddressOf Me.Button6.TabIndex = 2
			AddressOf Me.Button6.Text = "Starten"
			AddressOf Me.Button6.UseVisualStyleBackColor = True
			AddressOf Me.Aktualisieren.Enabled = True
			AddressOf Me.Aktualisieren.Interval = 10
			Dim autoScaleDimensions As SizeF = New SizeF(11F, 21F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.FromArgb(64, 64, 64)
			size = New Size(1193, 470)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.SplitContainer1)
			Me.Font = New Font("Courier New", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Me.ForeColor = Color.Lime
			Me.FormBorderStyle = FormBorderStyle.SizableToolWindow
			margin = New Padding(6, 5, 6, 5)
			Me.Margin = margin
			Me.Name = "GreenStart"
			Me.Text = "GreenStarter"
			AddressOf Me.Panel1.ResumeLayout(False)
			AddressOf Me.Panel1.PerformLayout()
			AddressOf Me.SplitContainer1.Panel1.ResumeLayout(False)
			AddressOf Me.SplitContainer1.Panel2.ResumeLayout(False)
			(CType(AddressOf Me.SplitContainer1, ISupportInitialize)).EndInit()
			AddressOf Me.SplitContainer1.ResumeLayout(False)
			AddressOf Me.GroupBox1.ResumeLayout(False)
			AddressOf Me.GroupBox1.PerformLayout()
			(CType(AddressOf Me.RAM_Bar, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox4, ISupportInitialize)).EndInit()
			AddressOf Me.Panel2.ResumeLayout(False)
			AddressOf Me.Panel2.PerformLayout()
			Me.ResumeLayout(False)
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
		End Sub

		Private Sub Button3_Click(sender As Object, e As EventArgs)
			If Not AddressOf Me.Panel1.Visible Then
				AddressOf Me.Panel1.Visible = True
			Else
				AddressOf Me.Panel1.Visible = False
			End If
		End Sub

		Private Sub Form2_MouseHover(sender As Object, e As EventArgs)
			AddressOf Me.Panel1.Visible = False
		End Sub

		Private Sub Button2_Click(sender As Object, e As EventArgs)
			AddressOf Me.ListBox1.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Programs") Then
				Dim directory As DirectoryInfo = New DirectoryInfo("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Programs")
				AddressOf Me.Button2.Text = "Neu Laden..."
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					If Operators.CompareString(file.Extension, ".EXE", False) = 0 Or Operators.CompareString(file.Extension, ".exe", False) = 0 Or Operators.CompareString(file.Extension, ".INK", False) = 0 Or Operators.CompareString(file.Extension, ".ink", False) = 0 Or Operators.CompareString(file.Extension, ".Exe", False) = 0 Or Operators.CompareString(file.Extension, ".Ink", False) = 0 Then
						AddressOf Me.ListBox1.Items.Add(file.FullName)
					End If
				Next
			Else
				Interaction.MsgBox("Neuer leerer Ordner wird erstellt, da dieser noch nicht vorhanden ist, jedoch dringend benötigt wird. Der Ordner befindet sich auf dem Desktop.", MsgBoxStyle.OkOnly, Nothing)
				Try
					Directory.CreateDirectory("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Programs")
					Interaction.MsgBox("Der Ordner wurde erstellt. Er befindet sich auf dem Desktop unter dem Namen: 'EvoroVOS'", MsgBoxStyle.OkOnly, Nothing)
				Catch expr_152 As Exception
					ProjectData.SetProjectError(expr_152)
					Interaction.MsgBox("Fehler beim erstellen des Ordners! Bitte schließe das Programm, erstelle auf deinem Desktop einen Ordner mit dem Namen 'EvoroVOS' mit einem untergeordnetem Ordner 'Programs'.", MsgBoxStyle.Critical, Nothing)
					ProjectData.ClearProjectError()
				End Try
			End If
			If AddressOf Me.ListBox1.Items.Count = 0 Then
				Interaction.MsgBox("Der Ordner enthällt keine gültigen oder verfügbaren Dateien. Um gültige Dateien hinzuzufügen, gehen sie auf den Desktop und öffnen den Ordner EvoroVOS\Programs und fügen hier die gesuchten Programme oder Verknüpfungen ein.", MsgBoxStyle.OkOnly, Nothing)
			End If
		End Sub

		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			AddressOf Me.ListBox1.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Files") Then
				Dim directory As DirectoryInfo = New DirectoryInfo("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Files")
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					AddressOf Me.ListBox1.Items.Add(file.FullName)
				Next
			Else
				Interaction.MsgBox("Neuer leerer Ordner wird erstellt, da dieser noch nicht vorhanden ist, jedoch dringend benötigt wird. Der Ordner befindet sich auf dem Desktop.", MsgBoxStyle.OkOnly, Nothing)
				Try
					Directory.CreateDirectory("C:\Users\" + Environment.UserName + "\Desktop\EvoroVOS\Files")
					Interaction.MsgBox("Der Ordner wurde erstellt. Er befindet sich auf dem Desktop unter dem Namen: 'EvoroVOS'", MsgBoxStyle.OkOnly, Nothing)
				Catch expr_BA As Exception
					ProjectData.SetProjectError(expr_BA)
					Interaction.MsgBox("Fehler beim erstellen des Ordners! Bitte schließe das Programm, erstelle auf deinem Desktop einen Ordner mit dem Namen 'EvoroVOS' mit einem untergeordnetem Ordner 'Files'.", MsgBoxStyle.Critical, Nothing)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub Button1_Click_1(sender As Object, e As EventArgs)
			Try
				Me.pfad = Conversions.ToString(AddressOf Me.ListBox1.SelectedItem)
				Process.Start(Me.pfad)
			Catch expr_24 As Exception
				ProjectData.SetProjectError(expr_24)
				Interaction.MsgBox("Programm konnte nicht gestartet werden. Es können nur .exe-Dateien ausgeführt werden.", MsgBoxStyle.Critical, Nothing)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub Button4_Click(sender As Object, e As EventArgs)
			Dim Ownsrc As String = AddressOf Me.TextBox1.Text
			AddressOf Me.ListBox1.Items.Clear()
			' The following expression was wrapped in a checked-statement
			If AddressOf MyProject.Computer.FileSystem.DirectoryExists(Ownsrc) Then
				Dim directory As DirectoryInfo = New DirectoryInfo(Ownsrc)
				Dim files As FileInfo() = directory.GetFiles()
				For i As Integer = 0 To files.Length - 1
					Dim file As FileInfo = files(i)
					If Operators.CompareString(file.Extension, ".EXE", False) = 0 Or Operators.CompareString(file.Extension, ".exe", False) = 0 Or Operators.CompareString(file.Extension, ".INK", False) = 0 Or Operators.CompareString(file.Extension, ".ink", False) = 0 Or Operators.CompareString(file.Extension, ".Exe", False) = 0 Or Operators.CompareString(file.Extension, ".Ink", False) = 0 Then
						AddressOf Me.ListBox1.Items.Add(file.FullName)
					End If
				Next
			Else
				Interaction.MsgBox("Ordner nicht gefunden.", MsgBoxStyle.OkOnly, Nothing)
			End If
			If AddressOf Me.ListBox1.Items.Count = 0 Then
				AddressOf Me.ListBox1.Items.Add("Dieser Ordner enthällt keine gültigen Dateien.")
			End If
		End Sub

		Private Sub Button6_Click(sender As Object, e As EventArgs)
			Try
				Me.pfad = AddressOf Me.TextBox2.Text
				Process.Start(Me.pfad)
			Catch expr_1F As Exception
				ProjectData.SetProjectError(expr_1F)
				Interaction.MsgBox("Programm konnte nicht gestartet oder gefunden werden. Überprüfen sie den Namen und ob das Programm auf ihrem PC installiert ist.", MsgBoxStyle.Critical, Nothing)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub Button5_Click(sender As Object, e As EventArgs)
			If Not AddressOf Me.Panel2.Visible Then
				AddressOf Me.Panel2.Visible = True
			Else
				AddressOf Me.Panel2.Visible = False
			End If
		End Sub

		Private Sub Form2_Load(sender As Object, e As EventArgs)
			Me.PerCPU.CounterName = "% Processor Time"
			Me.PerCPU.InstanceName = "_Total"
			Me.PerCPU.CategoryName = "Processor"
		End Sub

		Private Sub Aktualisieren_Tick(sender As Object, e As EventArgs)
			' The following expression was wrapped in a checked-statement
			Try
				' The following expression was wrapped in a unchecked-expression
				' The following expression was wrapped in a checked-expression
				Dim Ram As Integer = CInt(Math.Round(AddressOf MyProject.Computer.Info.TotalPhysicalMemory - AddressOf MyProject.Computer.Info.AvailablePhysicalMemory / AddressOf MyProject.Computer.Info.TotalPhysicalMemory * 100.0))
				AddressOf Me.Label2.Text = "Ram: " + Conversions.ToString(Ram) + "%"
				AddressOf Me.RAM_Bar.Width = Ram * 2
			Catch expr_74 As Exception
				ProjectData.SetProjectError(expr_74)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)
		End Sub
	End Class
End Namespace
