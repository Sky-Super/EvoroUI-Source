Imports EvoroUI.My
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class EinstellungenStart
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("ListBox1")>
		Private _ListBox1 As ListBox

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button1_Click
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.Click, value2
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property ListBox1() As ListBox
			Get
				Return Me._ListBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As ListBox)
				Me._ListBox1 = value
			End Set
		End Property

		Public Sub New()
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			AddressOf Me.Button1 = New Button()
			AddressOf Me.ListBox1 = New ListBox()
			Me.SuspendLayout()
			AddressOf Me.Button1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			Dim arg_4D_0 As Control = AddressOf Me.Button1
			Dim location As Point = New Point(785, 486)
			arg_4D_0.Location = location
			Dim arg_67_0 As Control = AddressOf Me.Button1
			Dim size As Size = New Size(342, 29)
			arg_67_0.MaximumSize = size
			Dim arg_81_0 As Control = AddressOf Me.Button1
			size = New Size(342, 29)
			arg_81_0.MinimumSize = size
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_AB_0 As Control = AddressOf Me.Button1
			size = New Size(342, 29)
			arg_AB_0.Size = size
			AddressOf Me.Button1.TabIndex = 1
			AddressOf Me.Button1.Text = "Ok"
			AddressOf Me.Button1.UseVisualStyleBackColor = True
			AddressOf Me.ListBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.ListBox1.BackColor = Color.Black
			AddressOf Me.ListBox1.BorderStyle = BorderStyle.FixedSingle
			AddressOf Me.ListBox1.ForeColor = Color.White
			AddressOf Me.ListBox1.FormattingEnabled = True
			AddressOf Me.ListBox1.ItemHeight = 21
			AddressOf Me.ListBox1.Items.AddRange(New Object()() { "Log-in Settings", "Updater", "Quit" })
			Dim arg_177_0 As Control = AddressOf Me.ListBox1
			location = New Point(785, 457)
			arg_177_0.Location = location
			Dim arg_191_0 As Control = AddressOf Me.ListBox1
			size = New Size(342, 23)
			arg_191_0.MaximumSize = size
			Dim arg_1AB_0 As Control = AddressOf Me.ListBox1
			size = New Size(342, 23)
			arg_1AB_0.MinimumSize = size
			AddressOf Me.ListBox1.Name = "ListBox1"
			Dim arg_1D5_0 As Control = AddressOf Me.ListBox1
			size = New Size(342, 23)
			arg_1D5_0.Size = size
			AddressOf Me.ListBox1.TabIndex = 2
			Dim autoScaleDimensions As SizeF = New SizeF(10F, 21F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			size = New Size(1537, 761)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.ListBox1)
			Me.Controls.Add(AddressOf Me.Button1)
			Me.Font = New Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Me.ForeColor = Color.White
			Me.FormBorderStyle = FormBorderStyle.None
			Dim margin As Padding = New Padding(5, 5, 5, 5)
			Me.Margin = margin
			Me.Name = "EinstellungenStart"
			Me.Text = "EinstellungenStart"
			Me.WindowState = FormWindowState.Maximized
			Me.ResumeLayout(False)
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			If Operators.ConditionalCompareObjectEqual(AddressOf Me.ListBox1.SelectedItem, "Log-in Settings", False) Then
				AddressOf AddressOf MyProject.Forms.EinstellungenLoggin.Show()
				Me.Close()
			Else
				If Operators.ConditionalCompareObjectEqual(AddressOf Me.ListBox1.SelectedItem, "Quit", False) Then
					Me.Close()
				Else
					Interaction.MsgBox("Please Select setting!", MsgBoxStyle.OkOnly, Nothing)
				End If
			End If
		End Sub
	End Class
End Namespace
