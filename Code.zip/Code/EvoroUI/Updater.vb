Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Updater
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("Button2")>
		Private _Button2 As Button

		<AccessedThroughProperty("Button3")>
		Private _Button3 As Button

		<AccessedThroughProperty("Button4")>
		Private _Button4 As Button

		<AccessedThroughProperty("Button5")>
		Private _Button5 As Button

		<AccessedThroughProperty("Button6")>
		Private _Button6 As Button

		<AccessedThroughProperty("Button7")>
		Private _Button7 As Button

		<AccessedThroughProperty("Button8")>
		Private _Button8 As Button

		<AccessedThroughProperty("Button9")>
		Private _Button9 As Button

		<AccessedThroughProperty("Button10")>
		Private _Button10 As Button

		<AccessedThroughProperty("Button11")>
		Private _Button11 As Button

		<AccessedThroughProperty("WebBrowser1")>
		Private _WebBrowser1 As WebBrowser

		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button1_Click
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.Click, value2
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button2() As Button
			Get
				Return Me._Button2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button2_Click
				If Me._Button2 IsNot Nothing Then
					RemoveHandler Me._Button2.Click, value2
				End If
				Me._Button2 = value
				If Me._Button2 IsNot Nothing Then
					AddHandler Me._Button2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button3() As Button
			Get
				Return Me._Button3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button3 = value
			End Set
		End Property

		Friend Overridable Property Button4() As Button
			Get
				Return Me._Button4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button4 = value
			End Set
		End Property

		Friend Overridable Property Button5() As Button
			Get
				Return Me._Button5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button5 = value
			End Set
		End Property

		Friend Overridable Property Button6() As Button
			Get
				Return Me._Button6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button6 = value
			End Set
		End Property

		Friend Overridable Property Button7() As Button
			Get
				Return Me._Button7
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button7 = value
			End Set
		End Property

		Friend Overridable Property Button8() As Button
			Get
				Return Me._Button8
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button8 = value
			End Set
		End Property

		Friend Overridable Property Button9() As Button
			Get
				Return Me._Button9
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button9 = value
			End Set
		End Property

		Friend Overridable Property Button10() As Button
			Get
				Return Me._Button10
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button10 = value
			End Set
		End Property

		Friend Overridable Property Button11() As Button
			Get
				Return Me._Button11
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button11 = value
			End Set
		End Property

		Friend Overridable Property WebBrowser1() As WebBrowser
			Get
				Return Me._WebBrowser1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As WebBrowser)
				Me._WebBrowser1 = value
			End Set
		End Property

		Friend Overridable Property Timer1() As Timer
			Get
				Return Me._Timer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer1_Tick
				If Me._Timer1 IsNot Nothing Then
					RemoveHandler Me._Timer1.Tick, value2
				End If
				Me._Timer1 = value
				If Me._Timer1 IsNot Nothing Then
					AddHandler Me._Timer1.Tick, value2
				End If
			End Set
		End Property

		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.Updater_Load
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Container()
			AddressOf Me.Button1 = New Button()
			AddressOf Me.Button2 = New Button()
			AddressOf Me.Button3 = New Button()
			AddressOf Me.Button4 = New Button()
			AddressOf Me.Button5 = New Button()
			AddressOf Me.Button6 = New Button()
			AddressOf Me.Button7 = New Button()
			AddressOf Me.Button8 = New Button()
			AddressOf Me.Button9 = New Button()
			AddressOf Me.Button10 = New Button()
			AddressOf Me.Button11 = New Button()
			AddressOf Me.WebBrowser1 = New WebBrowser()
			AddressOf Me.Timer1 = New Timer(Me.components)
			Me.SuspendLayout()
			AddressOf Me.Button1.BackColor = Color.Black
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			Dim arg_D4_0 As Control = AddressOf Me.Button1
			Dim location As Point = New Point(12, 12)
			arg_D4_0.Location = location
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_FF_0 As Control = AddressOf Me.Button1
			Dim size As Size = New Size(214, 52)
			arg_FF_0.Size = size
			AddressOf Me.Button1.TabIndex = 0
			AddressOf Me.Button1.Text = "Load Website"
			AddressOf Me.Button1.UseVisualStyleBackColor = False
			AddressOf Me.Button2.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button2.BackColor = Color.Black
			AddressOf Me.Button2.FlatStyle = FlatStyle.Flat
			Dim arg_16A_0 As Control = AddressOf Me.Button2
			location = New Point(672, 12)
			arg_16A_0.Location = location
			AddressOf Me.Button2.Name = "Button2"
			Dim arg_195_0 As Control = AddressOf Me.Button2
			size = New Size(214, 52)
			arg_195_0.Size = size
			AddressOf Me.Button2.TabIndex = 1
			AddressOf Me.Button2.Text = "Close"
			AddressOf Me.Button2.UseVisualStyleBackColor = False
			AddressOf Me.Button3.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button3.BackColor = Color.Black
			AddressOf Me.Button3.FlatStyle = FlatStyle.Flat
			Dim arg_200_0 As Control = AddressOf Me.Button3
			location = New Point(672, 70)
			arg_200_0.Location = location
			AddressOf Me.Button3.Name = "Button3"
			Dim arg_22B_0 As Control = AddressOf Me.Button3
			size = New Size(214, 52)
			arg_22B_0.Size = size
			AddressOf Me.Button3.TabIndex = 2
			AddressOf Me.Button3.UseVisualStyleBackColor = False
			AddressOf Me.Button4.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button4.BackColor = Color.Black
			AddressOf Me.Button4.FlatStyle = FlatStyle.Flat
			Dim arg_289_0 As Control = AddressOf Me.Button4
			location = New Point(672, 128)
			arg_289_0.Location = location
			AddressOf Me.Button4.Name = "Button4"
			Dim arg_2B4_0 As Control = AddressOf Me.Button4
			size = New Size(214, 52)
			arg_2B4_0.Size = size
			AddressOf Me.Button4.TabIndex = 3
			AddressOf Me.Button4.UseVisualStyleBackColor = False
			AddressOf Me.Button5.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button5.BackColor = Color.Black
			AddressOf Me.Button5.FlatStyle = FlatStyle.Flat
			Dim arg_312_0 As Control = AddressOf Me.Button5
			location = New Point(672, 186)
			arg_312_0.Location = location
			AddressOf Me.Button5.Name = "Button5"
			Dim arg_33D_0 As Control = AddressOf Me.Button5
			size = New Size(214, 52)
			arg_33D_0.Size = size
			AddressOf Me.Button5.TabIndex = 4
			AddressOf Me.Button5.UseVisualStyleBackColor = False
			AddressOf Me.Button6.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button6.BackColor = Color.Black
			AddressOf Me.Button6.FlatStyle = FlatStyle.Flat
			Dim arg_39B_0 As Control = AddressOf Me.Button6
			location = New Point(672, 244)
			arg_39B_0.Location = location
			AddressOf Me.Button6.Name = "Button6"
			Dim arg_3C6_0 As Control = AddressOf Me.Button6
			size = New Size(214, 52)
			arg_3C6_0.Size = size
			AddressOf Me.Button6.TabIndex = 5
			AddressOf Me.Button6.UseVisualStyleBackColor = False
			AddressOf Me.Button7.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button7.BackColor = Color.Black
			AddressOf Me.Button7.FlatStyle = FlatStyle.Flat
			Dim arg_424_0 As Control = AddressOf Me.Button7
			location = New Point(672, 302)
			arg_424_0.Location = location
			AddressOf Me.Button7.Name = "Button7"
			Dim arg_44F_0 As Control = AddressOf Me.Button7
			size = New Size(214, 52)
			arg_44F_0.Size = size
			AddressOf Me.Button7.TabIndex = 6
			AddressOf Me.Button7.UseVisualStyleBackColor = False
			AddressOf Me.Button8.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button8.BackColor = Color.Black
			AddressOf Me.Button8.FlatStyle = FlatStyle.Flat
			Dim arg_4AD_0 As Control = AddressOf Me.Button8
			location = New Point(672, 360)
			arg_4AD_0.Location = location
			AddressOf Me.Button8.Name = "Button8"
			Dim arg_4D8_0 As Control = AddressOf Me.Button8
			size = New Size(214, 52)
			arg_4D8_0.Size = size
			AddressOf Me.Button8.TabIndex = 7
			AddressOf Me.Button8.UseVisualStyleBackColor = False
			AddressOf Me.Button9.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button9.BackColor = Color.Black
			AddressOf Me.Button9.FlatStyle = FlatStyle.Flat
			Dim arg_536_0 As Control = AddressOf Me.Button9
			location = New Point(672, 418)
			arg_536_0.Location = location
			AddressOf Me.Button9.Name = "Button9"
			Dim arg_561_0 As Control = AddressOf Me.Button9
			size = New Size(214, 52)
			arg_561_0.Size = size
			AddressOf Me.Button9.TabIndex = 8
			AddressOf Me.Button9.UseVisualStyleBackColor = False
			AddressOf Me.Button10.BackColor = Color.Black
			AddressOf Me.Button10.Enabled = False
			AddressOf Me.Button10.FlatStyle = FlatStyle.Flat
			Dim arg_5BB_0 As Control = AddressOf Me.Button10
			location = New Point(232, 12)
			arg_5BB_0.Location = location
			AddressOf Me.Button10.Name = "Button10"
			Dim arg_5E6_0 As Control = AddressOf Me.Button10
			size = New Size(214, 52)
			arg_5E6_0.Size = size
			AddressOf Me.Button10.TabIndex = 9
			AddressOf Me.Button10.Text = "Actuel Version:"
			AddressOf Me.Button10.UseVisualStyleBackColor = False
			AddressOf Me.Button11.BackColor = Color.Black
			AddressOf Me.Button11.Enabled = False
			AddressOf Me.Button11.FlatStyle = FlatStyle.Flat
			Dim arg_651_0 As Control = AddressOf Me.Button11
			location = New Point(452, 12)
			arg_651_0.Location = location
			AddressOf Me.Button11.Name = "Button11"
			Dim arg_67C_0 As Control = AddressOf Me.Button11
			size = New Size(214, 52)
			arg_67C_0.Size = size
			AddressOf Me.Button11.TabIndex = 10
			AddressOf Me.Button11.Text = "Time:"
			AddressOf Me.Button11.UseVisualStyleBackColor = False
			Dim arg_6BC_0 As Control = AddressOf Me.WebBrowser1
			location = New Point(12, 70)
			arg_6BC_0.Location = location
			Dim arg_6D4_0 As Control = AddressOf Me.WebBrowser1
			size = New Size(20, 20)
			arg_6D4_0.MinimumSize = size
			AddressOf Me.WebBrowser1.Name = "WebBrowser1"
			Dim arg_702_0 As Control = AddressOf Me.WebBrowser1
			size = New Size(654, 400)
			arg_702_0.Size = size
			AddressOf Me.WebBrowser1.TabIndex = 12
			AddressOf Me.Timer1.Enabled = True
			AddressOf Me.Timer1.Interval = 1
			Dim autoScaleDimensions As SizeF = New SizeF(8F, 17F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			size = New Size(898, 482)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.WebBrowser1)
			Me.Controls.Add(AddressOf Me.Button11)
			Me.Controls.Add(AddressOf Me.Button10)
			Me.Controls.Add(AddressOf Me.Button9)
			Me.Controls.Add(AddressOf Me.Button8)
			Me.Controls.Add(AddressOf Me.Button7)
			Me.Controls.Add(AddressOf Me.Button6)
			Me.Controls.Add(AddressOf Me.Button5)
			Me.Controls.Add(AddressOf Me.Button4)
			Me.Controls.Add(AddressOf Me.Button3)
			Me.Controls.Add(AddressOf Me.Button2)
			Me.Controls.Add(AddressOf Me.Button1)
			Me.DoubleBuffered = True
			Me.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Me.ForeColor = Color.Lime
			Me.FormBorderStyle = FormBorderStyle.None
			Dim margin As Padding = New Padding(3, 4, 3, 4)
			Me.Margin = margin
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "Updater"
			Me.StartPosition = FormStartPosition.CenterScreen
			Me.Text = "Updates"
			Me.TransparencyKey = Color.FromArgb(255, 224, 192)
			Me.ResumeLayout(False)
		End Sub

		Private Sub Updater_Load(sender As Object, e As EventArgs)
			AddressOf Me.Button10.Text = "Actuel Version: " + Me.ProductVersion
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			AddressOf Me.WebBrowser1.Navigate("http://gmmodsbyskysuper.bplaced.com/updates.html")
		End Sub

		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			AddressOf Me.Button10.Text = "Actuel Version: " + Me.ProductVersion
		End Sub

		Private Sub Button2_Click(sender As Object, e As EventArgs)
			Me.Close()
		End Sub
	End Class
End Namespace
