Imports EvoroUI.My
Imports EvoroUI.My.Resources
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms

Namespace EvoroUI
	<DesignerGenerated()>
	Public Class Ansicht2
		Inherits Form

		Private components As IContainer

		<AccessedThroughProperty("Label7")>
		Private _Label7 As Label

		<AccessedThroughProperty("Label6")>
		Private _Label6 As Label

		<AccessedThroughProperty("PictureBox7")>
		Private _PictureBox7 As PictureBox

		<AccessedThroughProperty("PictureBox1")>
		Private _PictureBox1 As PictureBox

		<AccessedThroughProperty("PictureBox5")>
		Private _PictureBox5 As PictureBox

		<AccessedThroughProperty("PictureBox6")>
		Private _PictureBox6 As PictureBox

		<AccessedThroughProperty("PictureBox3")>
		Private _PictureBox3 As PictureBox

		<AccessedThroughProperty("PictureBox4")>
		Private _PictureBox4 As PictureBox

		<AccessedThroughProperty("PictureBox2")>
		Private _PictureBox2 As PictureBox

		<AccessedThroughProperty("Panel1")>
		Private _Panel1 As Panel

		<AccessedThroughProperty("Button8")>
		Private _Button8 As Button

		<AccessedThroughProperty("Button7")>
		Private _Button7 As Button

		<AccessedThroughProperty("Button6")>
		Private _Button6 As Button

		<AccessedThroughProperty("Button5")>
		Private _Button5 As Button

		<AccessedThroughProperty("Button4")>
		Private _Button4 As Button

		<AccessedThroughProperty("Button3")>
		Private _Button3 As Button

		<AccessedThroughProperty("Button2")>
		Private _Button2 As Button

		<AccessedThroughProperty("Button1")>
		Private _Button1 As Button

		<AccessedThroughProperty("Timer1")>
		Private _Timer1 As Timer

		<AccessedThroughProperty("Label8")>
		Private _Label8 As Label

		<AccessedThroughProperty("Label5")>
		Private _Label5 As Label

		<AccessedThroughProperty("Label4")>
		Private _Label4 As Label

		<AccessedThroughProperty("Label3")>
		Private _Label3 As Label

		<AccessedThroughProperty("Label2")>
		Private _Label2 As Label

		<AccessedThroughProperty("Label1")>
		Private _Label1 As Label

		<AccessedThroughProperty("Panel2")>
		Private _Panel2 As Panel

		<AccessedThroughProperty("Button9")>
		Private _Button9 As Button

		<AccessedThroughProperty("MenuStrip1")>
		Private _MenuStrip1 As MenuStrip

		<AccessedThroughProperty("Button10")>
		Private _Button10 As Button

		<AccessedThroughProperty("Button11")>
		Private _Button11 As Button

		<AccessedThroughProperty("Panel3")>
		Private _Panel3 As Panel

		<AccessedThroughProperty("Button13")>
		Private _Button13 As Button

		<AccessedThroughProperty("Button14")>
		Private _Button14 As Button

		<AccessedThroughProperty("Button12")>
		Private _Button12 As Button

		<AccessedThroughProperty("GroupBox1")>
		Private _GroupBox1 As GroupBox

		<AccessedThroughProperty("RAM_Bar")>
		Private _RAM_Bar As PictureBox

		<AccessedThroughProperty("Label9")>
		Private _Label9 As Label

		<AccessedThroughProperty("PictureBox8")>
		Private _PictureBox8 As PictureBox

		<AccessedThroughProperty("Aktualisieren")>
		Private _Aktualisieren As Timer

		<AccessedThroughProperty("Button15")>
		Private _Button15 As Button

		Friend Overridable Property Label7() As Label
			Get
				Return Me._Label7
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label7 = value
			End Set
		End Property

		Friend Overridable Property Label6() As Label
			Get
				Return Me._Label6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label6 = value
			End Set
		End Property

		Friend Overridable Property PictureBox7() As PictureBox
			Get
				Return Me._PictureBox7
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox7 = value
			End Set
		End Property

		Friend Overridable Property PictureBox1() As PictureBox
			Get
				Return Me._PictureBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox1 = value
			End Set
		End Property

		Friend Overridable Property PictureBox5() As PictureBox
			Get
				Return Me._PictureBox5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox5 = value
			End Set
		End Property

		Friend Overridable Property PictureBox6() As PictureBox
			Get
				Return Me._PictureBox6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox6 = value
			End Set
		End Property

		Friend Overridable Property PictureBox3() As PictureBox
			Get
				Return Me._PictureBox3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox3 = value
			End Set
		End Property

		Friend Overridable Property PictureBox4() As PictureBox
			Get
				Return Me._PictureBox4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox4 = value
			End Set
		End Property

		Friend Overridable Property PictureBox2() As PictureBox
			Get
				Return Me._PictureBox2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox2 = value
			End Set
		End Property

		Friend Overridable Property Panel1() As Panel
			Get
				Return Me._Panel1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._Panel1 = value
			End Set
		End Property

		Friend Overridable Property Button8() As Button
			Get
				Return Me._Button8
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button8 = value
			End Set
		End Property

		Friend Overridable Property Button7() As Button
			Get
				Return Me._Button7
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button7_Click
				If Me._Button7 IsNot Nothing Then
					RemoveHandler Me._Button7.Click, value2
				End If
				Me._Button7 = value
				If Me._Button7 IsNot Nothing Then
					AddHandler Me._Button7.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button6() As Button
			Get
				Return Me._Button6
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button6_Click
				If Me._Button6 IsNot Nothing Then
					RemoveHandler Me._Button6.Click, value2
				End If
				Me._Button6 = value
				If Me._Button6 IsNot Nothing Then
					AddHandler Me._Button6.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button5() As Button
			Get
				Return Me._Button5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button5_Click
				If Me._Button5 IsNot Nothing Then
					RemoveHandler Me._Button5.Click, value2
				End If
				Me._Button5 = value
				If Me._Button5 IsNot Nothing Then
					AddHandler Me._Button5.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button4() As Button
			Get
				Return Me._Button4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button4_Click
				If Me._Button4 IsNot Nothing Then
					RemoveHandler Me._Button4.Click, value2
				End If
				Me._Button4 = value
				If Me._Button4 IsNot Nothing Then
					AddHandler Me._Button4.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button3() As Button
			Get
				Return Me._Button3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button3_Click
				If Me._Button3 IsNot Nothing Then
					RemoveHandler Me._Button3.Click, value2
				End If
				Me._Button3 = value
				If Me._Button3 IsNot Nothing Then
					AddHandler Me._Button3.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button2() As Button
			Get
				Return Me._Button2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button2_Click
				If Me._Button2 IsNot Nothing Then
					RemoveHandler Me._Button2.Click, value2
				End If
				Me._Button2 = value
				If Me._Button2 IsNot Nothing Then
					AddHandler Me._Button2.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button1() As Button
			Get
				Return Me._Button1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button1_Click
				If Me._Button1 IsNot Nothing Then
					RemoveHandler Me._Button1.Click, value2
				End If
				Me._Button1 = value
				If Me._Button1 IsNot Nothing Then
					AddHandler Me._Button1.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Timer1() As Timer
			Get
				Return Me._Timer1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Timer1_Tick
				If Me._Timer1 IsNot Nothing Then
					RemoveHandler Me._Timer1.Tick, value2
				End If
				Me._Timer1 = value
				If Me._Timer1 IsNot Nothing Then
					AddHandler Me._Timer1.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Label8() As Label
			Get
				Return Me._Label8
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label8 = value
			End Set
		End Property

		Friend Overridable Property Label5() As Label
			Get
				Return Me._Label5
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label5 = value
			End Set
		End Property

		Friend Overridable Property Label4() As Label
			Get
				Return Me._Label4
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label4 = value
			End Set
		End Property

		Friend Overridable Property Label3() As Label
			Get
				Return Me._Label3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label3 = value
			End Set
		End Property

		Friend Overridable Property Label2() As Label
			Get
				Return Me._Label2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label2 = value
			End Set
		End Property

		Friend Overridable Property Label1() As Label
			Get
				Return Me._Label1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label1 = value
			End Set
		End Property

		Friend Overridable Property Panel2() As Panel
			Get
				Return Me._Panel2
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Me._Panel2 = value
			End Set
		End Property

		Friend Overridable Property Button9() As Button
			Get
				Return Me._Button9
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button9_Click
				If Me._Button9 IsNot Nothing Then
					RemoveHandler Me._Button9.Click, value2
				End If
				Me._Button9 = value
				If Me._Button9 IsNot Nothing Then
					AddHandler Me._Button9.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property MenuStrip1() As MenuStrip
			Get
				Return Me._MenuStrip1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As MenuStrip)
				Me._MenuStrip1 = value
			End Set
		End Property

		Friend Overridable Property Button10() As Button
			Get
				Return Me._Button10
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button10_Click
				Dim value3 As EventHandler = AddressOf Me.Button10_MouseHover
				If Me._Button10 IsNot Nothing Then
					RemoveHandler Me._Button10.Click, value2
					RemoveHandler Me._Button10.MouseHover, value3
				End If
				Me._Button10 = value
				If Me._Button10 IsNot Nothing Then
					AddHandler Me._Button10.Click, value2
					AddHandler Me._Button10.MouseHover, value3
				End If
			End Set
		End Property

		Friend Overridable Property Button11() As Button
			Get
				Return Me._Button11
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button11_Click
				If Me._Button11 IsNot Nothing Then
					RemoveHandler Me._Button11.Click, value2
				End If
				Me._Button11 = value
				If Me._Button11 IsNot Nothing Then
					AddHandler Me._Button11.Click, value2
				End If
			End Set
		End Property

		Friend Overridable Property Panel3() As Panel
			Get
				Return Me._Panel3
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Panel)
				Dim value2 As PaintEventHandler = AddressOf Me.Panel3_Paint
				Dim value3 As EventHandler = AddressOf Me.Panel3_MouseLeave
				If Me._Panel3 IsNot Nothing Then
					RemoveHandler Me._Panel3.Paint, value2
					RemoveHandler Me._Panel3.MouseLeave, value3
				End If
				Me._Panel3 = value
				If Me._Panel3 IsNot Nothing Then
					AddHandler Me._Panel3.Paint, value2
					AddHandler Me._Panel3.MouseLeave, value3
				End If
			End Set
		End Property

		Friend Overridable Property Button13() As Button
			Get
				Return Me._Button13
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Me._Button13 = value
			End Set
		End Property

		Friend Overridable Property Button14() As Button
			Get
				Return Me._Button14
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button14_Click
				Dim value3 As EventHandler = AddressOf Me.Button14_MouseHover
				If Me._Button14 IsNot Nothing Then
					RemoveHandler Me._Button14.Click, value2
					RemoveHandler Me._Button14.MouseHover, value3
				End If
				Me._Button14 = value
				If Me._Button14 IsNot Nothing Then
					AddHandler Me._Button14.Click, value2
					AddHandler Me._Button14.MouseHover, value3
				End If
			End Set
		End Property

		Friend Overridable Property Button12() As Button
			Get
				Return Me._Button12
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button12_MouseHover
				Dim value3 As EventHandler = AddressOf Me.Button12_Click
				If Me._Button12 IsNot Nothing Then
					RemoveHandler Me._Button12.MouseHover, value2
					RemoveHandler Me._Button12.Click, value3
				End If
				Me._Button12 = value
				If Me._Button12 IsNot Nothing Then
					AddHandler Me._Button12.MouseHover, value2
					AddHandler Me._Button12.Click, value3
				End If
			End Set
		End Property

		Friend Overridable Property GroupBox1() As GroupBox
			Get
				Return Me._GroupBox1
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As GroupBox)
				Dim value2 As EventHandler = AddressOf Me.GroupBox1_MouseHover
				If Me._GroupBox1 IsNot Nothing Then
					RemoveHandler Me._GroupBox1.MouseHover, value2
				End If
				Me._GroupBox1 = value
				If Me._GroupBox1 IsNot Nothing Then
					AddHandler Me._GroupBox1.MouseHover, value2
				End If
			End Set
		End Property

		Friend Overridable Property RAM_Bar() As PictureBox
			Get
				Return Me._RAM_Bar
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._RAM_Bar = value
			End Set
		End Property

		Friend Overridable Property Label9() As Label
			Get
				Return Me._Label9
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Label)
				Me._Label9 = value
			End Set
		End Property

		Friend Overridable Property PictureBox8() As PictureBox
			Get
				Return Me._PictureBox8
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As PictureBox)
				Me._PictureBox8 = value
			End Set
		End Property

		Friend Overridable Property Aktualisieren() As Timer
			Get
				Return Me._Aktualisieren
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Timer)
				Dim value2 As EventHandler = AddressOf Me.Aktualisieren_Tick
				If Me._Aktualisieren IsNot Nothing Then
					RemoveHandler Me._Aktualisieren.Tick, value2
				End If
				Me._Aktualisieren = value
				If Me._Aktualisieren IsNot Nothing Then
					AddHandler Me._Aktualisieren.Tick, value2
				End If
			End Set
		End Property

		Friend Overridable Property Button15() As Button
			Get
				Return Me._Button15
			End Get
			<MethodImpl(MethodImplOptions.Synchronized)>
			Set(value As Button)
				Dim value2 As EventHandler = AddressOf Me.Button15_Click
				If Me._Button15 IsNot Nothing Then
					RemoveHandler Me._Button15.Click, value2
				End If
				Me._Button15 = value
				If Me._Button15 IsNot Nothing Then
					AddHandler Me._Button15.Click, value2
				End If
			End Set
		End Property

		Public Sub New()
			AddHandler MyBase.Load, AddressOf Me.MDIParent2_Load
			Me.InitializeComponent()
		End Sub

		<DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				If disposing AndAlso Me.components IsNot Nothing Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		<DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Container()
			AddressOf Me.Timer1 = New Timer(Me.components)
			AddressOf Me.Panel2 = New Panel()
			AddressOf Me.MenuStrip1 = New MenuStrip()
			AddressOf Me.Button9 = New Button()
			AddressOf Me.Button10 = New Button()
			AddressOf Me.Panel3 = New Panel()
			AddressOf Me.GroupBox1 = New GroupBox()
			AddressOf Me.RAM_Bar = New PictureBox()
			AddressOf Me.Label9 = New Label()
			AddressOf Me.PictureBox8 = New PictureBox()
			AddressOf Me.Button13 = New Button()
			AddressOf Me.Button14 = New Button()
			AddressOf Me.PictureBox7 = New PictureBox()
			AddressOf Me.PictureBox1 = New PictureBox()
			AddressOf Me.PictureBox5 = New PictureBox()
			AddressOf Me.PictureBox6 = New PictureBox()
			AddressOf Me.PictureBox3 = New PictureBox()
			AddressOf Me.PictureBox4 = New PictureBox()
			AddressOf Me.PictureBox2 = New PictureBox()
			AddressOf Me.Panel1 = New Panel()
			AddressOf Me.Button15 = New Button()
			AddressOf Me.Button11 = New Button()
			AddressOf Me.Button8 = New Button()
			AddressOf Me.Label8 = New Label()
			AddressOf Me.Label5 = New Label()
			AddressOf Me.Button7 = New Button()
			AddressOf Me.Label4 = New Label()
			AddressOf Me.Button6 = New Button()
			AddressOf Me.Label3 = New Label()
			AddressOf Me.Label6 = New Label()
			AddressOf Me.Label1 = New Label()
			AddressOf Me.Button5 = New Button()
			AddressOf Me.Label2 = New Label()
			AddressOf Me.Button4 = New Button()
			AddressOf Me.Label7 = New Label()
			AddressOf Me.Button3 = New Button()
			AddressOf Me.Button2 = New Button()
			AddressOf Me.Button1 = New Button()
			AddressOf Me.Button12 = New Button()
			AddressOf Me.Aktualisieren = New Timer(Me.components)
			AddressOf Me.Panel3.SuspendLayout()
			AddressOf Me.GroupBox1.SuspendLayout()
			(CType(AddressOf Me.RAM_Bar, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox8, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox7, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox5, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox6, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox3, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox4, ISupportInitialize)).BeginInit()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).BeginInit()
			AddressOf Me.Panel1.SuspendLayout()
			Me.SuspendLayout()
			AddressOf Me.Timer1.Enabled = True
			AddressOf Me.Timer1.Interval = 1
			AddressOf Me.Panel2.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right)
			Dim arg_296_0 As Control = AddressOf Me.Panel2
			Dim location As Point = New Point(241, 571)
			arg_296_0.Location = location
			AddressOf Me.Panel2.Name = "Panel2"
			Dim arg_2C3_0 As Control = AddressOf Me.Panel2
			Dim size As Size = New Size(1048, 188)
			arg_2C3_0.Size = size
			AddressOf Me.Panel2.TabIndex = 62
			AddressOf Me.Panel2.Visible = False
			AddressOf Me.MenuStrip1.BackColor = Color.Black
			Dim arg_301_0 As Control = AddressOf Me.MenuStrip1
			location = New Point(0, 0)
			arg_301_0.Location = location
			AddressOf Me.MenuStrip1.Name = "MenuStrip1"
			Dim arg_32B_0 As Control = AddressOf Me.MenuStrip1
			size = New Size(1290, 24)
			arg_32B_0.Size = size
			AddressOf Me.MenuStrip1.TabIndex = 64
			AddressOf Me.MenuStrip1.Text = "MenuStrip1"
			AddressOf Me.Button9.FlatStyle = FlatStyle.Flat
			Dim arg_371_0 As Control = AddressOf Me.Button9
			location = New Point(241, 278)
			arg_371_0.Location = location
			Dim arg_386_0 As Control = AddressOf Me.Button9
			Dim margin As Padding = New Padding(4)
			arg_386_0.Margin = margin
			AddressOf Me.Button9.Name = "Button9"
			Dim arg_3AD_0 As Control = AddressOf Me.Button9
			size = New Size(31, 30)
			arg_3AD_0.Size = size
			AddressOf Me.Button9.TabIndex = 62
			AddressOf Me.Button9.Text = "<"
			AddressOf Me.Button9.UseVisualStyleBackColor = True
			AddressOf Me.Button10.FlatStyle = FlatStyle.Flat
			Dim arg_3FB_0 As Control = AddressOf Me.Button10
			location = New Point(-1, 278)
			arg_3FB_0.Location = location
			Dim arg_410_0 As Control = AddressOf Me.Button10
			margin = New Padding(4)
			arg_410_0.Margin = margin
			AddressOf Me.Button10.Name = "Button10"
			Dim arg_437_0 As Control = AddressOf Me.Button10
			size = New Size(31, 30)
			arg_437_0.Size = size
			AddressOf Me.Button10.TabIndex = 63
			AddressOf Me.Button10.Text = ">"
			AddressOf Me.Button10.UseVisualStyleBackColor = True
			AddressOf Me.Button10.Visible = False
			AddressOf Me.Panel3.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Panel3.BackColor = Color.Transparent
			AddressOf Me.Panel3.BackgroundImage = AddressOf Resources.Farbverlauf32
			AddressOf Me.Panel3.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Panel3.Controls.Add(AddressOf Me.GroupBox1)
			AddressOf Me.Panel3.Controls.Add(AddressOf Me.Button13)
			Dim arg_4EA_0 As Control = AddressOf Me.Panel3
			location = New Point(1039, 0)
			arg_4EA_0.Location = location
			Dim arg_4FF_0 As Control = AddressOf Me.Panel3
			margin = New Padding(4)
			arg_4FF_0.Margin = margin
			AddressOf Me.Panel3.Name = "Panel3"
			Dim arg_52C_0 As Control = AddressOf Me.Panel3
			size = New Size(251, 1033)
			arg_52C_0.Size = size
			AddressOf Me.Panel3.TabIndex = 66
			AddressOf Me.Panel3.Visible = False
			AddressOf Me.GroupBox1.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.RAM_Bar)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.Label9)
			AddressOf Me.GroupBox1.Controls.Add(AddressOf Me.PictureBox8)
			AddressOf Me.GroupBox1.Cursor = Cursors.No
			AddressOf Me.GroupBox1.Font = New Font("Century Gothic", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0)
			AddressOf Me.GroupBox1.ForeColor = Color.White
			Dim arg_5E6_0 As Control = AddressOf Me.GroupBox1
			location = New Point(3, 3)
			arg_5E6_0.Location = location
			AddressOf Me.GroupBox1.Name = "GroupBox1"
			Dim arg_610_0 As Control = AddressOf Me.GroupBox1
			size = New Size(245, 93)
			arg_610_0.Size = size
			AddressOf Me.GroupBox1.TabIndex = 68
			AddressOf Me.GroupBox1.TabStop = False
			AddressOf Me.GroupBox1.Text = "RamCounter V.A.01 /Metalica"
			AddressOf Me.RAM_Bar.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.RAM_Bar.BackColor = Color.White
			AddressOf Me.RAM_Bar.BackgroundImage = AddressOf Resources.VerlaufGrau2
			AddressOf Me.RAM_Bar.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.RAM_Bar.Cursor = Cursors.No
			Dim arg_699_0 As Control = AddressOf Me.RAM_Bar
			location = New Point(21, 60)
			arg_699_0.Location = location
			AddressOf Me.RAM_Bar.Name = "RAM_Bar"
			Dim arg_6C3_0 As Control = AddressOf Me.RAM_Bar
			size = New Size(200, 20)
			arg_6C3_0.Size = size
			AddressOf Me.RAM_Bar.TabIndex = 10
			AddressOf Me.RAM_Bar.TabStop = False
			AddressOf Me.Label9.Anchor = (AnchorStyles.Top Or AnchorStyles.Left Or AnchorStyles.Right)
			AddressOf Me.Label9.AutoSize = True
			Dim arg_70B_0 As Control = AddressOf Me.Label9
			location = New Point(6, 27)
			arg_70B_0.Location = location
			AddressOf Me.Label9.Name = "Label9"
			Dim arg_732_0 As Control = AddressOf Me.Label9
			size = New Size(65, 17)
			arg_732_0.Size = size
			AddressOf Me.Label9.TabIndex = 12
			AddressOf Me.Label9.Text = "RAM: 0 %"
			AddressOf Me.PictureBox8.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.PictureBox8.BackColor = Color.Black
			AddressOf Me.PictureBox8.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.PictureBox8.Cursor = Cursors.No
			Dim arg_79F_0 As Control = AddressOf Me.PictureBox8
			location = New Point(16, 55)
			arg_79F_0.Location = location
			AddressOf Me.PictureBox8.Name = "PictureBox8"
			Dim arg_7C9_0 As Control = AddressOf Me.PictureBox8
			size = New Size(210, 30)
			arg_7C9_0.Size = size
			AddressOf Me.PictureBox8.TabIndex = 9
			AddressOf Me.PictureBox8.TabStop = False
			AddressOf Me.Button13.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button13.FlatStyle = FlatStyle.Flat
			Dim arg_814_0 As Control = AddressOf Me.Button13
			location = New Point(18, 986)
			arg_814_0.Location = location
			Dim arg_829_0 As Control = AddressOf Me.Button13
			margin = New Padding(4)
			arg_829_0.Margin = margin
			AddressOf Me.Button13.Name = "Button13"
			Dim arg_853_0 As Control = AddressOf Me.Button13
			size = New Size(229, 30)
			arg_853_0.Size = size
			AddressOf Me.Button13.TabIndex = 7
			AddressOf Me.Button13.Text = "Standart-Ansicht"
			AddressOf Me.Button13.UseVisualStyleBackColor = True
			AddressOf Me.Button14.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button14.BackColor = Color.Black
			AddressOf Me.Button14.FlatStyle = FlatStyle.Flat
			Dim arg_8C1_0 As Control = AddressOf Me.Button14
			location = New Point(1259, 278)
			arg_8C1_0.Location = location
			Dim arg_8D6_0 As Control = AddressOf Me.Button14
			margin = New Padding(4)
			arg_8D6_0.Margin = margin
			AddressOf Me.Button14.Name = "Button14"
			Dim arg_8FD_0 As Control = AddressOf Me.Button14
			size = New Size(31, 30)
			arg_8FD_0.Size = size
			AddressOf Me.Button14.TabIndex = 67
			AddressOf Me.Button14.Text = "<"
			AddressOf Me.Button14.UseVisualStyleBackColor = False
			AddressOf Me.PictureBox7.BackgroundImage = AddressOf Resources.Painter
			AddressOf Me.PictureBox7.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_95F_0 As Control = AddressOf Me.PictureBox7
			location = New Point(241, 205)
			arg_95F_0.Location = location
			AddressOf Me.PictureBox7.Name = "PictureBox7"
			Dim arg_986_0 As Control = AddressOf Me.PictureBox7
			size = New Size(31, 30)
			arg_986_0.Size = size
			AddressOf Me.PictureBox7.TabIndex = 53
			AddressOf Me.PictureBox7.TabStop = False
			AddressOf Me.PictureBox1.BackgroundImage = AddressOf Resources.Inet
			AddressOf Me.PictureBox1.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_9D5_0 As Control = AddressOf Me.PictureBox1
			location = New Point(241, 15)
			arg_9D5_0.Location = location
			AddressOf Me.PictureBox1.Name = "PictureBox1"
			Dim arg_9FC_0 As Control = AddressOf Me.PictureBox1
			size = New Size(31, 30)
			arg_9FC_0.Size = size
			AddressOf Me.PictureBox1.TabIndex = 47
			AddressOf Me.PictureBox1.TabStop = False
			AddressOf Me.PictureBox5.BackgroundImage = AddressOf Resources.Player
			AddressOf Me.PictureBox5.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_A4E_0 As Control = AddressOf Me.PictureBox5
			location = New Point(241, 167)
			arg_A4E_0.Location = location
			AddressOf Me.PictureBox5.Name = "PictureBox5"
			Dim arg_A75_0 As Control = AddressOf Me.PictureBox5
			size = New Size(31, 30)
			arg_A75_0.Size = size
			AddressOf Me.PictureBox5.TabIndex = 51
			AddressOf Me.PictureBox5.TabStop = False
			AddressOf Me.PictureBox6.BackgroundImage = AddressOf Resources._Option
			AddressOf Me.PictureBox6.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_AC7_0 As Control = AddressOf Me.PictureBox6
			location = New Point(241, 243)
			arg_AC7_0.Location = location
			AddressOf Me.PictureBox6.Name = "PictureBox6"
			Dim arg_AEE_0 As Control = AddressOf Me.PictureBox6
			size = New Size(31, 30)
			arg_AEE_0.Size = size
			AddressOf Me.PictureBox6.TabIndex = 52
			AddressOf Me.PictureBox6.TabStop = False
			AddressOf Me.PictureBox3.BackgroundImage = AddressOf Resources.Open
			AddressOf Me.PictureBox3.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_B3D_0 As Control = AddressOf Me.PictureBox3
			location = New Point(241, 91)
			arg_B3D_0.Location = location
			AddressOf Me.PictureBox3.Name = "PictureBox3"
			Dim arg_B64_0 As Control = AddressOf Me.PictureBox3
			size = New Size(31, 30)
			arg_B64_0.Size = size
			AddressOf Me.PictureBox3.TabIndex = 49
			AddressOf Me.PictureBox3.TabStop = False
			AddressOf Me.PictureBox4.BackgroundImage = AddressOf Resources.SkyVOSBig
			AddressOf Me.PictureBox4.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_BB6_0 As Control = AddressOf Me.PictureBox4
			location = New Point(241, 129)
			arg_BB6_0.Location = location
			AddressOf Me.PictureBox4.Name = "PictureBox4"
			Dim arg_BDD_0 As Control = AddressOf Me.PictureBox4
			size = New Size(31, 30)
			arg_BDD_0.Size = size
			AddressOf Me.PictureBox4.TabIndex = 50
			AddressOf Me.PictureBox4.TabStop = False
			AddressOf Me.PictureBox2.BackgroundImage = AddressOf Resources.Texter
			AddressOf Me.PictureBox2.BackgroundImageLayout = ImageLayout.Zoom
			Dim arg_C2C_0 As Control = AddressOf Me.PictureBox2
			location = New Point(241, 53)
			arg_C2C_0.Location = location
			AddressOf Me.PictureBox2.Name = "PictureBox2"
			Dim arg_C53_0 As Control = AddressOf Me.PictureBox2
			size = New Size(31, 30)
			arg_C53_0.Size = size
			AddressOf Me.PictureBox2.TabIndex = 48
			AddressOf Me.PictureBox2.TabStop = False
			AddressOf Me.Panel1.Anchor = (AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Panel1.BackgroundImage = AddressOf Resources.Farbverlauf31
			AddressOf Me.Panel1.BackgroundImageLayout = ImageLayout.Stretch
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button15)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button11)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button8)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Label8)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Label5)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button7)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Label4)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button6)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Label3)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Label6)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Label1)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button5)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Label2)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button4)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Label7)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button3)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button2)
			AddressOf Me.Panel1.Controls.Add(AddressOf Me.Button1)
			Dim arg_E36_0 As Control = AddressOf Me.Panel1
			location = New Point(1, -3)
			arg_E36_0.Location = location
			Dim arg_E4B_0 As Control = AddressOf Me.Panel1
			margin = New Padding(4)
			arg_E4B_0.Margin = margin
			AddressOf Me.Panel1.Name = "Panel1"
			Dim arg_E78_0 As Control = AddressOf Me.Panel1
			size = New Size(251, 1033)
			arg_E78_0.Size = size
			AddressOf Me.Panel1.TabIndex = 46
			AddressOf Me.Button15.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button15.FlatStyle = FlatStyle.Flat
			Dim arg_EB7_0 As Control = AddressOf Me.Button15
			location = New Point(18, 668)
			arg_EB7_0.Location = location
			Dim arg_ECC_0 As Control = AddressOf Me.Button15
			margin = New Padding(4)
			arg_ECC_0.Margin = margin
			AddressOf Me.Button15.Name = "Button15"
			Dim arg_EF6_0 As Control = AddressOf Me.Button15
			size = New Size(229, 30)
			arg_EF6_0.Size = size
			AddressOf Me.Button15.TabIndex = 63
			AddressOf Me.Button15.Text = "End"
			AddressOf Me.Button15.UseVisualStyleBackColor = True
			AddressOf Me.Button11.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button11.FlatStyle = FlatStyle.Flat
			Dim arg_F51_0 As Control = AddressOf Me.Button11
			location = New Point(18, 706)
			arg_F51_0.Location = location
			Dim arg_F66_0 As Control = AddressOf Me.Button11
			margin = New Padding(4)
			arg_F66_0.Margin = margin
			AddressOf Me.Button11.Name = "Button11"
			Dim arg_F90_0 As Control = AddressOf Me.Button11
			size = New Size(229, 30)
			arg_F90_0.Size = size
			AddressOf Me.Button11.TabIndex = 62
			AddressOf Me.Button11.Text = "Standard-Ansicht"
			AddressOf Me.Button11.UseVisualStyleBackColor = True
			AddressOf Me.Button8.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Left)
			AddressOf Me.Button8.FlatStyle = FlatStyle.Flat
			Dim arg_FEB_0 As Control = AddressOf Me.Button8
			location = New Point(18, 986)
			arg_FEB_0.Location = location
			Dim arg_1000_0 As Control = AddressOf Me.Button8
			margin = New Padding(4)
			arg_1000_0.Margin = margin
			AddressOf Me.Button8.Name = "Button8"
			Dim arg_102A_0 As Control = AddressOf Me.Button8
			size = New Size(229, 30)
			arg_102A_0.Size = size
			AddressOf Me.Button8.TabIndex = 7
			AddressOf Me.Button8.Text = "Standart-Ansicht"
			AddressOf Me.Button8.UseVisualStyleBackColor = True
			AddressOf Me.Label8.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label8.AutoSize = True
			AddressOf Me.Label8.BackColor = Color.Red
			AddressOf Me.Label8.ForeColor = Color.White
			Dim arg_10A5_0 As Control = AddressOf Me.Label8
			location = New Point(15, 740)
			arg_10A5_0.Location = location
			AddressOf Me.Label8.Name = "Label8"
			Dim arg_10CC_0 As Control = AddressOf Me.Label8
			size = New Size(13, 13)
			arg_10CC_0.Size = size
			AddressOf Me.Label8.TabIndex = 61
			AddressOf Me.Label8.Text = "F"
			AddressOf Me.Label5.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label5.AutoSize = True
			AddressOf Me.Label5.BackColor = Color.Red
			AddressOf Me.Label5.ForeColor = Color.White
			Dim arg_113C_0 As Control = AddressOf Me.Label5
			location = New Point(35, 740)
			arg_113C_0.Location = location
			AddressOf Me.Label5.Name = "Label5"
			Dim arg_1163_0 As Control = AddressOf Me.Label5
			size = New Size(13, 13)
			arg_1163_0.Size = size
			AddressOf Me.Label5.TabIndex = 60
			AddressOf Me.Label5.Text = "F"
			AddressOf Me.Button7.FlatStyle = FlatStyle.Flat
			Dim arg_11A6_0 As Control = AddressOf Me.Button7
			location = New Point(18, 246)
			arg_11A6_0.Location = location
			Dim arg_11BB_0 As Control = AddressOf Me.Button7
			margin = New Padding(4)
			arg_11BB_0.Margin = margin
			AddressOf Me.Button7.Name = "Button7"
			Dim arg_11E5_0 As Control = AddressOf Me.Button7
			size = New Size(229, 30)
			arg_11E5_0.Size = size
			AddressOf Me.Button7.TabIndex = 6
			AddressOf Me.Button7.Text = "Settings"
			AddressOf Me.Button7.UseVisualStyleBackColor = True
			AddressOf Me.Label4.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label4.AutoSize = True
			AddressOf Me.Label4.BackColor = Color.Red
			AddressOf Me.Label4.ForeColor = Color.White
			Dim arg_1260_0 As Control = AddressOf Me.Label4
			location = New Point(54, 740)
			arg_1260_0.Location = location
			AddressOf Me.Label4.Name = "Label4"
			Dim arg_1287_0 As Control = AddressOf Me.Label4
			size = New Size(13, 13)
			arg_1287_0.Size = size
			AddressOf Me.Label4.TabIndex = 59
			AddressOf Me.Label4.Text = "F"
			AddressOf Me.Button6.FlatStyle = FlatStyle.Flat
			Dim arg_12CA_0 As Control = AddressOf Me.Button6
			location = New Point(18, 208)
			arg_12CA_0.Location = location
			Dim arg_12DF_0 As Control = AddressOf Me.Button6
			margin = New Padding(4)
			arg_12DF_0.Margin = margin
			AddressOf Me.Button6.Name = "Button6"
			Dim arg_1309_0 As Control = AddressOf Me.Button6
			size = New Size(229, 30)
			arg_1309_0.Size = size
			AddressOf Me.Button6.TabIndex = 5
			AddressOf Me.Button6.Text = "EvoPaint"
			AddressOf Me.Button6.UseVisualStyleBackColor = True
			AddressOf Me.Label3.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label3.AutoSize = True
			AddressOf Me.Label3.BackColor = Color.Red
			AddressOf Me.Label3.ForeColor = Color.White
			Dim arg_1384_0 As Control = AddressOf Me.Label3
			location = New Point(73, 740)
			arg_1384_0.Location = location
			AddressOf Me.Label3.Name = "Label3"
			Dim arg_13AB_0 As Control = AddressOf Me.Label3
			size = New Size(13, 13)
			arg_13AB_0.Size = size
			AddressOf Me.Label3.TabIndex = 58
			AddressOf Me.Label3.Text = "F"
			AddressOf Me.Label6.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Label6.AutoSize = True
			AddressOf Me.Label6.BackColor = Color.Transparent
			AddressOf Me.Label6.Font = New Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Dim arg_1428_0 As Control = AddressOf Me.Label6
			location = New Point(34, 281)
			arg_1428_0.Location = location
			AddressOf Me.Label6.Name = "Label6"
			Dim arg_144F_0 As Control = AddressOf Me.Label6
			size = New Size(127, 21)
			arg_144F_0.Size = size
			AddressOf Me.Label6.TabIndex = 54
			AddressOf Me.Label6.Text = "Welcome, User!"
			AddressOf Me.Label1.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label1.AutoSize = True
			AddressOf Me.Label1.BackColor = Color.Red
			AddressOf Me.Label1.ForeColor = Color.White
			Dim arg_14BF_0 As Control = AddressOf Me.Label1
			location = New Point(111, 740)
			arg_14BF_0.Location = location
			AddressOf Me.Label1.Name = "Label1"
			Dim arg_14E6_0 As Control = AddressOf Me.Label1
			size = New Size(13, 13)
			arg_14E6_0.Size = size
			AddressOf Me.Label1.TabIndex = 56
			AddressOf Me.Label1.Text = "F"
			AddressOf Me.Button5.FlatStyle = FlatStyle.Flat
			Dim arg_1529_0 As Control = AddressOf Me.Button5
			location = New Point(18, 170)
			arg_1529_0.Location = location
			Dim arg_153E_0 As Control = AddressOf Me.Button5
			margin = New Padding(4)
			arg_153E_0.Margin = margin
			AddressOf Me.Button5.Name = "Button5"
			Dim arg_1568_0 As Control = AddressOf Me.Button5
			size = New Size(229, 30)
			arg_1568_0.Size = size
			AddressOf Me.Button5.TabIndex = 4
			AddressOf Me.Button5.Text = "EvoPlayer"
			AddressOf Me.Button5.UseVisualStyleBackColor = True
			AddressOf Me.Label2.Anchor = (AnchorStyles.Bottom Or AnchorStyles.Right)
			AddressOf Me.Label2.AutoSize = True
			AddressOf Me.Label2.BackColor = Color.Red
			AddressOf Me.Label2.ForeColor = Color.White
			Dim arg_15E3_0 As Control = AddressOf Me.Label2
			location = New Point(92, 740)
			arg_15E3_0.Location = location
			AddressOf Me.Label2.Name = "Label2"
			Dim arg_160A_0 As Control = AddressOf Me.Label2
			size = New Size(13, 13)
			arg_160A_0.Size = size
			AddressOf Me.Label2.TabIndex = 57
			AddressOf Me.Label2.Text = "F"
			AddressOf Me.Button4.FlatStyle = FlatStyle.Flat
			Dim arg_164D_0 As Control = AddressOf Me.Button4
			location = New Point(18, 132)
			arg_164D_0.Location = location
			Dim arg_1662_0 As Control = AddressOf Me.Button4
			margin = New Padding(4)
			arg_1662_0.Margin = margin
			AddressOf Me.Button4.Name = "Button4"
			Dim arg_168C_0 As Control = AddressOf Me.Button4
			size = New Size(229, 30)
			arg_168C_0.Size = size
			AddressOf Me.Button4.TabIndex = 3
			AddressOf Me.Button4.Text = "GreenStart"
			AddressOf Me.Button4.UseVisualStyleBackColor = True
			AddressOf Me.Label7.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Label7.AutoSize = True
			AddressOf Me.Label7.BackColor = Color.Transparent
			AddressOf Me.Label7.Font = New Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0)
			Dim arg_1714_0 As Control = AddressOf Me.Label7
			location = New Point(34, 302)
			arg_1714_0.Location = location
			AddressOf Me.Label7.Name = "Label7"
			Dim arg_173B_0 As Control = AddressOf Me.Label7
			size = New Size(101, 21)
			arg_173B_0.Size = size
			AddressOf Me.Label7.TabIndex = 55
			AddressOf Me.Label7.Text = "It's... o'clock"
			AddressOf Me.Button3.FlatStyle = FlatStyle.Flat
			Dim arg_177B_0 As Control = AddressOf Me.Button3
			location = New Point(18, 94)
			arg_177B_0.Location = location
			Dim arg_1790_0 As Control = AddressOf Me.Button3
			margin = New Padding(4)
			arg_1790_0.Margin = margin
			AddressOf Me.Button3.Name = "Button3"
			Dim arg_17BA_0 As Control = AddressOf Me.Button3
			size = New Size(229, 30)
			arg_17BA_0.Size = size
			AddressOf Me.Button3.TabIndex = 2
			AddressOf Me.Button3.Text = "Evoxplorer"
			AddressOf Me.Button3.UseVisualStyleBackColor = True
			AddressOf Me.Button2.FlatStyle = FlatStyle.Flat
			Dim arg_1805_0 As Control = AddressOf Me.Button2
			location = New Point(18, 56)
			arg_1805_0.Location = location
			Dim arg_181A_0 As Control = AddressOf Me.Button2
			margin = New Padding(4)
			arg_181A_0.Margin = margin
			AddressOf Me.Button2.Name = "Button2"
			Dim arg_1844_0 As Control = AddressOf Me.Button2
			size = New Size(229, 30)
			arg_1844_0.Size = size
			AddressOf Me.Button2.TabIndex = 1
			AddressOf Me.Button2.Text = "Texter Evoro"
			AddressOf Me.Button2.UseVisualStyleBackColor = True
			AddressOf Me.Button1.FlatStyle = FlatStyle.Flat
			Dim arg_188F_0 As Control = AddressOf Me.Button1
			location = New Point(18, 18)
			arg_188F_0.Location = location
			Dim arg_18A4_0 As Control = AddressOf Me.Button1
			margin = New Padding(4)
			arg_18A4_0.Margin = margin
			AddressOf Me.Button1.Name = "Button1"
			Dim arg_18CE_0 As Control = AddressOf Me.Button1
			size = New Size(229, 30)
			arg_18CE_0.Size = size
			AddressOf Me.Button1.TabIndex = 0
			AddressOf Me.Button1.Text = "SkyWeb Evoro"
			AddressOf Me.Button1.UseVisualStyleBackColor = True
			AddressOf Me.Button12.Anchor = (AnchorStyles.Top Or AnchorStyles.Right)
			AddressOf Me.Button12.FlatStyle = FlatStyle.Flat
			Dim arg_192C_0 As Control = AddressOf Me.Button12
			location = New Point(1027, 278)
			arg_192C_0.Location = location
			Dim arg_1941_0 As Control = AddressOf Me.Button12
			margin = New Padding(4)
			arg_1941_0.Margin = margin
			AddressOf Me.Button12.Name = "Button12"
			Dim arg_1968_0 As Control = AddressOf Me.Button12
			size = New Size(31, 30)
			arg_1968_0.Size = size
			AddressOf Me.Button12.TabIndex = 63
			AddressOf Me.Button12.Text = ">"
			AddressOf Me.Button12.UseVisualStyleBackColor = True
			AddressOf Me.Button12.Visible = False
			AddressOf Me.Aktualisieren.Enabled = True
			AddressOf Me.Aktualisieren.Interval = 1
			Dim autoScaleDimensions As SizeF = New SizeF(6F, 13F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = AutoScaleMode.Font
			Me.BackColor = Color.Black
			Me.BackgroundImage = AddressOf Resources.Black
			size = New Size(1290, 759)
			Me.ClientSize = size
			Me.Controls.Add(AddressOf Me.Button12)
			Me.Controls.Add(AddressOf Me.Button14)
			Me.Controls.Add(AddressOf Me.Panel3)
			Me.Controls.Add(AddressOf Me.Button10)
			Me.Controls.Add(AddressOf Me.Button9)
			Me.Controls.Add(AddressOf Me.PictureBox7)
			Me.Controls.Add(AddressOf Me.PictureBox1)
			Me.Controls.Add(AddressOf Me.PictureBox5)
			Me.Controls.Add(AddressOf Me.PictureBox6)
			Me.Controls.Add(AddressOf Me.PictureBox3)
			Me.Controls.Add(AddressOf Me.PictureBox4)
			Me.Controls.Add(AddressOf Me.PictureBox2)
			Me.Controls.Add(AddressOf Me.Panel1)
			Me.Controls.Add(AddressOf Me.Panel2)
			Me.Controls.Add(AddressOf Me.MenuStrip1)
			Me.DoubleBuffered = True
			Me.ForeColor = Color.White
			Me.FormBorderStyle = FormBorderStyle.None
			Me.IsMdiContainer = True
			Me.Name = "Ansicht2"
			Me.Text = "MDIParent2"
			Me.TransparencyKey = Color.FromArgb(255, 224, 192)
			Me.WindowState = FormWindowState.Maximized
			AddressOf Me.Panel3.ResumeLayout(False)
			AddressOf Me.GroupBox1.ResumeLayout(False)
			AddressOf Me.GroupBox1.PerformLayout()
			(CType(AddressOf Me.RAM_Bar, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox8, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox7, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox1, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox5, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox6, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox3, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox4, ISupportInitialize)).EndInit()
			(CType(AddressOf Me.PictureBox2, ISupportInitialize)).EndInit()
			AddressOf Me.Panel1.ResumeLayout(False)
			AddressOf Me.Panel1.PerformLayout()
			Me.ResumeLayout(False)
			Me.PerformLayout()
		End Sub

		Private Sub Timer1_Tick(sender As Object, e As EventArgs)
			AddressOf Me.Label7.Text = "It's " + Conversions.ToString(DateAndTime.TimeOfDay) + " o'clock."
			AddressOf Me.Panel2.SendToBack()
			If Not AddressOf AddressOf MyProject.Forms.Texteditor.Visible Then
				AddressOf Me.Label2.Text = "F"
				AddressOf Me.Label2.BackColor = Color.Red
			End If
			If Not AddressOf AddressOf MyProject.Forms.Browser.Visible Then
				AddressOf Me.Label1.Text = "F"
				AddressOf Me.Label1.BackColor = Color.Red
			End If
			If Not AddressOf AddressOf MyProject.Forms.Explorer.Visible Then
				AddressOf Me.Label3.Text = "F"
				AddressOf Me.Label3.BackColor = Color.Red
			End If
			If Not AddressOf AddressOf MyProject.Forms.GreenStart.Visible Then
				AddressOf Me.Label4.Text = "F"
				AddressOf Me.Label4.BackColor = Color.Red
			End If
			AddressOf Me.Label6.Text = "Welcome, " + AddressOf AddressOf MySettingsProperty.Settings.Username + "!"
		End Sub

		Private Sub Button1_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label1.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Browser.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Browser.Show()
				AddressOf Me.Label1.Text = "T"
				AddressOf Me.Label1.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("SkyWeb Evoro")
			Else
				AddressOf Me.Label1.Text = "T"
				AddressOf AddressOf MyProject.Forms.Browser.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Browser.Hide()
				AddressOf Me.Label1.Text = "F"
				AddressOf Me.Label1.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("SkyWeb Evoro")
				Catch expr_E8 As Exception
					ProjectData.SetProjectError(expr_E8)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub Button2_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label2.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Texteditor.Show()
				AddressOf Me.Label2.Text = "T"
				AddressOf Me.Label2.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("Texter Evoro")
			Else
				AddressOf Me.Label2.Text = "T"
				AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Texteditor.Hide()
				AddressOf Me.Label2.Text = "F"
				AddressOf AddressOf AddressOf MyProject.Forms.Texteditor.RichTextBox1.Clear()
				AddressOf Me.Label2.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("Texter Evoro")
				Catch expr_FF As Exception
					ProjectData.SetProjectError(expr_FF)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub Button3_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label3.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Explorer.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Explorer.Show()
				AddressOf Me.Label3.Text = "T"
				AddressOf Me.Label3.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("Evoxplorer")
			Else
				AddressOf Me.Label3.Text = "T"
				AddressOf AddressOf MyProject.Forms.Explorer.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Explorer.Hide()
				AddressOf Me.Label3.Text = "F"
				AddressOf Me.Label3.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("Evoxplorer")
				Catch expr_E8 As Exception
					ProjectData.SetProjectError(expr_E8)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub Button4_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label4.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.GreenStart.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.GreenStart.Show()
				AddressOf Me.Label4.Text = "T"
				AddressOf Me.Label4.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("GreenStart")
			Else
				AddressOf Me.Label4.Text = "T"
				AddressOf AddressOf MyProject.Forms.GreenStart.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.GreenStart.Hide()
				AddressOf Me.Label4.Text = "F"
				AddressOf Me.Label4.BackColor = Color.Red
				Try
					AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("GreenStart")
				Catch expr_E8 As Exception
					ProjectData.SetProjectError(expr_E8)
					ProjectData.ClearProjectError()
				End Try
			End If
		End Sub

		Private Sub Button5_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label5.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Form2.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Form2.Show()
				AddressOf Me.Label5.Text = "T"
				AddressOf Me.Label5.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("EvoPlayer")
			Else
				If Operators.CompareString(AddressOf Me.Label5.Text, "T", False) = 0 Then
					AddressOf AddressOf MyProject.Forms.Form2.MdiParent = Me
					AddressOf AddressOf MyProject.Forms.Form2.Hide()
					AddressOf Me.Label5.Text = "F"
					AddressOf Me.Label5.BackColor = Color.Red
					Try
						AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("EvoPlayer")
					Catch expr_F4 As Exception
						ProjectData.SetProjectError(expr_F4)
						ProjectData.ClearProjectError()
					End Try
				End If
			End If
		End Sub

		Private Sub Button6_Click(sender As Object, e As EventArgs)
			If Operators.CompareString(AddressOf Me.Label8.Text, "F", False) = 0 Then
				AddressOf AddressOf MyProject.Forms.Painter.MdiParent = Me
				AddressOf AddressOf MyProject.Forms.Painter.Show()
				AddressOf Me.Label8.Text = "T"
				AddressOf Me.Label8.BackColor = Color.Green
				AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Add("EvoPainter")
			Else
				If Operators.CompareString(AddressOf Me.Label8.Text, "T", False) = 0 Then
					AddressOf AddressOf MyProject.Forms.Painter.MdiParent = Me
					AddressOf AddressOf MyProject.Forms.Painter.Hide()
					AddressOf Me.Label8.Text = "F"
					AddressOf Me.Label8.BackColor = Color.Red
					Try
						AddressOf AddressOf AddressOf MyProject.Forms.Options.ListBox1.Items.Remove("EvoPainter")
					Catch expr_F4 As Exception
						ProjectData.SetProjectError(expr_F4)
						ProjectData.ClearProjectError()
					End Try
				End If
			End If
		End Sub

		Private Sub Button7_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.EinstellungenStart.Show()
		End Sub

		Private Sub MDIParent2_Load(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.Painter.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Explorer.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.GreenStart.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Options.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Form2.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = Me
			AddressOf AddressOf MyProject.Forms.Updater.MdiParent = Me
			AddressOf Me.Label1.Text = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label1.Text
			AddressOf Me.Label2.Text = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label2.Text
			AddressOf Me.Label3.Text = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label3.Text
			AddressOf Me.Label4.Text = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label4.Text
			AddressOf Me.Label5.Text = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label5.Text
			AddressOf Me.Label8.Text = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label8.Text
			AddressOf Me.Label1.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label1.BackColor
			AddressOf Me.Label2.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label2.BackColor
			AddressOf Me.Label3.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label3.BackColor
			AddressOf Me.Label4.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label4.BackColor
			AddressOf Me.Label5.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label5.BackColor
			AddressOf Me.Label8.BackColor = AddressOf AddressOf AddressOf MyProject.Forms.MDIParent1.Label8.BackColor
		End Sub

		Private Sub Button9_Click(sender As Object, e As EventArgs)
			AddressOf Me.Panel1.Hide()
			AddressOf Me.PictureBox1.Hide()
			AddressOf Me.PictureBox2.Hide()
			AddressOf Me.PictureBox3.Hide()
			AddressOf Me.PictureBox4.Hide()
			AddressOf Me.PictureBox5.Hide()
			AddressOf Me.PictureBox6.Hide()
			AddressOf Me.PictureBox7.Hide()
			AddressOf Me.Button9.Hide()
			AddressOf Me.Button10.Show()
		End Sub

		Private Sub Button10_Click(sender As Object, e As EventArgs)
			AddressOf Me.Panel1.Show()
			AddressOf Me.PictureBox1.Show()
			AddressOf Me.PictureBox2.Show()
			AddressOf Me.PictureBox3.Show()
			AddressOf Me.PictureBox4.Show()
			AddressOf Me.PictureBox5.Show()
			AddressOf Me.PictureBox6.Show()
			AddressOf Me.PictureBox7.Show()
			AddressOf Me.Button9.Show()
			AddressOf Me.Button10.Hide()
		End Sub

		Private Sub Button11_Click(sender As Object, e As EventArgs)
			AddressOf AddressOf MyProject.Forms.MDIParent1.Show()
			AddressOf AddressOf MyProject.Forms.Painter.MdiParent = AddressOf AddressOf MyProject.Forms.MDIParent1
			AddressOf AddressOf MyProject.Forms.Explorer.MdiParent = AddressOf AddressOf MyProject.Forms.MDIParent1
			AddressOf AddressOf MyProject.Forms.GreenStart.MdiParent = AddressOf AddressOf MyProject.Forms.MDIParent1
			AddressOf AddressOf MyProject.Forms.Options.MdiParent = AddressOf AddressOf MyProject.Forms.MDIParent1
			AddressOf AddressOf MyProject.Forms.Form2.MdiParent = AddressOf AddressOf MyProject.Forms.MDIParent1
			AddressOf AddressOf MyProject.Forms.Texteditor.MdiParent = AddressOf AddressOf MyProject.Forms.MDIParent1
			Me.Close()
		End Sub

		Private Sub Button14_MouseHover(sender As Object, e As EventArgs)
			AddressOf Me.Panel3.Show()
			AddressOf Me.Button14.Hide()
			AddressOf Me.Button12.Show()
		End Sub

		Private Sub Button14_Click(sender As Object, e As EventArgs)
			AddressOf Me.Panel3.Show()
			AddressOf Me.Button12.Show()
			AddressOf Me.Button14.Hide()
		End Sub

		Private Sub Button12_Click(sender As Object, e As EventArgs)
			AddressOf Me.Panel3.Hide()
			AddressOf Me.Button14.Show()
			AddressOf Me.Button12.Hide()
		End Sub

		Private Sub Button12_MouseHover(sender As Object, e As EventArgs)
			AddressOf Me.Panel3.Show()
		End Sub

		Private Sub Aktualisieren_Tick(sender As Object, e As EventArgs)
			Try
				AddressOf Me.Label9.Text = AddressOf AddressOf AddressOf MyProject.Forms.GreenStart.Label2.Text
				AddressOf Me.RAM_Bar.Width = AddressOf AddressOf AddressOf MyProject.Forms.GreenStart.RAM_Bar.Width
			Catch expr_40 As Exception
				ProjectData.SetProjectError(expr_40)
				ProjectData.ClearProjectError()
			End Try
		End Sub

		<MethodImpl(MethodImplOptions.NoInlining Or MethodImplOptions.NoOptimization)>
		Private Sub Button15_Click(sender As Object, e As EventArgs)
			ProjectData.EndApp()
		End Sub

		Private Sub Panel3_MouseLeave(sender As Object, e As EventArgs)
			AddressOf Me.Panel3.Hide()
			AddressOf Me.Button14.Show()
			AddressOf Me.Button12.Hide()
		End Sub

		Private Sub Panel3_Paint(sender As Object, e As PaintEventArgs)
		End Sub

		Private Sub Button10_MouseHover(sender As Object, e As EventArgs)
			AddressOf Me.Panel1.Show()
			AddressOf Me.PictureBox1.Show()
			AddressOf Me.PictureBox2.Show()
			AddressOf Me.PictureBox3.Show()
			AddressOf Me.PictureBox4.Show()
			AddressOf Me.PictureBox5.Show()
			AddressOf Me.PictureBox6.Show()
			AddressOf Me.PictureBox7.Show()
			AddressOf Me.Button9.Show()
			AddressOf Me.Button10.Hide()
		End Sub

		Private Sub GroupBox1_MouseHover(sender As Object, e As EventArgs)
			AddressOf Me.Panel3.Show()
		End Sub
	End Class
End Namespace
