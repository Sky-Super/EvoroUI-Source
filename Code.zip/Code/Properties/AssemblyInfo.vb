using System;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
[assembly: AssemblyVersion("0.4.0.0")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright © Mil Gaspar 2014")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("0.4")]
[assembly: AssemblyProduct("EvoroUI")]
[assembly: AssemblyTitle("EvoroUI")]
[assembly: AssemblyTrademark("")]
[assembly: NeutralResourcesLanguage("")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: ComVisible(true)]
[assembly: Guid("4073677a-3b5c-4935-95d1-d1e4c004df06")]
[assembly: TargetFramework(".NETFramework,Version=v4.0,Profile=Client", FrameworkDisplayName = ".NET Framework 4 Client Profile")]
