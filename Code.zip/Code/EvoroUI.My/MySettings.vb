Imports Microsoft.VisualBasic.ApplicationServices
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.CodeDom.Compiler
Imports System.ComponentModel
Imports System.Configuration
Imports System.Diagnostics
Imports System.Runtime.CompilerServices

Namespace EvoroUI.My
	<GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "10.0.0.0"), EditorBrowsable(EditorBrowsableState.Advanced), CompilerGenerated()>
	Friend Class MySettings
		Inherits ApplicationSettingsBase

		Private Shared defaultInstance As MySettings = CType(SettingsBase.Synchronized(New MySettings()), MySettings)

		Private Shared addedHandler As Boolean

		Private Shared addedHandlerLockObject As Object = RuntimeHelpers.GetObjectValue(New Object())

		Public Shared ReadOnly Property [Default]() As MySettings
			Get
				If Not MySettings.addedHandler Then
					Dim obj As Object = MySettings.addedHandlerLockObject
					ObjectFlowControl.CheckForSyncLockOnValueType(obj)
					SyncLock obj
						If Not MySettings.addedHandler Then
							AddHandler AddressOf MyProject.Application.Shutdown, AddressOf MySettings.AutoSaveSettings
							MySettings.addedHandler = True
						End If
					End SyncLock
				End If
				Return MySettings.defaultInstance
			End Get
		End Property

		<DefaultSettingValue("F"), UserScopedSetting(), DebuggerNonUserCode()>
		Public Property Pausiert() As String
			Get
				Return Conversions.ToString(Me("Pausiert"))
			End Get
			Set(value As String)
				Me("Pausiert") = value
			End Set
		End Property

		<DefaultSettingValue("Nein"), UserScopedSetting(), DebuggerNonUserCode()>
		Public Property Laeuft() As String
			Get
				Return Conversions.ToString(Me("Laeuft"))
			End Get
			Set(value As String)
				Me("Laeuft") = value
			End Set
		End Property

		<DefaultSettingValue("Hallo"), UserScopedSetting(), DebuggerNonUserCode()>
		Public Property Passwort() As String
			Get
				Return Conversions.ToString(Me("Passwort"))
			End Get
			Set(value As String)
				Me("Passwort") = value
			End Set
		End Property

		<DefaultSettingValue("User"), UserScopedSetting(), DebuggerNonUserCode()>
		Public Property Username() As String
			Get
				Return Conversions.ToString(Me("Username"))
			End Get
			Set(value As String)
				Me("Username") = value
			End Set
		End Property

		<DefaultSettingValue(""), UserScopedSetting(), DebuggerNonUserCode()>
		Public Property Pfad() As String
			Get
				Return Conversions.ToString(Me("Pfad"))
			End Get
			Set(value As String)
				Me("Pfad") = value
			End Set
		End Property

		<DefaultSettingValue("Desktop"), UserScopedSetting(), DebuggerNonUserCode()>
		Public Property StandartStartfenster() As String
			Get
				Return Conversions.ToString(Me("StandartStartfenster"))
			End Get
			Set(value As String)
				Me("StandartStartfenster") = value
			End Set
		End Property

		<DefaultSettingValue("2"), UserScopedSetting(), DebuggerNonUserCode()>
		Public Property Startdesign() As String
			Get
				Return Conversions.ToString(Me("Startdesign"))
			End Get
			Set(value As String)
				Me("Startdesign") = value
			End Set
		End Property

		<EditorBrowsable(EditorBrowsableState.Advanced), DebuggerNonUserCode()>
		Private Shared Sub AutoSaveSettings(sender As Object, e As EventArgs)
			If AddressOf MyProject.Application.SaveMySettingsOnExit Then
				AddressOf MySettingsProperty.Settings.Save()
			End If
		End Sub
	End Class
End Namespace
