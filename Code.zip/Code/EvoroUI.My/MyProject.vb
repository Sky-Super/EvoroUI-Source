Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.ApplicationServices
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.CodeDom.Compiler
Imports System.Collections
Imports System.ComponentModel
Imports System.ComponentModel.Design
Imports System.Diagnostics
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

Namespace EvoroUI.My
	<HideModuleName(), GeneratedCode("MyTemplate", "10.0.0.0")>
	Friend Module MyProject
		<MyGroupCollection("System.Windows.Forms.Form", "Create__Instance__", "Dispose__Instance__", "My.MyProject.Forms"), EditorBrowsable(EditorBrowsableState.Never)>
		Friend Class MyForms
			Public m_Ansicht2 As Ansicht2

			Public m_Black_Loader As Black_Loader

			Public m_Browser As Browser

			Public m_EinstellungenLoggin As EinstellungenLoggin

			Public m_EinstellungenStart As EinstellungenStart

			Public m_Explorer As Explorer

			Public m_Form1 As Form1

			Public m_Form2 As Form2

			Public m_GreenStart As GreenStart

			Public m_MDIParent1 As MDIParent1

			Public m_Options As Options

			Public m_Painter As Painter

			Public m_PainterInfo As PainterInfo

			Public m_Start As Start

			Public m_Texteditor As Texteditor

			Public m_Updater As Updater

			<ThreadStatic()>
			Private Shared m_FormBeingCreated As Hashtable

			Public Property Ansicht2() As Ansicht2
				Get
					Me.m_Ansicht2 = MyProject.MyForms.Create__Instance__(Of Ansicht2)(Me.m_Ansicht2)
					Return Me.m_Ansicht2
				End Get
				Set(value As Ansicht2)
					If value Is Me.m_Ansicht2 Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Ansicht2)(Me.m_Ansicht2)
				End Set
			End Property

			Public Property Black_Loader() As Black_Loader
				Get
					Me.m_Black_Loader = MyProject.MyForms.Create__Instance__(Of Black_Loader)(Me.m_Black_Loader)
					Return Me.m_Black_Loader
				End Get
				Set(value As Black_Loader)
					If value Is Me.m_Black_Loader Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Black_Loader)(Me.m_Black_Loader)
				End Set
			End Property

			Public Property Browser() As Browser
				Get
					Me.m_Browser = MyProject.MyForms.Create__Instance__(Of Browser)(Me.m_Browser)
					Return Me.m_Browser
				End Get
				Set(value As Browser)
					If value Is Me.m_Browser Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Browser)(Me.m_Browser)
				End Set
			End Property

			Public Property EinstellungenLoggin() As EinstellungenLoggin
				Get
					Me.m_EinstellungenLoggin = MyProject.MyForms.Create__Instance__(Of EinstellungenLoggin)(Me.m_EinstellungenLoggin)
					Return Me.m_EinstellungenLoggin
				End Get
				Set(value As EinstellungenLoggin)
					If value Is Me.m_EinstellungenLoggin Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of EinstellungenLoggin)(Me.m_EinstellungenLoggin)
				End Set
			End Property

			Public Property EinstellungenStart() As EinstellungenStart
				Get
					Me.m_EinstellungenStart = MyProject.MyForms.Create__Instance__(Of EinstellungenStart)(Me.m_EinstellungenStart)
					Return Me.m_EinstellungenStart
				End Get
				Set(value As EinstellungenStart)
					If value Is Me.m_EinstellungenStart Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of EinstellungenStart)(Me.m_EinstellungenStart)
				End Set
			End Property

			Public Property Explorer() As Explorer
				Get
					Me.m_Explorer = MyProject.MyForms.Create__Instance__(Of Explorer)(Me.m_Explorer)
					Return Me.m_Explorer
				End Get
				Set(value As Explorer)
					If value Is Me.m_Explorer Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Explorer)(Me.m_Explorer)
				End Set
			End Property

			Public Property Form1() As Form1
				Get
					Me.m_Form1 = MyProject.MyForms.Create__Instance__(Of Form1)(Me.m_Form1)
					Return Me.m_Form1
				End Get
				Set(value As Form1)
					If value Is Me.m_Form1 Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Form1)(Me.m_Form1)
				End Set
			End Property

			Public Property Form2() As Form2
				Get
					Me.m_Form2 = MyProject.MyForms.Create__Instance__(Of Form2)(Me.m_Form2)
					Return Me.m_Form2
				End Get
				Set(value As Form2)
					If value Is Me.m_Form2 Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Form2)(Me.m_Form2)
				End Set
			End Property

			Public Property GreenStart() As GreenStart
				Get
					Me.m_GreenStart = MyProject.MyForms.Create__Instance__(Of GreenStart)(Me.m_GreenStart)
					Return Me.m_GreenStart
				End Get
				Set(value As GreenStart)
					If value Is Me.m_GreenStart Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of GreenStart)(Me.m_GreenStart)
				End Set
			End Property

			Public Property MDIParent1() As MDIParent1
				Get
					Me.m_MDIParent1 = MyProject.MyForms.Create__Instance__(Of MDIParent1)(Me.m_MDIParent1)
					Return Me.m_MDIParent1
				End Get
				Set(value As MDIParent1)
					If value Is Me.m_MDIParent1 Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of MDIParent1)(Me.m_MDIParent1)
				End Set
			End Property

			Public Property Options() As Options
				Get
					Me.m_Options = MyProject.MyForms.Create__Instance__(Of Options)(Me.m_Options)
					Return Me.m_Options
				End Get
				Set(value As Options)
					If value Is Me.m_Options Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Options)(Me.m_Options)
				End Set
			End Property

			Public Property Painter() As Painter
				Get
					Me.m_Painter = MyProject.MyForms.Create__Instance__(Of Painter)(Me.m_Painter)
					Return Me.m_Painter
				End Get
				Set(value As Painter)
					If value Is Me.m_Painter Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Painter)(Me.m_Painter)
				End Set
			End Property

			Public Property PainterInfo() As PainterInfo
				Get
					Me.m_PainterInfo = MyProject.MyForms.Create__Instance__(Of PainterInfo)(Me.m_PainterInfo)
					Return Me.m_PainterInfo
				End Get
				Set(value As PainterInfo)
					If value Is Me.m_PainterInfo Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of PainterInfo)(Me.m_PainterInfo)
				End Set
			End Property

			Public Property Start() As Start
				Get
					Me.m_Start = MyProject.MyForms.Create__Instance__(Of Start)(Me.m_Start)
					Return Me.m_Start
				End Get
				Set(value As Start)
					If value Is Me.m_Start Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Start)(Me.m_Start)
				End Set
			End Property

			Public Property Texteditor() As Texteditor
				Get
					Me.m_Texteditor = MyProject.MyForms.Create__Instance__(Of Texteditor)(Me.m_Texteditor)
					Return Me.m_Texteditor
				End Get
				Set(value As Texteditor)
					If value Is Me.m_Texteditor Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Texteditor)(Me.m_Texteditor)
				End Set
			End Property

			Public Property Updater() As Updater
				Get
					Me.m_Updater = MyProject.MyForms.Create__Instance__(Of Updater)(Me.m_Updater)
					Return Me.m_Updater
				End Get
				Set(value As Updater)
					If value Is Me.m_Updater Then
						Return
					End If
					If value IsNot Nothing Then
						Throw New ArgumentException("Property can only be set to Nothing")
					End If
					Me.Dispose__Instance__(Of Updater)(Me.m_Updater)
				End Set
			End Property

			<DebuggerHidden()>
			Private Shared Function Create__Instance__(Of T As{Form, New})(Instance As T) As T
				If Instance Is Nothing OrElse Instance.IsDisposed Then
					If MyProject.MyForms.m_FormBeingCreated IsNot Nothing Then
						If MyProject.MyForms.m_FormBeingCreated.ContainsKey(GetType(T)) Then
							Throw New InvalidOperationException(Utils.GetResourceString("WinForms_RecursiveFormCreate", New String(0 - 1) {}))
						End If
					Else
						MyProject.MyForms.m_FormBeingCreated = New Hashtable()
					End If
					MyProject.MyForms.m_FormBeingCreated.Add(GetType(T), Nothing)
					Try
						Try
							Return Activator.CreateInstance(Of T)()
						End Try
						Dim arg_74_0 As Object
						Dim expr_79 As TargetInvocationException = TryCast(arg_74_0, TargetInvocationException)
						Dim arg_96_0 As Integer
						If expr_79 Is Nothing Then
							arg_96_0 = 0
						Else
							Dim ex As TargetInvocationException = expr_79
							ProjectData.SetProjectError(expr_79)
							arg_96_0 = (If(((ex.InnerException IsNot Nothing) > False), 1, 0))
						End If
						endfilter(arg_96_0)
					Finally
						MyProject.MyForms.m_FormBeingCreated.Remove(GetType(T))
					End Try
					Return Instance
				End If
				Return Instance
			End Function

			<DebuggerHidden()>
			Private Sub Dispose__Instance__(Of T As Form)(ByRef instance As T)
				instance.Dispose()
				instance = Nothing
			End Sub

			<EditorBrowsable(EditorBrowsableState.Never), DebuggerHidden()>
			Public Sub New()
			End Sub

			<EditorBrowsable(EditorBrowsableState.Never)>
			Public Overrides Function Equals(o As Object) As Boolean
				Return MyBase.Equals(RuntimeHelpers.GetObjectValue(o))
			End Function

			<EditorBrowsable(EditorBrowsableState.Never)>
			Public Overrides Function GetHashCode() As Integer
				Return MyBase.GetHashCode()
			End Function

			<EditorBrowsable(EditorBrowsableState.Never)>
			Friend Function [GetType]() As Type
				Return GetType(MyProject.MyForms)
			End Function

			<EditorBrowsable(EditorBrowsableState.Never)>
			Public Overrides Function ToString() As String
				Return MyBase.ToString()
			End Function
		End Class

		<MyGroupCollection("System.Web.Services.Protocols.SoapHttpClientProtocol", "Create__Instance__", "Dispose__Instance__", ""), EditorBrowsable(EditorBrowsableState.Never)>
		Friend Class MyWebServices
			<EditorBrowsable(EditorBrowsableState.Never), DebuggerHidden()>
			Public Overrides Function Equals(o As Object) As Boolean
				Return MyBase.Equals(RuntimeHelpers.GetObjectValue(o))
			End Function

			<EditorBrowsable(EditorBrowsableState.Never), DebuggerHidden()>
			Public Overrides Function GetHashCode() As Integer
				Return MyBase.GetHashCode()
			End Function

			<EditorBrowsable(EditorBrowsableState.Never), DebuggerHidden()>
			Friend Function [GetType]() As Type
				Return GetType(MyProject.MyWebServices)
			End Function

			<EditorBrowsable(EditorBrowsableState.Never), DebuggerHidden()>
			Public Overrides Function ToString() As String
				Return MyBase.ToString()
			End Function

			<DebuggerHidden()>
			Private Shared Function Create__Instance__(Of T As New)(instance As T) As T
				If instance Is Nothing Then
					Return Activator.CreateInstance(Of T)()
				End If
				Return instance
			End Function

			<DebuggerHidden()>
			Private Sub Dispose__Instance__(Of T)(ByRef instance As T)
				instance = Nothing
			End Sub

			<EditorBrowsable(EditorBrowsableState.Never), DebuggerHidden()>
			Public Sub New()
			End Sub
		End Class

		<EditorBrowsable(EditorBrowsableState.Never), ComVisible(False)>
		Friend Class ThreadSafeObjectProvider
			<CompilerGenerated(), ThreadStatic()>
			Private Shared m_ThreadStaticValue As T

			Friend ReadOnly Property GetInstance() As T
				<DebuggerHidden()>
				Get
					If MyProject.ThreadSafeObjectProvider(Of T).m_ThreadStaticValue Is Nothing Then
						MyProject.ThreadSafeObjectProvider(Of T).m_ThreadStaticValue = Activator.CreateInstance(Of T)()
					End If
					Return MyProject.ThreadSafeObjectProvider(Of T).m_ThreadStaticValue
				End Get
			End Property

			<EditorBrowsable(EditorBrowsableState.Never), DebuggerHidden()>
			Public Sub New()
			End Sub
		End Class

		Private m_ComputerObjectProvider As MyProject.ThreadSafeObjectProvider(Of MyComputer) = New MyProject.ThreadSafeObjectProvider(Of MyComputer)()

		Private m_AppObjectProvider As MyProject.ThreadSafeObjectProvider(Of MyApplication) = New MyProject.ThreadSafeObjectProvider(Of MyApplication)()

		Private m_UserObjectProvider As MyProject.ThreadSafeObjectProvider(Of User) = New MyProject.ThreadSafeObjectProvider(Of User)()

		Private m_MyFormsObjectProvider As MyProject.ThreadSafeObjectProvider(Of MyProject.MyForms) = New MyProject.ThreadSafeObjectProvider(Of MyProject.MyForms)()

		Private m_MyWebServicesObjectProvider As MyProject.ThreadSafeObjectProvider(Of MyProject.MyWebServices) = New MyProject.ThreadSafeObjectProvider(Of MyProject.MyWebServices)()

		<HelpKeyword("My.Computer")>
		Friend ReadOnly Property Computer() As MyComputer
			<DebuggerHidden()>
			Get
				Return MyProject.m_ComputerObjectProvider.GetInstance
			End Get
		End Property

		<HelpKeyword("My.Application")>
		Friend ReadOnly Property Application() As MyApplication
			<DebuggerHidden()>
			Get
				Return MyProject.m_AppObjectProvider.GetInstance
			End Get
		End Property

		<HelpKeyword("My.User")>
		Friend ReadOnly Property User() As User
			<DebuggerHidden()>
			Get
				Return MyProject.m_UserObjectProvider.GetInstance
			End Get
		End Property

		<HelpKeyword("My.Forms")>
		Friend ReadOnly Property Forms() As MyProject.MyForms
			<DebuggerHidden()>
			Get
				Return MyProject.m_MyFormsObjectProvider.GetInstance
			End Get
		End Property

		<HelpKeyword("My.WebServices")>
		Friend ReadOnly Property WebServices() As MyProject.MyWebServices
			<DebuggerHidden()>
			Get
				Return MyProject.m_MyWebServicesObjectProvider.GetInstance
			End Get
		End Property
	End Module
End Namespace
