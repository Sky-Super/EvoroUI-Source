Imports Microsoft.VisualBasic.Devices
Imports System
Imports System.CodeDom.Compiler
Imports System.ComponentModel
Imports System.Diagnostics

Namespace EvoroUI.My
	<GeneratedCode("MyTemplate", "10.0.0.0"), EditorBrowsable(EditorBrowsableState.Never)>
	Friend Class MyComputer
		Inherits Computer

		<EditorBrowsable(EditorBrowsableState.Never), DebuggerHidden()>
		Public Sub New()
		End Sub
	End Class
End Namespace
