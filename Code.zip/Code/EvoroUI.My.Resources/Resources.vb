Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.CodeDom.Compiler
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Globalization
Imports System.Resources
Imports System.Runtime.CompilerServices

Namespace EvoroUI.My.Resources
	<HideModuleName(), GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0"), DebuggerNonUserCode(), CompilerGenerated()>
	Friend Module Resources
		Private resourceMan As ResourceManager

		Private resourceCulture As CultureInfo

		<EditorBrowsable(EditorBrowsableState.Advanced)>
		Friend ReadOnly Property ResourceManager() As ResourceManager
			Get
				If Object.ReferenceEquals(Resources.resourceMan, Nothing) Then
					Dim temp As ResourceManager = New ResourceManager("EvoroUI.Resources", GetType(Resources).Assembly)
					Resources.resourceMan = temp
				End If
				Return Resources.resourceMan
			End Get
		End Property

		<EditorBrowsable(EditorBrowsableState.Advanced)>
		Friend Property Culture() As CultureInfo
			Get
				Return Resources.resourceCulture
			End Get
			Set(value As CultureInfo)
				Resources.resourceCulture = value
			End Set
		End Property

		Friend ReadOnly Property _0614_gigaombw_chip_630x420() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("0614_gigaombw_chip_630x420", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property _Option() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Option", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property ajax_loader__5_() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("ajax-loader (5)", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Black() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Black", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property bootanimation() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("bootanimation", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property CPU_Bar_1() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("CPU_Bar_1", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property CPU_Bar_11() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("CPU_Bar_11", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property CPU_Bar_Inner_1() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("CPU_Bar_Inner_1", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Farbverlauf() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Farbverlauf", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Farbverlauf2() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Farbverlauf2", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Farbverlauf3() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Farbverlauf3", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Farbverlauf31() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Farbverlauf31", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Farbverlauf32() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Farbverlauf32", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property GMmods_Modern___Kopieé() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("GMmods Modern - Kopieé", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property GMmods_Modern___Kopieé1() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("GMmods Modern - Kopieé1", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Inet() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Inet", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Metall() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Metall", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Open() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Open", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Painter() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Painter", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Player() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Player", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property SkyVOSBig() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("SkyVOSBig", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property SkyVOSBig___Kopie() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("SkyVOSBig - Kopie", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Texter() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Texter", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Textur() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Textur", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property Up() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("Up", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property VerlaufGrau() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("VerlaufGrau", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property VerlaufGrau1() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("VerlaufGrau1", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property VerlaufGrau2() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("VerlaufGrau2", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property windows8() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("windows8", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property

		Friend ReadOnly Property X() As Bitmap
			Get
				Dim obj As Object = RuntimeHelpers.GetObjectValue(AddressOf Resources.ResourceManager.GetObject("X", Resources.resourceCulture))
				Return CType(obj, Bitmap)
			End Get
		End Property
	End Module
End Namespace
